
//////SC INI Dijual !!!!   

// Message Filter / Message Cooldowns
const usedCommandRecently = new Set()

const isFiltered = (from) => {
return !!usedCommandRecently.has(from)
}

const addFilter = (from) => {
usedCommandRecently.add(from)
setTimeout(() => {
return usedCommandRecently.delete(from)
}, 3000) // 3 detik
}

module.exports = {
antispam: { isFiltered, addFilter }
}