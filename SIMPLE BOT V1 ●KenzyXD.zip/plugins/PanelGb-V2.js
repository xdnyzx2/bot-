const fs = require("fs")
const os = require('os');
let handler = async (m, { Kenz, isCreator, isPremium, qtext, runtime, toIDR, qkontak, asumaSaldo, Kenzganteng, pickRandom, readmore,fetchJson, prefix, sleep, salam, totalfitur}) => {

const xmenu_oh = `
*\`➠ ㌕ -Menu Panel 1gb - Unli V2\`*
> *➟ 1gb-V2*
> *➟ 2gb-V2*
> *➟ 3gb-V2*
> *➟ 4gb-V2*
> *➟ 5gb-V2*
> *➟ 6gb-V2*
> *➟ 7gb-V2*
> *➟ 8gb-V2*
> *➟ 9gb-V2*
> *➟ 10gb-V2*
> *➟ unlimited-V2*`

const resize = async(buffer, ukur1, ukur2) => {
 return new Promise(async(resolve, reject) => {
 let jimp = require('jimp')
 var baper = await jimp.read(buffer);
 var ab = await baper.resize(ukur1, ukur2).getBufferAsync(jimp.MIME_JPEG)
 resolve(ab)
 })
}
Kenz.sendMessage(m?.chat, {
 video: {
 url: "https://files.catbox.moe/nz84fr.mp4"
 }, 
 mimetype: "video/mp4", 
 caption: xmenu_oh,
 footer: `\n© ${global.namaOwner2}`,
   buttons: [
  {
    buttonId: '.allmenu',
    buttonText: {
      displayText: 'Tampilkan Semua Menu📋'
    },
    type: 1,
  },
  {
    buttonId: '.menu-list',
    buttonText: {
      displayText: 'Tampilkan Menu List'
    },
    type: 1,
  },
  {
    buttonId: 'action',
    buttonText: {
      displayText: 'ini pesan interactiveMeta'
    },
    type: 4,
    nativeFlowInfo: {
      name: 'single_select',
      paramsJson: JSON.stringify({
        title: 'click here',
        sections: [
          {
            title: `${global.nameHost} - 2025`,
            highlight_label: '',
            rows: [
              {
                header: 'Menu Panel V1',
                title: 'Tampilkan Menu Panel V1',
                description: '© Kenz - ribut',
                id: 'menu-panelv1',
              },
              {
                header: 'Menu Panel V2',
                title: 'Tampilkan Menu Panel V2',
                description: '© Kenz - ribut',
                id: '.menu-panelv2',
              },

            ],
          },
        ],
      }),
    },
  },
  ],
 viewOnce: true,
 headerType: 6,
 contextInfo: {
 isForwarded: true,
 forwardingScore: 99999,
mentionedJid: [global.owner+"@s.whatsapp.net", m.sender],
 externalAdReply: {
 showAdAttribution: true,
 title: `${global.namaOwner} | ${global.botname2}`,
 mediaType: 1,
 previewType: 1,
 body: `${m.pushName}`,
 //previewType: "PHOTO",
 thumbnail: fs.readFileSync('./source/media/menuowner.jpg'),
 renderLargerThumbnail: true,
 mediaUrl: null,
 sourceUrl: null,
 },
 forwardedNewsletterMessageInfo: {
 newsletterJid: idSaluran,
 serverMessageId: -1,
 newsletterName: `Whatsapp Bot ${namaOwner}`,
 }
 }
}, { quoted: null });
let pler = await fetchJson('https://raw.githubusercontent.com/ditss-dev/musikk/main/randomm.json');

let itil = pler[Math.floor(Math.random() * pler.length)];
//await Kenz.sendMessage(m.chat, { audio:{url: itil},mimetype: 'audio/mp4', ptt: true, fileLength: 88738}, { quoted: qkontak })
await Kenz.sendMessage(m.chat, { audio: { url: itil}, mimetype: 'audio/mpeg', ptt: true,
  contextInfo: {
    mentionedJid: [m.sender],
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
      newsletterJid: global.idSaluran,
      newsletterName: `${salam} ${m.pushName}`,
      serverMessageId: 143
    }
  }
}, { 
  quoted: {
    key: { 
      fromMe: false, 
      participant: m.sender, 
      id: 'fake-msg-id' 
    },
    message: { 
      conversation: '....' 
    }
  }
})

}


handler.command = ["panelgb-V2", "panelgb2"]

module.exports = handler