const fs = require("fs");
const os = require("os");

let handler = async (m, { Kenz, command, text, prefix }) => {
  if (!text) return m.reply(`*Format salah!*\nPenggunaan:\n${prefix + command} hostname, ipVps`);

  let t = text.split(",");
  if (t.length < 2) return m.reply(`*Format salah!*\nPenggunaan:\n${prefix + command} hostname, ipVps`);

  let hostname = t[0].trim();
  let ip = t[1].trim();

  const xmenu_oh = `*Klik Tombol Di Bawah Untuk Melihat Domain Yang Tersedia*`;

  await Kenz.sendMessage(m.chat, {
    video: {
      url: "https://files.catbox.moe/nz84fr.mp4"
    },
    gifPlayback: true, // Menjadikan video sebagai GIF
    mimetype: "video/mp4",
    caption: xmenu_oh,
    footer: `\n© ${global.namaOwner2}`,
    buttons: [
      {
        buttonId: `.allmenu`,
        buttonText: { displayText: 'All Menu' },
        type: 1
      },
      {
        buttonId: `.menu-list`,
        buttonText: { displayText: 'List Menu' },
        type: 1
      },
      {
        buttonId: 'action',
        buttonText: {
          displayText: 'Pesan InteractiveMeta'
        },
        type: 4,
        nativeFlowInfo: {
          name: 'single_select',
          paramsJson: JSON.stringify({
            title: 'Klik di sini',
            sections: [
              {
                title: `${global.nameHost} - 2025`,
                highlight_label: '',
                rows: [
                  { 
                    title: "privatserver.my.id", 
                    description: "Aktif ✅", 
                    id: `.domain1 ${hostname}|${ip}` 
                  },
                  { 
                    title: "panelwebsite.biz.id", 
                    description: "Aktif ✅", 
                    id: `.domain2 ${hostname}|${ip}` 
                  },
                  { 
                    title: "panel-Kenz.my.id", 
                    description: "Aktif ✅", 
                    id: `.domain3 ${hostname}|${ip}` 
                  },
                  { 
                    title: "serverku.biz.id", 
                    description: "Aktif ✅", 
                    id: `.domain4 ${hostname}|${ip}` 
                  }
                ],
              },
            ],
          }),
        },
      },
    ],
    viewOnce: true,
    headerType: 6,
    contextInfo: {
      isForwarded: true,
      forwardingScore: 99999,
      mentionedJid: [global.owner + "@s.whatsapp.net", m.sender],
      forwardedNewsletterMessageInfo: {
        newsletterJid: global.idSaluran,
        newsletterName: `WhatsApp Bot ${global.namaOwner2}`,
        serverMessageId: -1
      }
    }
  }, { quoted: null });
};

// Konfigurasi plugin
handler.help = ["buysubdomain", "buydomain", "buysubdo"];
handler.tags = ["internet", "domain"];
handler.command = ["buysubdomain", "buydomain", "buysubdo"];
handler.premium = false;
handler.limit = false;

module.exports = handler;
