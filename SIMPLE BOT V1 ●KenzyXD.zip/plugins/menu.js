const fs = require("fs");
const os = require("os");

let handler = async (m, { Kenz, isCreator, isPremium, qtext, runtime, toIDR, qkontak, asumaSaldo, Kenzganteng, pickRandom, readmore, fetchJson, prefix, sleep, salam, totalfitur }) => {
  
  const xmenu_oh = `*— Ola' ${salam} @${m.pushName} Welcome To Bot © KenzyXD - Official*

*I N F O R M A T I O N*
*▢ Developer :* @${global.owner}
*▢ Versi : 4.5*
*▢ Type : Case-Plugins*
*▢ Status : ${runtime(process.uptime())}*
*▢ Total Fitur : ${totalfitur}*

*Please Select The Button Below.*`;

  // Daftar suara untuk dipilih secara acak
  const soundList = [
    "https://files.catbox.moe/z0lsk8.mp3", 
    "https://files.catbox.moe/v9fno3.mp3",
    "https://files.catbox.moe/g2hyzt.mp3",
    "https://files.catbox.moe/ox0kie.mp3",
    "https://files.catbox.moe/ircdqf.m4a",
    "https://files.catbox.moe/yuogxi.mp3",
    "https://files.catbox.moe/89216l.m4a"
  ];

  // Pilih suara secara acak
  const randomSound = soundList[Math.floor(Math.random() * soundList.length)];

  // Kirim video dengan menu
  await Kenz.sendMessage(m.chat, {
    video: {
      url: "https://files.catbox.moe/nz84fr.mp4"
    },
    gifPlayback: true, 
    mimetype: "video/mp4",
    caption: xmenu_oh,
    footer: `Kenz Bau`,
    buttons: [
      {
        buttonId: `.allmenu`,
        buttonText: { displayText: 'All Menu' },
        type: 1
      },
      {
        buttonId: `.menu-list`,
        buttonText: { displayText: 'List Menu' },
        type: 1
      },
      {
        buttonId: 'action',
        buttonText: {
          displayText: 'Pesan InteractiveMeta'
        },
        type: 4,
        nativeFlowInfo: {
          name: 'single_select',
          paramsJson: JSON.stringify({
            title: 'Klik di sini',
            sections: [
              {
                title: `${global.nameHost} - 2025`,
                highlight_label: '',
                rows: [
                  {
                    header: 'Menu Otomatis',
                    title: 'Tampilkan Menu Otomatis',
                    description: '© Kenz - ribut',
                    id: 'menu-otomatis',
                  },
                  {
                    header: 'Owner 😈',
                    title: 'Tampilkan Contact Owner',
                    description: '© Kenz - ribut',
                    id: '.owner',
                  },
                ],
              },
            ],
          }),
        },
      },
    ],
    viewOnce: true,
    headerType: 6,
    contextInfo: {
      isForwarded: true,
      forwardingScore: 99999,
      mentionedJid: [global.owner + "@s.whatsapp.net", m.sender],
      forwardedNewsletterMessageInfo: {
        newsletterJid: global.idSaluran,
        serverMessageId: -1,
        newsletterName: `WhatsApp Bot ${global.namaOwner}`,
      }
    }
  }, { quoted: null });

  // Kirim suara acak setelah menu ditampilkan
  await Kenz.sendMessage(m.chat, {
    audio: { 
      url: randomSound
    },
    mimetype: "audio/mp4",
    ptt: true // Mengubah audio menjadi voice note (PTT)
  });

};

handler.command = ["menu", "Kenz"];

module.exports = handler;