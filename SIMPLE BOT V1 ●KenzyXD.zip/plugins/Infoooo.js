const fs = require("fs")
const os = require('os');
let handler = async (m, { Kenz, isCreator, isPremium, qtext, runtime, toIDR, qkontak, asumaSaldo, Kenzganteng, pickRandom, readmore,fetchJson, prefix, sleep, salam, totalfitur}) => {

const xmenu_oh = `*\`I N F O R M A T O N  B O T\`*
*—Total Pengguna :* ${Object.keys(db.users).length}
*—Total Fitur :* ${totalfitur}
*—Command Used :* ${db.users[m.sender].hitcmd}
*—Device :* \`IPhone 20 Pro\`

*\`I N F O R M A T I O N  U S E R\`*
*—Status :* \`${isCreator ? "Owner" : isPremium ? "Premium" : "Free User"}\`
*—Number :* ${m.sender.split("@")[0]}`;

  await Kenz.sendMessage(m.chat, {
    video: {
      url: "https://files.catbox.moe/9apr2a.mp4"
    },
    gifPlayback: true, 
    mimetype: "video/mp4",
    caption: xmenu_oh,
    footer: `Kenz Xpoww`,
    buttons: [
      {
        buttonId: `.allmenu`,
        buttonText: { displayText: 'All Menu' },
        type: 1
      },
      {
        buttonId: `.menu-list`,
        buttonText: { displayText: 'List Menu' },
        type: 1
      },
      {
        buttonId: 'action',
        buttonText: {
          displayText: 'Pesan InteractiveMeta'
        },
        type: 4,
        nativeFlowInfo: {
          name: 'single_select',
          paramsJson: JSON.stringify({
            title: 'Klik di sini',
            sections: [
              {
                title: `${global.nameHost} - 2025`,
                highlight_label: '',
                rows: [
                  {
                    header: 'Menu Otomatis',
                    title: 'Tampilkan Menu Otomatis',
                    description: '© Kenz - ribut',
                    id: 'menu-otomatis',
                  },
                  {
                    header: 'Owner 😈',
                    title: 'Tampilkan Contact Owner',
                    description: '© Kenz - ribut',
                    id: '.owner',
                  },
                ],
              },
            ],
          }),
        },
      },
    ],
    viewOnce: true,
    headerType: 6,
    contextInfo: {
      isForwarded: true,
      forwardingScore: 99999,
      mentionedJid: [global.owner + "@s.whatsapp.net", m.sender],
      forwardedNewsletterMessageInfo: {
        newsletterJid: global.idSaluran,
        serverMessageId: -1,
        newsletterName: `WhatsApp Bot ${namaOwner}`,
      }
    }
  }, { quoted: null });

};

handler.command = ["info", "script"];

module.exports = handler;