const fs = require("fs")
const os = require('os');
let handler = async (m, { Kenz, isCreator, isPremium, qtext, runtime, toIDR, qkontak, asumaSaldo, Kenzganteng, pickRandom, readmore,fetchJson, prefix, sleep, salam, totalfitur}) => {

const xmenu_oh = `*\`I N F O R M A T O N  B O T\`*
*—Total Pengguna :* ${Object.keys(db.users).length}
*—Total Fitur :* ${totalfitur}
*—Command Used :* ${db.users[m.sender].hitcmd}
*—Device :* \`IPhone 60 Pro\`

*\`I N F O R M A T I O N  U S E R\`*
*—Status :* \`${isCreator ? "Owner" : isPremium ? "Premium" : "Free User"}\`
*—Number :* ${m.sender.split("@")[0]}

> *© KenzyXD - Official || 2024 - 2025*
‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎


[ *\`金 List Menu Bot 金\`* ]
— ≽ .allmenu
— ≽ .menu-panel
— ≽ .panel-v2
— ≽ .menu-install
— ≽ .menu-otomatis
— ≽ .menu-store
— ≽ .menu-push
— ≽ .menu-vps
— ≽ .menu-sticker
— ≽ .menu-download
— ≽ .menu-group
— ≽ .menu-owner
— ≽ .installtema

[ *\`金 List Menu Panel V1 金\`* ]
— ≽ .addseller
— ≽ .delseller
— ≽ .listseller
— ≽ .addowner
— ≽ .delowner
— ≽ .listowner
— ≽ .listpanel
— ≽ .listadmin
— ≽ .delpanel
— ≽ .delpanelall
— ≽ .deladmin
— ≽ .cadmin
— ≽ .cadmin1
— ≽ .1gb-unli
— ≽ .cpanel

[ *\`金 List Menu Panel Versi 2 金\`* ]
— ≽ .addprem
— ≽ .delprem
— ≽ .listprem
— ≽ .listpanel
— ≽ .listadmin-v2
— ≽ .delpanel-v2
— ≽ .delpanelall-v2
— ≽ .deladmin-v2
— ≽ .deladminall-v2
— ≽ .cadmin-v2
— ≽ .cadmin1-v2
— ≽ .1gb-v2 - unli-v2
— ≽ .cpanel-v2 

[ *\`金 List Menu Installer 金\`* ]
— ≽ .installtema
— ≽ .startwings
— ≽ .installpanel
— ≽ .installtemamaster
— ≽ .installtemanebula
— ≽ .installtemadepend
— ≽ .installtemabilling
— ≽ .installtemaenigma
— ≽ .hbpanel
— ≽ .uninstallpanel

[ *\`金 List Menu Layanan 金\`* ]
— ≽ .buypanel
— ≽ .buyresellerpanel
— ≽ .buyadminpanel
— ≽ .buypartnerpanel
— ≽ .buyownerpanel
— ≽ .buyscript 
— ≽ .buyvps
— ≽ .addscript
— ≽ .delscript
— ≽ .listscript 
— ≽ .jasainstalltema
— ≽ .jasainstallpanel
— ≽ .jasajpmch
— ≽ .jasajpmgroup

[ *\`金 List Menu Store 金\`* ]
— ≽ .payment
— ≽ .dana
— ≽ .ovo
— ≽ .gopay
— ≽ .qris
— ≽ .proses
— ≽ .done

[ *\`金 List Menu Push 金\`* ]
— ≽ .pushkontak
— ≽ .pushkontak1
— ≽ .pushkontak2
— ≽ .savekontak
— ≽ .savekontak1
— ≽ .jpm
— ≽ .jpm1
— ≽ .jpmslide
— ≽ .jpmslideht
— ≽ .listgc
— ≽ .cekidch

[ *\`金 List Menu Create VPS 金\`* ]
— ≽ .cvps *Button*
— ≽ .deldroplet
— ≽ .sisadroplet
— ≽ .rebuild
— ≽ .restartvps
— ≽ .listdroplet
— ≽ .r1c1
— ≽ .r2c2
— ≽ .r4c2
— ≽ .r8c4
— ≽ .r16c4

[ *\`金 List Menu Sticker 金\` ]
— ≽ .sticker
— ≽ .qc
— ≽ .brat
— ≽ .ai
— ≽ .tourl
— ≽ .tohd
— ≽ .translate
— ≽ .stickerwm

[ *\`金 List Menu Download 金\`* ]
— ≽ .tiktok
— ≽ .tiktokmp3
— ≽ .instagram
— ≽ .ytmp4
— ≽ .ytmp3
— ≽ .play
— ≽ .mediafire

[ *\`金 List Menu Group 金\`* ]
— ≽ .on
— ≽ .off
— ≽ .hidetag
— ≽ .addmember
— ≽ .closegc
— ≽ .opengc
— ≽ .kick
— ≽ .kicktime
— ≽ .spamtag
— ≽ .promote
— ≽ .demote

[ *\`金 List Menu Owner 金\` ]
— ≽ .owner
— ≽ .self
— ≽ .public
— ≽ .subdo
— ≽ .getcase
— ≽ .savesticker`;

  await Kenz.sendMessage(m.chat, {
    video: {
      url: "https://files.catbox.moe/nz84fr.mp4"
    },
    gifPlayback: true, 
    mimetype: "video/mp4",
    caption: xmenu_oh,
    footer: `Kenz Bau`,
    buttons: [
      {
        buttonId: `.allmenu`,
        buttonText: { displayText: 'All Menu' },
        type: 1
      },
      {
        buttonId: `.menu-list`,
        buttonText: { displayText: 'List Menu' },
        type: 1
      },
      {
        buttonId: 'action',
        buttonText: {
          displayText: 'Pesan InteractiveMeta'
        },
        type: 4,
        nativeFlowInfo: {
          name: 'single_select',
          paramsJson: JSON.stringify({
            title: 'Klik di sini',
            sections: [
              {
                title: `${global.nameHost} - 2025`,
                highlight_label: '',
                rows: [
                  {
                    header: 'Menu Otomatis',
                    title: 'Tampilkan Menu Otomatis',
                    description: '© Kenz - ribut',
                    id: 'menu-otomatis',
                  },
                  {
                    header: 'Owner 😈',
                    title: 'Tampilkan Contact Owner',
                    description: '© Kenz - ribut',
                    id: '.owner',
                  },
                ],
              },
            ],
          }),
        },
      },
    ],
    viewOnce: true,
    headerType: 6,
    contextInfo: {
      isForwarded: true,
      forwardingScore: 99999,
      mentionedJid: [global.owner + "@s.whatsapp.net", m.sender],
      forwardedNewsletterMessageInfo: {
        newsletterJid: global.idSaluran,
        serverMessageId: -1,
        newsletterName: `WhatsApp Bot ${namaOwner}`,
      }
    }
  }, { quoted: null });

};

handler.command = ["allmenu", "menuall"];

module.exports = handler;