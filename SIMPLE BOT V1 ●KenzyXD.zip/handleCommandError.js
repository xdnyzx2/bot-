const stringSimilarity = require('string-similarity');

const commands = [
    ".saldo", ".menu", ".help", ".buy", ".status", ".owner"
]; // Tambahkan semua command botmu

async function handleCommandError(m, Keel, command) {
    const bestMatch = stringSimilarity.findBestMatch(command, commands);
    const isSimilar = bestMatch.bestMatch.rating >= 0.5; // Minimal kemiripan 50%

    let responseText = "🚨 Perintah yang Anda gunakan salah!";
    let buttons = [
        { buttonId: ".menu", buttonText: { displayText: "📜 Lihat Menu" }, type: 1 }
    ];

    if (isSimilar) {
        responseText += `\n🔍 Mungkin yang Anda maksud adalah: *${bestMatch.bestMatch.target}*`;
        responseText += `\n📊 Hasil kemiripan: *${Math.round(bestMatch.bestMatch.rating * 100)}%*`;
        buttons.unshift({ 
            buttonId: bestMatch.bestMatch.target, 
            buttonText: { displayText: `✅ Gunakan ${bestMatch.bestMatch.target}` }, 
            type: 1 
        });
    }

    await Keel.sendMessage(m.chat, {
        text: responseText,
        footer: "Pilih metode di bawah:",
        buttons: buttons,
        headerType: 1
    }, { quoted: m });
}

module.exports = handleCommandError;