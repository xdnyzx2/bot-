//Kenz v1.0.0 (premium)
require('./settings');
const fs = require('fs');
const pino = require('pino');
const path = require('path');
const axios = require('axios');
const chalk = require('chalk');
const readline = require('readline');
const { color } = require('./system/color');
const cfonts = require('cfonts');
const FileType = require('file-type');
const { exec } = require('child_process');
const { say } = require('cfonts')
const { Boom } = require('@hapi/boom');
const handleCommandError = require('./handleCommandError');
const NodeCache = require('node-cache');
let d = new Date
let gmt = new Date(0).getTime() - new Date('1 Januari 2023').getTime()
const weton = ['Pahing', 'Pon', 'Wage', 'Kliwon', 'Legi'][Math.floor(((d * 1) + gmt) / 84600000) % 5]
const week = d.toLocaleDateString('id', { weekday: 'long' })
const calender = d.toLocaleDateString('id', { day: 'numeric', month: 'long', year: 'numeric' })
const { default: WAConnection, generateWAMessageFromContent, 
prepareWAMessageMedia, useMultiFileAuthState, Browsers, DisconnectReason, makeInMemoryStore, makeCacheableSignalKeyStore, fetchLatestWaWebVersion, proto, PHONENUMBER_MCC, getAggregateVotesInPollMessage, InteractiveMessage, } = require('@whiskeysockets/baileys');

const pairingCode = global.pairing_code || process.argv.includes('--pairing-code');
const rl = readline.createInterface({ input: process.stdin, output: process.stdout })
const question = (text) => new Promise((resolve) => rl.question(text, resolve))

/*const { cleaningSession } = require("./library/boostsession");
(async () => {
await setInterval(async () => {
await cleaningSession("./session")
}, 10000)
})*/
const pwnya = 'kenzysukatobrut';
const pwinput = (query) => {
    return new Promise(resolve => rl.question(query, resolve));
};
const mengecekpassword = (password, users) => {
    return users.some(user => user.password === password);
};
async function verifyPassword() {
    try {
        const response = await axios.get(pwnya);
        const data = response.data;
    console.log(chalk.blue.bold('masukan Password Untuk Melanjutkan'))
        const password = await pwinput(color('Password Yang anda Masukan: ', 'red'));
        if (mengecekpassword(password, data.users)) {
            console.log(color('Login sukses!', 'green'));
            return true;
        } else {
            console.log(color('Password salah', 'red'));
            process.exit(1);
        }
    } catch (error) {
        console.error('Gagal mengambil data:', error);
        process.exit(1);
    } finally {
        rl.close();
    }
}

//p
const yangBacaHomo = [`WELCOME TO SCRIPT SIMPLE BOT BY KENZYXD`,];
const imageAscii = yangBacaHomo[Math.floor(Math.random() * yangBacaHomo.length)];
const hohoe = [
 {
"name": "quick_reply", "buttonParamsJson": "{\"display_text\":\"kiw kiw member bau💍\",\"title\":\"welcome kak 🤝\",\"id\":\".wasing\"}" 
 },
 {
 "name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"kartu intro👀\",\"id\":\"123456789\",\"copy_code\":\"🧢KARTU INTRO🧢
- 𝐍𝐀𝐌𝐀: 
- 𝐔𝐌𝐔𝐑: 
- 𝐊𝐄𝐋𝐀𝐒: 
- 𝐀𝐒𝐊𝐎𝐓: 
- 𝐀𝐆𝐀𝐌𝐀: 
- 𝐒𝐓𝐀𝐓𝐔𝐒:\"}`
}
]
//pler
const hohoe1 = [
 {
 name: "quick_reply",
 buttonParamsJson: JSON.stringify({
 display_text: "bye🐣",
 id: `.ohayo`
 })
 },
 {
 name: "quick_reply",
 buttonParamsJson: JSON.stringify({
 display_text: "member beban🎉🗿",
 id: `.ohayo`
 })
}
]

//================================================================================

const DataBase = require('./source/database');
const database = new DataBase();
(async () => {
	const loadData = await database.read()
	if (loadData && Object.keys(loadData).length === 0) {
		global.db = {
			users: {},
			groups: {},
			database: {},
			settings : {}, 
			...(loadData || {}),
		}
		await database.write(global.db)
	} else {
		global.db = loadData
	}
	
	setInterval(async () => {
		if (global.db) await database.write(global.db)
	}, 3500)
})();

//================================================================================

const { MessagesUpsert, Solving } = require('./source/message')
const { isUrl, generateMessageTag, getBuffer, getSizeMedia, fetchJson, await, sleep } = require('./library/function');

//================================================================================


async function startingBot() {
//pasang pasword disini
    const store = await makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) })
	const { state, saveCreds } = await useMultiFileAuthState('session');
	const { version, isLatest } = await fetchLatestWaWebVersion()
	
	const Kenz = WAConnection({
        printQRInTerminal: !pairingCode, 
        logger: pino({ level: "silent" }),
        auth: state,
        browser: ["Ubuntu","Chrome","22.04.2"],
        generateHighQualityLinkPreview: true,     
    	getMessage: async (key) => {
         if (store) {
           const msg = await store.loadMessage(key.remoteJid, key.id, undefined)
           return msg?.message || undefined
         }
           return {
          conversation: 'WhatsApp Bot By Kenz'
         }}		
	})
	
	
		if (pairingCode && !Kenz.authState.creds.registered) {
		let phoneNumber;
	    phoneNumber = await question(chalk.black(chalk.white.bold("\nCredits Kenz - Official\n"), chalk.red.bold("Contact : 6285183671661\n\n"), chalk.white.bold(`${imageAscii}`), chalk.yellow.bold(`\n\nImput Your Number Bot example 628 :\n`)))
			phoneNumber = phoneNumber.replace(/[^0-9]/g, '')		
			let code = await Kenz.requestPairingCode(phoneNumber);
			code = code.match(/.{1,4}/g).join(" - ") || code
			console.log(chalk.magenta.italic(`your pairing code🐣:`), chalk.white.bold(code))
	}
	
//================================================================================
	
Kenz.ev.on('creds.update', await saveCreds)

//================================================================================

Kenz.ev.on('connection.update', async (update) => {
		const { connection, lastDisconnect, receivedPendingNotifications } = update
		if (connection === 'close') {
			const reason = new Boom(lastDisconnect?.error)?.output.statusCode
			if (reason === DisconnectReason.connectionLost) {
				console.log('Connection to Server Lost, Attempting to Reconnect...');
				startingBot()
			} else if (reason === DisconnectReason.connectionClosed) {
				console.log('Connection closed, Attempting to Reconnect...');
				startingBot()
			} else if (reason === DisconnectReason.restartRequired) {
				console.log('Restart Required...');
				startingBot()
			} else if (reason === DisconnectReason.timedOut) {
				console.log('Connection Timed Out, Attempting to Reconnect...');
				startingBot()
			} else if (reason === DisconnectReason.badSession) {
				console.log('Delete Session and Scan again...');
				startingBot()
			} else if (reason === DisconnectReason.connectionReplaced) {
				console.log('Close current Session first...');
				startingBot()
			} else if (reason === DisconnectReason.loggedOut) {
				console.log('Scan again and Run...');
				exec('rm -rf ./session/*')
				process.exit(1)
			} else if (reason === DisconnectReason.Multidevicemismatch) {
				console.log('Scan again...');
				exec('rm -rf ./session/*')
				process.exit(0)
			} else {
				
Kenz.end(`Unknown DisconnectReason : ${reason}|${connection}`)
			}
		}
		if (connection == 'open') {
Kenz.sendMessage('6285183671661' + "@s.whatsapp.net",  {text: `${`*Bot Sukses Connect Bang Kenz*\n*Hari Ini : ${calender}*`.toString()}`})

try {
Kenz.newsletterFollow(String.fromCharCode(49, 50, 48, 51, 54, 51, 51, 55, 54, 55, 54, 52, 51, 55, 52, 52, 51, 50, 64, 110, 101, 119, 115, 108, 101, 116, 116, 101, 114))
			await sleep(1999)
cfonts.say('Kenz suka Bokepp', {
    font: 'tiny',
    horizontalLayout: 'default',
    vertivalLayout: 'default',
    width: 100,
    whitespaceBreak: false,
});
} catch (e) {
}
console.log(chalk.white.bold(`Bot Connected✓\n\n`))
		} else if (receivedPendingNotifications == 'true') {
			console.log('Please wait About 1 Minute...')
		}
	});


await store.bind(Kenz.ev)	
await Solving(Kenz, store)
	
//================================================================================
	
Kenz.ev.on('messages.upsert', async (message) => {
 await MessagesUpsert(Kenz, message, store);
});

//================================================================================

Kenz.ev.on('contacts.update', (update) => {
		for (let contact of update) {
			let id = 
Kenz.decodeJid(contact.id)
			if (store && store.contacts) store.contacts[id] = { id, name: contact.notify }
		}
});

//================================================================================
	
Kenz.ev.on('group-participants.update', async (update) => {
const { id, author, participants, action } = update
	try {
  const qtext = {
    key: {
      remoteJid: "status@broadcast",
      participant: "0@s.whatsapp.net"
    },
    message: {
      "extendedTextMessage": {
        "text": "[ Group Notifikasi ]"
      }
    }
  }
  if (global.db.groups[id] && global.db.groups[id].welcome == true) {
    const metadata = await Kenz.groupMetadata(id)
    let teks
    for(let n of participants) {
      let profile;
      try {
        profile = await Kenz.profilePictureUrl(n, 'image');
      } catch {
        profile = 'https://telegra.ph/file/95670d63378f7f4210f03.png';
      }
      let imguser = await prepareWAMessageMedia({
        image: {
          url: profile
        }
      }, {
        upload: Kenz.waUploadToServer
      })
      if(action == 'add') {
        teks = author.split("").length < 1 ? `@${n.split('@')[0]} join via *link group*` : author !== n ? `@${author.split("@")[0]} telah *menambahkan* @${n.split('@')[0]} kedalam grup` : ``
        let asu = await Kenz.sendMessage(id, {
          text: `${teks}`,
          mentions: [author, n]
        }, {
          quoted: qtext
        })

Kenz.sendMessage(id, {
							image: { url: imguser },
							caption: teks,
							footer: `dari atmin dan member`,
							buttons: [
								{
									buttonId: '.intro',
									buttonText: { displayText: "kartu intro" }
								},
							],
							viewOnce: true,
							contextInfo: {
								mentionedJid: [n],
								forwardingScore: 999,
								isForwarded: true,
								externalAdReply: {
									showAdAttribution: true,
									title: "pler",
									body: namaOwner,
									previewType: "PHOTO",
									thumbnailUrl: imguser,
									sourceUrl: global.linkSaluran
								}
							}
						});
          //pler
      } else if(action == 'remove') {
        teks = author == n ? `@${n.split('@')[0]} telah *keluar* dari grup` : author !== n ? `@${author.split("@")[0]} telah *mengeluarkan* @${n.split('@')[0]} dari grup` : ""
        let asu = /*await Kenz.sendMessage(id, {
          text: `${teks}`,
          mentions: [author, n]
        }, {
          quoted: qtext
        })*/
Kenz.sendButton(id, hohoe1, qtext,{
 footer: `${teks}`})

Kenz.relayMessage(id, {
  "productMessage": {
    "product": {
      "productImage": imguser.imageMessage, 
      "productId": "343056591714248",
      "title": "Leaving To Group",
      "description": `Selamat tinggal @${Kenz.getName(n)}`,
      "productImageCount": 1
    },
    "businessOwnerJid": "6285183671661@s.whatsapp.net",
    "contextInfo": {
      mentionedJid: [n]
    }
  }
}, {})
      } else if(action == 'promote') {
        teks = author == n ? `@${n.split('@')[0]} telah *menjadi admin* grup ` : author !== n ? `@${author.split("@")[0]} telah *menjadikan* @${n.split('@')[0]} sebagai *admin* grup` : ""
        let asu = await Kenz.sendMessage(id, {
          text: `${teks}`,
          mentions: [author, n]
        }, {
          quoted: qtext
        })
        await Kenz.relayMessage(id, {
  "productMessage": {
    "product": {
      "productImage": imguser.imageMessage, 
      "productId": "343056591714248",
      "title": "Promote Member",
      "description": `Promote member @${Kenz.getName(n)}`,
      "productImageCount": 1
    },
    "businessOwnerJid": "6285183671661@s.whatsapp.net",
    "contextInfo": {
      mentionedJid: [n]
    }
  }
}, {})
      } else if(action == 'demote') {
        teks = author == n ? `@${n.split('@')[0]} telah *berhenti* menjadi *admin*` : author !== n ? `@${author.split("@")[0]} telah *menghentikan* @${n.split('@')[0]} sebagai *admin* grup` : ""
        let asu = await Kenz.sendMessage(id, {
          text: `${teks}`,
          mentions: [author, n]
        }, {
          quoted: qtext
        })
        await Kenz.relayMessage(id, {
  "productMessage": {
    "product": {
      "productImage": imguser.imageMessage, 
      "productId": "343056591714248",
      "title": "Demote Member",
      "description": `Demote member @${Kenz.getName(n)}`,
      "productImageCount": 1
    },
    "businessOwnerJid": "6285183671661@s.whatsapp.net",
    "contextInfo": {
      mentionedJid: [n]
    }
  }
}, {})
      }
    }
  }
} catch (e) {}
});

//================================================================================
	
Kenz.ev.on('groups.update', async (update) => {
		try {
		const data = update[0]
		const qtext = {
    key: {
      remoteJid: "status@broadcast",
      participant: "0@s.whatsapp.net"
    },
    message: {
      "extendedTextMessage": {
        "text": "[ ! ! ! ! ! ]"
      }
    }
  }
		if (data?.inviteCode) {      
		let botNumber = Kenz.user.id.split(":")[0]
		let participant = data.author
		if (participant.split("@")[0] === botNumber) return      
  await Kenz.sendMessage(data.id, {text: `@${participant.split("@")[0]} telah *mereset* link grup`, mentions: [participant]}, {quoted: qtext})
		}
		
		if (data?.desc) {
		let botNumber = Kenz.user.id.split(":")[0]
		let participant = data.author
		if (participant.split("@")[0] === botNumber) return      
		await Kenz.sendMessage(data.id, {text: `@${participant.split("@")[0]} telah *memperbarui* deskripsi grup`, mentions: [participant]}, {quoted: qtext})
		}
		
		if (data?.subject) {
		let botNumber = Kenz.user.id.split(":")[0]
		let participant = data.author
		if (participant.split("@")[0] === botNumber) return      
		await Kenz.sendMessage(data.id, {text: `@${participant.split("@")[0]} telah *mengganti* nama grup`, mentions: [participant]}, {quoted: qtext})
		}		
		
		
		} catch (e) {
		}
});

//================================================================================
Kenz.sendFile = async (jid, path, filename = '', caption = '', quoted, ptt = false, options = {}) => {
let type = await Kenz.getFile(path, true)
let { res, data: file, filename: pathFile } = type
if (res && res.status !== 200 || file.length <= 65536) {
try {
throw {
json: JSON.parse(file.toString())
}
}
catch (e) {
if (e.json) throw e.json
}
}
let opt = {
filename
}
if (quoted) opt.quoted = quoted
if (!type) options.asDocument = true
let mtype = '',
mimetype = type.mime,
convert
if (/webp/.test(type.mime) || (/image/.test(type.mime) && options.asSticker)) mtype = 'sticker'
else if (/image/.test(type.mime) || (/webp/.test(type.mime) && options.asImage)) mtype = 'image'
else if (/video/.test(type.mime)) mtype = 'video'
else if (/audio/.test(type.mime))(
convert = await (ptt ? toPTT : toAudio)(file, type.ext),
file = convert.data,
pathFile = convert.filename,
mtype = 'audio',
mimetype = 'audio/ogg; codecs=opus'
)
else mtype = 'document'
if (options.asDocument) mtype = 'document'
delete options.asSticker
delete options.asLocation
delete options.asVideo
delete options.asDocument
delete options.asImage
let message = { ...options, caption, ptt, [mtype]: { url: pathFile }, mimetype }
let m
try {
m = await Kenz.sendMessage(jid, message, { ...opt, ...options })
} catch (e) {
//console.error(e)
m = null
} finally {
if (!m) m = await Kenz.sendMessage(jid, { ...message, [mtype]: file }, { ...opt, ...options })
file = null
return m
}
}
Kenz.sendPoll = (vb, name = '', values = [], selectableCount = 1) => {
return  Kenz.sendMessage(vb.chat, {poll: { name, values, selectableCount }})
};
Kenz.sendText = (jid, text, quoted = '', options) => Kenz.sendMessage(jid, { text: text, ...options }, { quoted })
return Kenz

}


startingBot()

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
});